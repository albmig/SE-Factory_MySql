﻿namespace SE_Factory
{


    partial class DB_FactoryDataSet
    {
        partial class GC_KitDataTable
        {
        }

        partial class NM_V_ANAGRAFICA_DB_DESCRIZIONEESTESADataTable
        {
        }

        partial class NM_V_ANAGRAFICA_DBDataTable
        {
        }

        partial class xls_SerialsDataTable
        {
        }
    }
}

namespace SE_Factory.DB_FactoryDataSetTableAdapters
{
    partial class GC_KitTableAdapter
    {
    }
}
