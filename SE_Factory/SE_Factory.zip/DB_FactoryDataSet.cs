﻿namespace SE_Factory
{


    partial class DB_FactoryDataSet
    {
    }
}
