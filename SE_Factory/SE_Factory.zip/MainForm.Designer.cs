﻿namespace SE_Factory
{
    partial class MainForm
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel_Menu = new MetroFramework.Controls.MetroPanel();
            this.menu_spacer_01 = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_ID = new MetroFramework.Controls.MetroTile();
            this.panel_Main = new MetroFramework.Controls.MetroPanel();
            this.panel_ID = new MetroFramework.Controls.MetroPanel();
            this.ID_pan_C = new MetroFramework.Controls.MetroPanel();
            this.ID_lab_Controller = new MetroFramework.Controls.MetroLabel();
            this.ID_pan_P = new MetroFramework.Controls.MetroPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ID_radio_868 = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_433 = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_915 = new MetroFramework.Controls.MetroRadioButton();
            this.ID_toggle_Fungo = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Torcia = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Vibracall = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Buzzer = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_SP = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Accel = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Display = new MetroFramework.Controls.MetroToggle();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.ID_lab_scheda_des = new System.Windows.Forms.Label();
            this.schedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dB_FactoryDataSet = new SE_Factory.DB_FactoryDataSet();
            this.ID_combo_Scheda_P = new System.Windows.Forms.ComboBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.ID_lab_Palmare = new MetroFramework.Controls.MetroLabel();
            this.ID_pan_bottom = new MetroFramework.Controls.MetroPanel();
            this.ID_Result = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.ID_pan_Top = new MetroFramework.Controls.MetroPanel();
            this.ID_combo_Famiglia = new System.Windows.Forms.ComboBox();
            this.famProdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.titolo_ID = new MetroFramework.Controls.MetroLabel();
            this.ID_lab_Famiglia = new MetroFramework.Controls.MetroLabel();
            this.fam_ProdTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter();
            this.schedeTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SchedeTableAdapter();
            this.ID_timer = new System.Windows.Forms.Timer(this.components);
            this.panel_Menu.SuspendLayout();
            this.panel_ID.SuspendLayout();
            this.ID_pan_C.SuspendLayout();
            this.ID_pan_P.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.schedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).BeginInit();
            this.ID_pan_bottom.SuspendLayout();
            this.ID_pan_Top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Menu
            // 
            this.panel_Menu.BackColor = System.Drawing.Color.Transparent;
            this.panel_Menu.Controls.Add(this.menu_spacer_01);
            this.panel_Menu.Controls.Add(this.menu_btn_ID);
            this.panel_Menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Menu.HorizontalScrollbarBarColor = true;
            this.panel_Menu.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Menu.HorizontalScrollbarSize = 10;
            this.panel_Menu.Location = new System.Drawing.Point(23, 83);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(150, 590);
            this.panel_Menu.TabIndex = 1;
            this.panel_Menu.VerticalScrollbarBarColor = true;
            this.panel_Menu.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Menu.VerticalScrollbarSize = 10;
            // 
            // menu_spacer_01
            // 
            this.menu_spacer_01.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_spacer_01.HorizontalScrollbarBarColor = true;
            this.menu_spacer_01.HorizontalScrollbarHighlightOnWheel = false;
            this.menu_spacer_01.HorizontalScrollbarSize = 10;
            this.menu_spacer_01.Location = new System.Drawing.Point(0, 50);
            this.menu_spacer_01.Name = "menu_spacer_01";
            this.menu_spacer_01.Size = new System.Drawing.Size(150, 10);
            this.menu_spacer_01.TabIndex = 3;
            this.menu_spacer_01.VerticalScrollbarBarColor = true;
            this.menu_spacer_01.VerticalScrollbarHighlightOnWheel = false;
            this.menu_spacer_01.VerticalScrollbarSize = 10;
            // 
            // menu_btn_ID
            // 
            this.menu_btn_ID.ActiveControl = null;
            this.menu_btn_ID.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_ID.Location = new System.Drawing.Point(0, 0);
            this.menu_btn_ID.Name = "menu_btn_ID";
            this.menu_btn_ID.Size = new System.Drawing.Size(150, 50);
            this.menu_btn_ID.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_ID.TabIndex = 2;
            this.menu_btn_ID.Text = "Calcolo ID";
            this.menu_btn_ID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_ID.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_ID.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_ID.TileImage")));
            this.menu_btn_ID.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_ID.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_ID.UseCustomForeColor = true;
            this.menu_btn_ID.UseSelectable = true;
            this.menu_btn_ID.UseTileImage = true;
            this.menu_btn_ID.Click += new System.EventHandler(this.menu_btn_ID_Click);
            // 
            // panel_Main
            // 
            this.panel_Main.BackColor = System.Drawing.Color.White;
            this.panel_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main.HorizontalScrollbarBarColor = true;
            this.panel_Main.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Main.HorizontalScrollbarSize = 10;
            this.panel_Main.Location = new System.Drawing.Point(173, 83);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(770, 590);
            this.panel_Main.TabIndex = 2;
            this.panel_Main.UseCustomBackColor = true;
            this.panel_Main.VerticalScrollbarBarColor = true;
            this.panel_Main.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Main.VerticalScrollbarSize = 10;
            // 
            // panel_ID
            // 
            this.panel_ID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel_ID.Controls.Add(this.ID_pan_C);
            this.panel_ID.Controls.Add(this.ID_pan_P);
            this.panel_ID.Controls.Add(this.ID_pan_bottom);
            this.panel_ID.Controls.Add(this.ID_pan_Top);
            this.panel_ID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ID.HorizontalScrollbarBarColor = true;
            this.panel_ID.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_ID.HorizontalScrollbarSize = 10;
            this.panel_ID.Location = new System.Drawing.Point(173, 83);
            this.panel_ID.Name = "panel_ID";
            this.panel_ID.Size = new System.Drawing.Size(770, 590);
            this.panel_ID.TabIndex = 3;
            this.panel_ID.UseCustomBackColor = true;
            this.panel_ID.VerticalScrollbarBarColor = true;
            this.panel_ID.VerticalScrollbarHighlightOnWheel = false;
            this.panel_ID.VerticalScrollbarSize = 10;
            this.panel_ID.Visible = false;
            // 
            // ID_pan_C
            // 
            this.ID_pan_C.Controls.Add(this.ID_lab_Controller);
            this.ID_pan_C.Dock = System.Windows.Forms.DockStyle.Left;
            this.ID_pan_C.HorizontalScrollbarBarColor = true;
            this.ID_pan_C.HorizontalScrollbarHighlightOnWheel = false;
            this.ID_pan_C.HorizontalScrollbarSize = 10;
            this.ID_pan_C.Location = new System.Drawing.Point(586, 100);
            this.ID_pan_C.Name = "ID_pan_C";
            this.ID_pan_C.Size = new System.Drawing.Size(341, 440);
            this.ID_pan_C.TabIndex = 6;
            this.ID_pan_C.VerticalScrollbarBarColor = true;
            this.ID_pan_C.VerticalScrollbarHighlightOnWheel = false;
            this.ID_pan_C.VerticalScrollbarSize = 10;
            this.ID_pan_C.Visible = false;
            // 
            // ID_lab_Controller
            // 
            this.ID_lab_Controller.AutoSize = true;
            this.ID_lab_Controller.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.ID_lab_Controller.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.ID_lab_Controller.Location = new System.Drawing.Point(20, 20);
            this.ID_lab_Controller.Name = "ID_lab_Controller";
            this.ID_lab_Controller.Size = new System.Drawing.Size(90, 25);
            this.ID_lab_Controller.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_lab_Controller.TabIndex = 8;
            this.ID_lab_Controller.Text = "Controller";
            this.ID_lab_Controller.UseStyleColors = true;
            // 
            // ID_pan_P
            // 
            this.ID_pan_P.Controls.Add(this.groupBox1);
            this.ID_pan_P.Controls.Add(this.ID_toggle_Fungo);
            this.ID_pan_P.Controls.Add(this.ID_toggle_Torcia);
            this.ID_pan_P.Controls.Add(this.ID_toggle_Vibracall);
            this.ID_pan_P.Controls.Add(this.ID_toggle_Buzzer);
            this.ID_pan_P.Controls.Add(this.ID_toggle_SP);
            this.ID_pan_P.Controls.Add(this.ID_toggle_Accel);
            this.ID_pan_P.Controls.Add(this.ID_toggle_Display);
            this.ID_pan_P.Controls.Add(this.metroLabel9);
            this.ID_pan_P.Controls.Add(this.metroLabel8);
            this.ID_pan_P.Controls.Add(this.metroLabel7);
            this.ID_pan_P.Controls.Add(this.metroLabel6);
            this.ID_pan_P.Controls.Add(this.metroLabel5);
            this.ID_pan_P.Controls.Add(this.metroLabel4);
            this.ID_pan_P.Controls.Add(this.metroLabel3);
            this.ID_pan_P.Controls.Add(this.metroLabel2);
            this.ID_pan_P.Controls.Add(this.ID_lab_scheda_des);
            this.ID_pan_P.Controls.Add(this.ID_combo_Scheda_P);
            this.ID_pan_P.Controls.Add(this.metroLabel1);
            this.ID_pan_P.Controls.Add(this.ID_lab_Palmare);
            this.ID_pan_P.Dock = System.Windows.Forms.DockStyle.Left;
            this.ID_pan_P.HorizontalScrollbarBarColor = true;
            this.ID_pan_P.HorizontalScrollbarHighlightOnWheel = false;
            this.ID_pan_P.HorizontalScrollbarSize = 10;
            this.ID_pan_P.Location = new System.Drawing.Point(0, 100);
            this.ID_pan_P.Name = "ID_pan_P";
            this.ID_pan_P.Size = new System.Drawing.Size(586, 440);
            this.ID_pan_P.TabIndex = 5;
            this.ID_pan_P.UseCustomBackColor = true;
            this.ID_pan_P.VerticalScrollbarBarColor = true;
            this.ID_pan_P.VerticalScrollbarHighlightOnWheel = false;
            this.ID_pan_P.VerticalScrollbarSize = 10;
            this.ID_pan_P.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ID_radio_868);
            this.groupBox1.Controls.Add(this.ID_radio_433);
            this.groupBox1.Controls.Add(this.ID_radio_915);
            this.groupBox1.Location = new System.Drawing.Point(159, 132);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 20);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            // 
            // ID_radio_868
            // 
            this.ID_radio_868.AutoSize = true;
            this.ID_radio_868.Location = new System.Drawing.Point(0, 0);
            this.ID_radio_868.Name = "ID_radio_868";
            this.ID_radio_868.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_868.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_868.TabIndex = 32;
            this.ID_radio_868.Text = "868";
            this.ID_radio_868.UseCustomBackColor = true;
            this.ID_radio_868.UseSelectable = true;
            this.ID_radio_868.UseStyleColors = true;
            // 
            // ID_radio_433
            // 
            this.ID_radio_433.AutoSize = true;
            this.ID_radio_433.Location = new System.Drawing.Point(140, 0);
            this.ID_radio_433.Name = "ID_radio_433";
            this.ID_radio_433.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_433.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_433.TabIndex = 34;
            this.ID_radio_433.Text = "433";
            this.ID_radio_433.UseCustomBackColor = true;
            this.ID_radio_433.UseSelectable = true;
            this.ID_radio_433.UseStyleColors = true;
            // 
            // ID_radio_915
            // 
            this.ID_radio_915.AutoSize = true;
            this.ID_radio_915.Location = new System.Drawing.Point(70, 0);
            this.ID_radio_915.Name = "ID_radio_915";
            this.ID_radio_915.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_915.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_915.TabIndex = 33;
            this.ID_radio_915.Text = "915";
            this.ID_radio_915.UseCustomBackColor = true;
            this.ID_radio_915.UseSelectable = true;
            this.ID_radio_915.UseStyleColors = true;
            // 
            // ID_toggle_Fungo
            // 
            this.ID_toggle_Fungo.AutoSize = true;
            this.ID_toggle_Fungo.Location = new System.Drawing.Point(159, 344);
            this.ID_toggle_Fungo.Name = "ID_toggle_Fungo";
            this.ID_toggle_Fungo.Size = new System.Drawing.Size(80, 22);
            this.ID_toggle_Fungo.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Fungo.TabIndex = 28;
            this.ID_toggle_Fungo.Text = "Off";
            this.ID_toggle_Fungo.UseSelectable = true;
            // 
            // ID_toggle_Torcia
            // 
            this.ID_toggle_Torcia.AutoSize = true;
            this.ID_toggle_Torcia.Location = new System.Drawing.Point(159, 313);
            this.ID_toggle_Torcia.Name = "ID_toggle_Torcia";
            this.ID_toggle_Torcia.Size = new System.Drawing.Size(80, 22);
            this.ID_toggle_Torcia.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Torcia.TabIndex = 27;
            this.ID_toggle_Torcia.Text = "Off";
            this.ID_toggle_Torcia.UseSelectable = true;
            // 
            // ID_toggle_Vibracall
            // 
            this.ID_toggle_Vibracall.AutoSize = true;
            this.ID_toggle_Vibracall.Location = new System.Drawing.Point(159, 282);
            this.ID_toggle_Vibracall.Name = "ID_toggle_Vibracall";
            this.ID_toggle_Vibracall.Size = new System.Drawing.Size(80, 22);
            this.ID_toggle_Vibracall.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Vibracall.TabIndex = 26;
            this.ID_toggle_Vibracall.Text = "Off";
            this.ID_toggle_Vibracall.UseSelectable = true;
            // 
            // ID_toggle_Buzzer
            // 
            this.ID_toggle_Buzzer.AutoSize = true;
            this.ID_toggle_Buzzer.Location = new System.Drawing.Point(159, 251);
            this.ID_toggle_Buzzer.Name = "ID_toggle_Buzzer";
            this.ID_toggle_Buzzer.Size = new System.Drawing.Size(80, 22);
            this.ID_toggle_Buzzer.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Buzzer.TabIndex = 25;
            this.ID_toggle_Buzzer.Text = "Off";
            this.ID_toggle_Buzzer.UseSelectable = true;
            // 
            // ID_toggle_SP
            // 
            this.ID_toggle_SP.AutoSize = true;
            this.ID_toggle_SP.Location = new System.Drawing.Point(159, 220);
            this.ID_toggle_SP.Name = "ID_toggle_SP";
            this.ID_toggle_SP.Size = new System.Drawing.Size(80, 22);
            this.ID_toggle_SP.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_SP.TabIndex = 24;
            this.ID_toggle_SP.Text = "Off";
            this.ID_toggle_SP.UseSelectable = true;
            // 
            // ID_toggle_Accel
            // 
            this.ID_toggle_Accel.AutoSize = true;
            this.ID_toggle_Accel.Location = new System.Drawing.Point(159, 189);
            this.ID_toggle_Accel.Name = "ID_toggle_Accel";
            this.ID_toggle_Accel.Size = new System.Drawing.Size(80, 22);
            this.ID_toggle_Accel.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Accel.TabIndex = 23;
            this.ID_toggle_Accel.Text = "Off";
            this.ID_toggle_Accel.UseSelectable = true;
            // 
            // ID_toggle_Display
            // 
            this.ID_toggle_Display.AutoSize = true;
            this.ID_toggle_Display.Checked = true;
            this.ID_toggle_Display.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ID_toggle_Display.Location = new System.Drawing.Point(159, 158);
            this.ID_toggle_Display.Name = "ID_toggle_Display";
            this.ID_toggle_Display.Size = new System.Drawing.Size(80, 22);
            this.ID_toggle_Display.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Display.TabIndex = 22;
            this.ID_toggle_Display.Text = "On";
            this.ID_toggle_Display.UseSelectable = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(20, 347);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(119, 19);
            this.metroLabel9.TabIndex = 20;
            this.metroLabel9.Text = "Fungo Emergenza:";
            this.metroLabel9.UseCustomBackColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(20, 316);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(46, 19);
            this.metroLabel8.TabIndex = 19;
            this.metroLabel8.Text = "Torcia:";
            this.metroLabel8.UseCustomBackColor = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(20, 285);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(62, 19);
            this.metroLabel7.TabIndex = 18;
            this.metroLabel7.Text = "Vibracall:";
            this.metroLabel7.UseCustomBackColor = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(20, 254);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(52, 19);
            this.metroLabel6.TabIndex = 17;
            this.metroLabel6.Text = "Buzzer:";
            this.metroLabel6.UseCustomBackColor = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(20, 223);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(80, 19);
            this.metroLabel5.TabIndex = 16;
            this.metroLabel5.Text = "Safety Point:";
            this.metroLabel5.UseCustomBackColor = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(20, 192);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(99, 19);
            this.metroLabel4.TabIndex = 15;
            this.metroLabel4.Text = "Accelerometro:";
            this.metroLabel4.UseCustomBackColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(20, 161);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(86, 19);
            this.metroLabel3.TabIndex = 14;
            this.metroLabel3.Text = "Display Oled:";
            this.metroLabel3.UseCustomBackColor = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(20, 130);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(111, 19);
            this.metroLabel2.TabIndex = 13;
            this.metroLabel2.Text = "Frequenza Radio:";
            this.metroLabel2.UseCustomBackColor = true;
            // 
            // ID_lab_scheda_des
            // 
            this.ID_lab_scheda_des.AutoSize = true;
            this.ID_lab_scheda_des.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.schedeBindingSource, "Prod_Descrizione", true));
            this.ID_lab_scheda_des.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ID_lab_scheda_des.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_lab_scheda_des.Location = new System.Drawing.Point(156, 94);
            this.ID_lab_scheda_des.Name = "ID_lab_scheda_des";
            this.ID_lab_scheda_des.Size = new System.Drawing.Size(107, 17);
            this.ID_lab_scheda_des.TabIndex = 12;
            this.ID_lab_scheda_des.Text = "ID_lab_scheda_des";
            // 
            // schedeBindingSource
            // 
            this.schedeBindingSource.DataMember = "Schede";
            this.schedeBindingSource.DataSource = this.dB_FactoryDataSet;
            this.schedeBindingSource.CurrentChanged += new System.EventHandler(this.schedeBindingSource_CurrentChanged);
            // 
            // dB_FactoryDataSet
            // 
            this.dB_FactoryDataSet.DataSetName = "DB_FactoryDataSet";
            this.dB_FactoryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ID_combo_Scheda_P
            // 
            this.ID_combo_Scheda_P.DataSource = this.schedeBindingSource;
            this.ID_combo_Scheda_P.DisplayMember = "Prod_Sch";
            this.ID_combo_Scheda_P.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ID_combo_Scheda_P.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.ID_combo_Scheda_P.FormattingEnabled = true;
            this.ID_combo_Scheda_P.ItemHeight = 15;
            this.ID_combo_Scheda_P.Location = new System.Drawing.Point(159, 66);
            this.ID_combo_Scheda_P.Name = "ID_combo_Scheda_P";
            this.ID_combo_Scheda_P.Size = new System.Drawing.Size(277, 23);
            this.ID_combo_Scheda_P.TabIndex = 11;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(20, 66);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(108, 19);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Scheda utilizzata:";
            this.metroLabel1.UseCustomBackColor = true;
            // 
            // ID_lab_Palmare
            // 
            this.ID_lab_Palmare.AutoSize = true;
            this.ID_lab_Palmare.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.ID_lab_Palmare.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.ID_lab_Palmare.Location = new System.Drawing.Point(20, 20);
            this.ID_lab_Palmare.Name = "ID_lab_Palmare";
            this.ID_lab_Palmare.Size = new System.Drawing.Size(74, 25);
            this.ID_lab_Palmare.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_lab_Palmare.TabIndex = 7;
            this.ID_lab_Palmare.Text = "Palmare";
            this.ID_lab_Palmare.UseCustomBackColor = true;
            this.ID_lab_Palmare.UseStyleColors = true;
            // 
            // ID_pan_bottom
            // 
            this.ID_pan_bottom.BackColor = System.Drawing.Color.SkyBlue;
            this.ID_pan_bottom.Controls.Add(this.ID_Result);
            this.ID_pan_bottom.Controls.Add(this.metroLabel10);
            this.ID_pan_bottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ID_pan_bottom.HorizontalScrollbarBarColor = true;
            this.ID_pan_bottom.HorizontalScrollbarHighlightOnWheel = false;
            this.ID_pan_bottom.HorizontalScrollbarSize = 10;
            this.ID_pan_bottom.Location = new System.Drawing.Point(0, 540);
            this.ID_pan_bottom.Name = "ID_pan_bottom";
            this.ID_pan_bottom.Size = new System.Drawing.Size(770, 50);
            this.ID_pan_bottom.TabIndex = 7;
            this.ID_pan_bottom.UseCustomBackColor = true;
            this.ID_pan_bottom.VerticalScrollbarBarColor = true;
            this.ID_pan_bottom.VerticalScrollbarHighlightOnWheel = false;
            this.ID_pan_bottom.VerticalScrollbarSize = 10;
            // 
            // ID_Result
            // 
            // 
            // 
            // 
            this.ID_Result.CustomButton.Image = null;
            this.ID_Result.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.ID_Result.CustomButton.Name = "";
            this.ID_Result.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.ID_Result.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.ID_Result.CustomButton.TabIndex = 1;
            this.ID_Result.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.ID_Result.CustomButton.UseSelectable = true;
            this.ID_Result.CustomButton.Visible = false;
            this.ID_Result.Lines = new string[0];
            this.ID_Result.Location = new System.Drawing.Point(159, 13);
            this.ID_Result.MaxLength = 32767;
            this.ID_Result.Name = "ID_Result";
            this.ID_Result.PasswordChar = '\0';
            this.ID_Result.ReadOnly = true;
            this.ID_Result.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ID_Result.SelectedText = "";
            this.ID_Result.SelectionLength = 0;
            this.ID_Result.SelectionStart = 0;
            this.ID_Result.ShortcutsEnabled = true;
            this.ID_Result.Size = new System.Drawing.Size(75, 23);
            this.ID_Result.TabIndex = 5;
            this.ID_Result.UseSelectable = true;
            this.ID_Result.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.ID_Result.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.ForeColor = System.Drawing.Color.Red;
            this.metroLabel10.Location = new System.Drawing.Point(20, 15);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(58, 19);
            this.metroLabel10.TabIndex = 4;
            this.metroLabel10.Text = "Sigla ID:";
            this.metroLabel10.UseCustomBackColor = true;
            this.metroLabel10.UseCustomForeColor = true;
            // 
            // ID_pan_Top
            // 
            this.ID_pan_Top.Controls.Add(this.ID_combo_Famiglia);
            this.ID_pan_Top.Controls.Add(this.titolo_ID);
            this.ID_pan_Top.Controls.Add(this.ID_lab_Famiglia);
            this.ID_pan_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.ID_pan_Top.HorizontalScrollbarBarColor = true;
            this.ID_pan_Top.HorizontalScrollbarHighlightOnWheel = false;
            this.ID_pan_Top.HorizontalScrollbarSize = 10;
            this.ID_pan_Top.Location = new System.Drawing.Point(0, 0);
            this.ID_pan_Top.Name = "ID_pan_Top";
            this.ID_pan_Top.Size = new System.Drawing.Size(770, 100);
            this.ID_pan_Top.TabIndex = 4;
            this.ID_pan_Top.UseCustomBackColor = true;
            this.ID_pan_Top.VerticalScrollbarBarColor = true;
            this.ID_pan_Top.VerticalScrollbarHighlightOnWheel = false;
            this.ID_pan_Top.VerticalScrollbarSize = 10;
            // 
            // ID_combo_Famiglia
            // 
            this.ID_combo_Famiglia.DataSource = this.famProdBindingSource;
            this.ID_combo_Famiglia.DisplayMember = "Fam_Name";
            this.ID_combo_Famiglia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ID_combo_Famiglia.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_combo_Famiglia.FormattingEnabled = true;
            this.ID_combo_Famiglia.ItemHeight = 15;
            this.ID_combo_Famiglia.Location = new System.Drawing.Point(159, 68);
            this.ID_combo_Famiglia.Name = "ID_combo_Famiglia";
            this.ID_combo_Famiglia.Size = new System.Drawing.Size(277, 23);
            this.ID_combo_Famiglia.TabIndex = 6;
            this.ID_combo_Famiglia.ValueMember = "Fam_Tipo";
            // 
            // famProdBindingSource
            // 
            this.famProdBindingSource.DataMember = "Fam_Prod";
            this.famProdBindingSource.DataSource = this.dB_FactoryDataSet;
            this.famProdBindingSource.CurrentChanged += new System.EventHandler(this.famProdBindingSource_CurrentChanged);
            // 
            // titolo_ID
            // 
            this.titolo_ID.AutoSize = true;
            this.titolo_ID.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.titolo_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.titolo_ID.Location = new System.Drawing.Point(20, 20);
            this.titolo_ID.Name = "titolo_ID";
            this.titolo_ID.Size = new System.Drawing.Size(125, 25);
            this.titolo_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.titolo_ID.TabIndex = 2;
            this.titolo_ID.Text = "Calcolo dell\'ID";
            this.titolo_ID.UseCustomBackColor = true;
            this.titolo_ID.UseStyleColors = true;
            // 
            // ID_lab_Famiglia
            // 
            this.ID_lab_Famiglia.AutoSize = true;
            this.ID_lab_Famiglia.Location = new System.Drawing.Point(20, 68);
            this.ID_lab_Famiglia.Name = "ID_lab_Famiglia";
            this.ID_lab_Famiglia.Size = new System.Drawing.Size(133, 19);
            this.ID_lab_Famiglia.TabIndex = 3;
            this.ID_lab_Famiglia.Text = "Famiglia di prodotto:";
            this.ID_lab_Famiglia.UseCustomBackColor = true;
            // 
            // fam_ProdTableAdapter
            // 
            this.fam_ProdTableAdapter.ClearBeforeFill = true;
            // 
            // schedeTableAdapter
            // 
            this.schedeTableAdapter.ClearBeforeFill = true;
            // 
            // ID_timer
            // 
            this.ID_timer.Enabled = true;
            this.ID_timer.Tick += new System.EventHandler(this.ID_timer_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 701);
            this.Controls.Add(this.panel_ID);
            this.Controls.Add(this.panel_Main);
            this.Controls.Add(this.panel_Menu);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(23, 83, 23, 28);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica Factory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel_Menu.ResumeLayout(false);
            this.panel_ID.ResumeLayout(false);
            this.ID_pan_C.ResumeLayout(false);
            this.ID_pan_C.PerformLayout();
            this.ID_pan_P.ResumeLayout(false);
            this.ID_pan_P.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.schedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).EndInit();
            this.ID_pan_bottom.ResumeLayout(false);
            this.ID_pan_bottom.PerformLayout();
            this.ID_pan_Top.ResumeLayout(false);
            this.ID_pan_Top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel panel_Menu;
        private MetroFramework.Controls.MetroTile menu_btn_ID;
        private MetroFramework.Controls.MetroPanel panel_Main;
        private MetroFramework.Controls.MetroPanel panel_ID;
        private MetroFramework.Controls.MetroLabel titolo_ID;
        private MetroFramework.Controls.MetroPanel ID_pan_Top;
        private MetroFramework.Controls.MetroLabel ID_lab_Famiglia;
        private DB_FactoryDataSet dB_FactoryDataSet;
        private System.Windows.Forms.BindingSource famProdBindingSource;
        private DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter fam_ProdTableAdapter;
        private MetroFramework.Controls.MetroPanel menu_spacer_01;
        private MetroFramework.Controls.MetroPanel ID_pan_C;
        private MetroFramework.Controls.MetroLabel ID_lab_Controller;
        private MetroFramework.Controls.MetroPanel ID_pan_P;
        private MetroFramework.Controls.MetroLabel ID_lab_Palmare;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.BindingSource schedeBindingSource;
        private DB_FactoryDataSetTableAdapters.SchedeTableAdapter schedeTableAdapter;
        private System.Windows.Forms.ComboBox ID_combo_Famiglia;
        private System.Windows.Forms.ComboBox ID_combo_Scheda_P;
        private System.Windows.Forms.Label ID_lab_scheda_des;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroToggle ID_toggle_Fungo;
        private MetroFramework.Controls.MetroToggle ID_toggle_Torcia;
        private MetroFramework.Controls.MetroToggle ID_toggle_Vibracall;
        private MetroFramework.Controls.MetroToggle ID_toggle_Buzzer;
        private MetroFramework.Controls.MetroToggle ID_toggle_SP;
        private MetroFramework.Controls.MetroToggle ID_toggle_Accel;
        private MetroFramework.Controls.MetroToggle ID_toggle_Display;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroPanel ID_pan_bottom;
        private MetroFramework.Controls.MetroTextBox ID_Result;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroRadioButton ID_radio_868;
        private MetroFramework.Controls.MetroRadioButton ID_radio_433;
        private MetroFramework.Controls.MetroRadioButton ID_radio_915;
        private System.Windows.Forms.Timer ID_timer;
    }
}

