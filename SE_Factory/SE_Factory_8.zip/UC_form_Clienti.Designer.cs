﻿namespace SE_Factory
{
    partial class UC_form_Clienti
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.mastroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sOTTOCONTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARTITAIVADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cODICEFISCALEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rAGIONESOCIALEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cODICENOMINATIVODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNDIRIZZODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROCIVICODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fRAZIONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cAPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOMUNEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pROVINCIADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rEGIONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cODISONAZIONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nAZIONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cODICEPAGAMENTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aGENTEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fIDODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREFISSOTELEFONODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROTELEFONODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROVERDEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREFISSOFAXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROFAXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNDIRIZZOINTERNETDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMAILPECDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tIPOLOGIACLIENTEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lISTINODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sCONTO1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sCONTO2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sCONTO3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sCONTO4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pORTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sPEDIZIONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sMVANAGRAFICACLIENTIBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dB_FactoryDataSet = new SE_Factory.DB_FactoryDataSet();
            this.sM_V_ANAGRAFICA_CLIENTITableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SM_V_ANAGRAFICA_CLIENTITableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sMVANAGRAFICACLIENTIBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mastroDataGridViewTextBoxColumn,
            this.contoDataGridViewTextBoxColumn,
            this.sOTTOCONTODataGridViewTextBoxColumn,
            this.pARTITAIVADataGridViewTextBoxColumn,
            this.cODICEFISCALEDataGridViewTextBoxColumn,
            this.rAGIONESOCIALEDataGridViewTextBoxColumn,
            this.cODICENOMINATIVODataGridViewTextBoxColumn,
            this.iNDIRIZZODataGridViewTextBoxColumn,
            this.nUMEROCIVICODataGridViewTextBoxColumn,
            this.fRAZIONEDataGridViewTextBoxColumn,
            this.cAPDataGridViewTextBoxColumn,
            this.cOMUNEDataGridViewTextBoxColumn,
            this.pROVINCIADataGridViewTextBoxColumn,
            this.rEGIONEDataGridViewTextBoxColumn,
            this.cODISONAZIONEDataGridViewTextBoxColumn,
            this.nAZIONEDataGridViewTextBoxColumn,
            this.cODICEPAGAMENTODataGridViewTextBoxColumn,
            this.dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn,
            this.aGENTEDataGridViewTextBoxColumn,
            this.fIDODataGridViewTextBoxColumn,
            this.pREFISSOTELEFONODataGridViewTextBoxColumn,
            this.nUMEROTELEFONODataGridViewTextBoxColumn,
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn,
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn,
            this.nUMEROVERDEDataGridViewTextBoxColumn,
            this.pREFISSOFAXDataGridViewTextBoxColumn,
            this.nUMEROFAXDataGridViewTextBoxColumn,
            this.iNDIRIZZOINTERNETDataGridViewTextBoxColumn,
            this.eMailDataGridViewTextBoxColumn,
            this.eMAILPECDataGridViewTextBoxColumn,
            this.eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn,
            this.tIPOLOGIACLIENTEDataGridViewTextBoxColumn,
            this.cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn,
            this.lISTINODataGridViewTextBoxColumn,
            this.sCONTO1DataGridViewTextBoxColumn,
            this.sCONTO2DataGridViewTextBoxColumn,
            this.sCONTO3DataGridViewTextBoxColumn,
            this.sCONTO4DataGridViewTextBoxColumn,
            this.pORTODataGridViewTextBoxColumn,
            this.sPEDIZIONEDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.sMVANAGRAFICACLIENTIBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(816, 520);
            this.dataGridView1.TabIndex = 1;
            // 
            // mastroDataGridViewTextBoxColumn
            // 
            this.mastroDataGridViewTextBoxColumn.DataPropertyName = "Mastro";
            this.mastroDataGridViewTextBoxColumn.HeaderText = "Mastro";
            this.mastroDataGridViewTextBoxColumn.Name = "mastroDataGridViewTextBoxColumn";
            this.mastroDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // contoDataGridViewTextBoxColumn
            // 
            this.contoDataGridViewTextBoxColumn.DataPropertyName = "Conto";
            this.contoDataGridViewTextBoxColumn.HeaderText = "Conto";
            this.contoDataGridViewTextBoxColumn.Name = "contoDataGridViewTextBoxColumn";
            this.contoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sOTTOCONTODataGridViewTextBoxColumn
            // 
            this.sOTTOCONTODataGridViewTextBoxColumn.DataPropertyName = "SOTTOCONTO";
            this.sOTTOCONTODataGridViewTextBoxColumn.HeaderText = "SOTTOCONTO";
            this.sOTTOCONTODataGridViewTextBoxColumn.Name = "sOTTOCONTODataGridViewTextBoxColumn";
            this.sOTTOCONTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pARTITAIVADataGridViewTextBoxColumn
            // 
            this.pARTITAIVADataGridViewTextBoxColumn.DataPropertyName = "PARTITA_IVA";
            this.pARTITAIVADataGridViewTextBoxColumn.HeaderText = "PARTITA_IVA";
            this.pARTITAIVADataGridViewTextBoxColumn.Name = "pARTITAIVADataGridViewTextBoxColumn";
            this.pARTITAIVADataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cODICEFISCALEDataGridViewTextBoxColumn
            // 
            this.cODICEFISCALEDataGridViewTextBoxColumn.DataPropertyName = "CODICE_FISCALE";
            this.cODICEFISCALEDataGridViewTextBoxColumn.HeaderText = "CODICE_FISCALE";
            this.cODICEFISCALEDataGridViewTextBoxColumn.Name = "cODICEFISCALEDataGridViewTextBoxColumn";
            this.cODICEFISCALEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rAGIONESOCIALEDataGridViewTextBoxColumn
            // 
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.DataPropertyName = "RAGIONESOCIALE";
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.HeaderText = "RAGIONESOCIALE";
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.Name = "rAGIONESOCIALEDataGridViewTextBoxColumn";
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cODICENOMINATIVODataGridViewTextBoxColumn
            // 
            this.cODICENOMINATIVODataGridViewTextBoxColumn.DataPropertyName = "CODICE_NOMINATIVO";
            this.cODICENOMINATIVODataGridViewTextBoxColumn.HeaderText = "CODICE_NOMINATIVO";
            this.cODICENOMINATIVODataGridViewTextBoxColumn.Name = "cODICENOMINATIVODataGridViewTextBoxColumn";
            this.cODICENOMINATIVODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // iNDIRIZZODataGridViewTextBoxColumn
            // 
            this.iNDIRIZZODataGridViewTextBoxColumn.DataPropertyName = "INDIRIZZO";
            this.iNDIRIZZODataGridViewTextBoxColumn.HeaderText = "INDIRIZZO";
            this.iNDIRIZZODataGridViewTextBoxColumn.Name = "iNDIRIZZODataGridViewTextBoxColumn";
            this.iNDIRIZZODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nUMEROCIVICODataGridViewTextBoxColumn
            // 
            this.nUMEROCIVICODataGridViewTextBoxColumn.DataPropertyName = "NUMERO_CIVICO";
            this.nUMEROCIVICODataGridViewTextBoxColumn.HeaderText = "NUMERO_CIVICO";
            this.nUMEROCIVICODataGridViewTextBoxColumn.Name = "nUMEROCIVICODataGridViewTextBoxColumn";
            this.nUMEROCIVICODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fRAZIONEDataGridViewTextBoxColumn
            // 
            this.fRAZIONEDataGridViewTextBoxColumn.DataPropertyName = "FRAZIONE";
            this.fRAZIONEDataGridViewTextBoxColumn.HeaderText = "FRAZIONE";
            this.fRAZIONEDataGridViewTextBoxColumn.Name = "fRAZIONEDataGridViewTextBoxColumn";
            this.fRAZIONEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cAPDataGridViewTextBoxColumn
            // 
            this.cAPDataGridViewTextBoxColumn.DataPropertyName = "CAP";
            this.cAPDataGridViewTextBoxColumn.HeaderText = "CAP";
            this.cAPDataGridViewTextBoxColumn.Name = "cAPDataGridViewTextBoxColumn";
            this.cAPDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cOMUNEDataGridViewTextBoxColumn
            // 
            this.cOMUNEDataGridViewTextBoxColumn.DataPropertyName = "COMUNE";
            this.cOMUNEDataGridViewTextBoxColumn.HeaderText = "COMUNE";
            this.cOMUNEDataGridViewTextBoxColumn.Name = "cOMUNEDataGridViewTextBoxColumn";
            this.cOMUNEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pROVINCIADataGridViewTextBoxColumn
            // 
            this.pROVINCIADataGridViewTextBoxColumn.DataPropertyName = "PROVINCIA";
            this.pROVINCIADataGridViewTextBoxColumn.HeaderText = "PROVINCIA";
            this.pROVINCIADataGridViewTextBoxColumn.Name = "pROVINCIADataGridViewTextBoxColumn";
            this.pROVINCIADataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rEGIONEDataGridViewTextBoxColumn
            // 
            this.rEGIONEDataGridViewTextBoxColumn.DataPropertyName = "REGIONE";
            this.rEGIONEDataGridViewTextBoxColumn.HeaderText = "REGIONE";
            this.rEGIONEDataGridViewTextBoxColumn.Name = "rEGIONEDataGridViewTextBoxColumn";
            this.rEGIONEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cODISONAZIONEDataGridViewTextBoxColumn
            // 
            this.cODISONAZIONEDataGridViewTextBoxColumn.DataPropertyName = "COD_ISO_NAZIONE";
            this.cODISONAZIONEDataGridViewTextBoxColumn.HeaderText = "COD_ISO_NAZIONE";
            this.cODISONAZIONEDataGridViewTextBoxColumn.Name = "cODISONAZIONEDataGridViewTextBoxColumn";
            this.cODISONAZIONEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nAZIONEDataGridViewTextBoxColumn
            // 
            this.nAZIONEDataGridViewTextBoxColumn.DataPropertyName = "NAZIONE";
            this.nAZIONEDataGridViewTextBoxColumn.HeaderText = "NAZIONE";
            this.nAZIONEDataGridViewTextBoxColumn.Name = "nAZIONEDataGridViewTextBoxColumn";
            this.nAZIONEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cODICEPAGAMENTODataGridViewTextBoxColumn
            // 
            this.cODICEPAGAMENTODataGridViewTextBoxColumn.DataPropertyName = "CODICE_PAGAMENTO";
            this.cODICEPAGAMENTODataGridViewTextBoxColumn.HeaderText = "CODICE_PAGAMENTO";
            this.cODICEPAGAMENTODataGridViewTextBoxColumn.Name = "cODICEPAGAMENTODataGridViewTextBoxColumn";
            this.cODICEPAGAMENTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn
            // 
            this.dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn.DataPropertyName = "DESCRIZIONE_PAGAMENTO";
            this.dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn.HeaderText = "DESCRIZIONE_PAGAMENTO";
            this.dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn.Name = "dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn";
            this.dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aGENTEDataGridViewTextBoxColumn
            // 
            this.aGENTEDataGridViewTextBoxColumn.DataPropertyName = "AGENTE";
            this.aGENTEDataGridViewTextBoxColumn.HeaderText = "AGENTE";
            this.aGENTEDataGridViewTextBoxColumn.Name = "aGENTEDataGridViewTextBoxColumn";
            this.aGENTEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fIDODataGridViewTextBoxColumn
            // 
            this.fIDODataGridViewTextBoxColumn.DataPropertyName = "FIDO";
            this.fIDODataGridViewTextBoxColumn.HeaderText = "FIDO";
            this.fIDODataGridViewTextBoxColumn.Name = "fIDODataGridViewTextBoxColumn";
            this.fIDODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pREFISSOTELEFONODataGridViewTextBoxColumn
            // 
            this.pREFISSOTELEFONODataGridViewTextBoxColumn.DataPropertyName = "PREFISSO_TELEFONO";
            this.pREFISSOTELEFONODataGridViewTextBoxColumn.HeaderText = "PREFISSO_TELEFONO";
            this.pREFISSOTELEFONODataGridViewTextBoxColumn.Name = "pREFISSOTELEFONODataGridViewTextBoxColumn";
            this.pREFISSOTELEFONODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nUMEROTELEFONODataGridViewTextBoxColumn
            // 
            this.nUMEROTELEFONODataGridViewTextBoxColumn.DataPropertyName = "NUMERO_TELEFONO";
            this.nUMEROTELEFONODataGridViewTextBoxColumn.HeaderText = "NUMERO_TELEFONO";
            this.nUMEROTELEFONODataGridViewTextBoxColumn.Name = "nUMEROTELEFONODataGridViewTextBoxColumn";
            this.nUMEROTELEFONODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn
            // 
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.DataPropertyName = "PREFISSO_TELEFONO_AGGIUNTIVO";
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.HeaderText = "PREFISSO_TELEFONO_AGGIUNTIVO";
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.Name = "pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn";
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn
            // 
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.DataPropertyName = "NUMERO_TELEFONO_AGGIUNTIVO";
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.HeaderText = "NUMERO_TELEFONO_AGGIUNTIVO";
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.Name = "nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn";
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nUMEROVERDEDataGridViewTextBoxColumn
            // 
            this.nUMEROVERDEDataGridViewTextBoxColumn.DataPropertyName = "NUMERO_VERDE";
            this.nUMEROVERDEDataGridViewTextBoxColumn.HeaderText = "NUMERO_VERDE";
            this.nUMEROVERDEDataGridViewTextBoxColumn.Name = "nUMEROVERDEDataGridViewTextBoxColumn";
            this.nUMEROVERDEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pREFISSOFAXDataGridViewTextBoxColumn
            // 
            this.pREFISSOFAXDataGridViewTextBoxColumn.DataPropertyName = "PREFISSO_FAX";
            this.pREFISSOFAXDataGridViewTextBoxColumn.HeaderText = "PREFISSO_FAX";
            this.pREFISSOFAXDataGridViewTextBoxColumn.Name = "pREFISSOFAXDataGridViewTextBoxColumn";
            this.pREFISSOFAXDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nUMEROFAXDataGridViewTextBoxColumn
            // 
            this.nUMEROFAXDataGridViewTextBoxColumn.DataPropertyName = "NUMERO_FAX";
            this.nUMEROFAXDataGridViewTextBoxColumn.HeaderText = "NUMERO_FAX";
            this.nUMEROFAXDataGridViewTextBoxColumn.Name = "nUMEROFAXDataGridViewTextBoxColumn";
            this.nUMEROFAXDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // iNDIRIZZOINTERNETDataGridViewTextBoxColumn
            // 
            this.iNDIRIZZOINTERNETDataGridViewTextBoxColumn.DataPropertyName = "INDIRIZZO_INTERNET";
            this.iNDIRIZZOINTERNETDataGridViewTextBoxColumn.HeaderText = "INDIRIZZO_INTERNET";
            this.iNDIRIZZOINTERNETDataGridViewTextBoxColumn.Name = "iNDIRIZZOINTERNETDataGridViewTextBoxColumn";
            this.iNDIRIZZOINTERNETDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // eMailDataGridViewTextBoxColumn
            // 
            this.eMailDataGridViewTextBoxColumn.DataPropertyName = "EMail";
            this.eMailDataGridViewTextBoxColumn.HeaderText = "EMail";
            this.eMailDataGridViewTextBoxColumn.Name = "eMailDataGridViewTextBoxColumn";
            this.eMailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // eMAILPECDataGridViewTextBoxColumn
            // 
            this.eMAILPECDataGridViewTextBoxColumn.DataPropertyName = "EMAIL_PEC";
            this.eMAILPECDataGridViewTextBoxColumn.HeaderText = "EMAIL_PEC";
            this.eMAILPECDataGridViewTextBoxColumn.Name = "eMAILPECDataGridViewTextBoxColumn";
            this.eMAILPECDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn
            // 
            this.eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn.DataPropertyName = "EMAIL_PEC_CAMERA_COMMERCIO";
            this.eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn.HeaderText = "EMAIL_PEC_CAMERA_COMMERCIO";
            this.eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn.Name = "eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn";
            this.eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tIPOLOGIACLIENTEDataGridViewTextBoxColumn
            // 
            this.tIPOLOGIACLIENTEDataGridViewTextBoxColumn.DataPropertyName = "TIPOLOGIA_CLIENTE";
            this.tIPOLOGIACLIENTEDataGridViewTextBoxColumn.HeaderText = "TIPOLOGIA_CLIENTE";
            this.tIPOLOGIACLIENTEDataGridViewTextBoxColumn.Name = "tIPOLOGIACLIENTEDataGridViewTextBoxColumn";
            this.tIPOLOGIACLIENTEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn
            // 
            this.cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn.DataPropertyName = "CATEGORIA_ECONOMICA_CLIENTE";
            this.cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn.HeaderText = "CATEGORIA_ECONOMICA_CLIENTE";
            this.cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn.Name = "cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn";
            this.cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lISTINODataGridViewTextBoxColumn
            // 
            this.lISTINODataGridViewTextBoxColumn.DataPropertyName = "LISTINO";
            this.lISTINODataGridViewTextBoxColumn.HeaderText = "LISTINO";
            this.lISTINODataGridViewTextBoxColumn.Name = "lISTINODataGridViewTextBoxColumn";
            this.lISTINODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sCONTO1DataGridViewTextBoxColumn
            // 
            this.sCONTO1DataGridViewTextBoxColumn.DataPropertyName = "SCONTO1";
            this.sCONTO1DataGridViewTextBoxColumn.HeaderText = "SCONTO1";
            this.sCONTO1DataGridViewTextBoxColumn.Name = "sCONTO1DataGridViewTextBoxColumn";
            this.sCONTO1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sCONTO2DataGridViewTextBoxColumn
            // 
            this.sCONTO2DataGridViewTextBoxColumn.DataPropertyName = "SCONTO2";
            this.sCONTO2DataGridViewTextBoxColumn.HeaderText = "SCONTO2";
            this.sCONTO2DataGridViewTextBoxColumn.Name = "sCONTO2DataGridViewTextBoxColumn";
            this.sCONTO2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sCONTO3DataGridViewTextBoxColumn
            // 
            this.sCONTO3DataGridViewTextBoxColumn.DataPropertyName = "SCONTO3";
            this.sCONTO3DataGridViewTextBoxColumn.HeaderText = "SCONTO3";
            this.sCONTO3DataGridViewTextBoxColumn.Name = "sCONTO3DataGridViewTextBoxColumn";
            this.sCONTO3DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sCONTO4DataGridViewTextBoxColumn
            // 
            this.sCONTO4DataGridViewTextBoxColumn.DataPropertyName = "SCONTO4";
            this.sCONTO4DataGridViewTextBoxColumn.HeaderText = "SCONTO4";
            this.sCONTO4DataGridViewTextBoxColumn.Name = "sCONTO4DataGridViewTextBoxColumn";
            this.sCONTO4DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pORTODataGridViewTextBoxColumn
            // 
            this.pORTODataGridViewTextBoxColumn.DataPropertyName = "PORTO";
            this.pORTODataGridViewTextBoxColumn.HeaderText = "PORTO";
            this.pORTODataGridViewTextBoxColumn.Name = "pORTODataGridViewTextBoxColumn";
            this.pORTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sPEDIZIONEDataGridViewTextBoxColumn
            // 
            this.sPEDIZIONEDataGridViewTextBoxColumn.DataPropertyName = "SPEDIZIONE";
            this.sPEDIZIONEDataGridViewTextBoxColumn.HeaderText = "SPEDIZIONE";
            this.sPEDIZIONEDataGridViewTextBoxColumn.Name = "sPEDIZIONEDataGridViewTextBoxColumn";
            this.sPEDIZIONEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sMVANAGRAFICACLIENTIBindingSource
            // 
            this.sMVANAGRAFICACLIENTIBindingSource.DataMember = "SM_V_ANAGRAFICA_CLIENTI";
            this.sMVANAGRAFICACLIENTIBindingSource.DataSource = this.dB_FactoryDataSet;
            // 
            // dB_FactoryDataSet
            // 
            this.dB_FactoryDataSet.DataSetName = "DB_FactoryDataSet";
            this.dB_FactoryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sM_V_ANAGRAFICA_CLIENTITableAdapter
            // 
            this.sM_V_ANAGRAFICA_CLIENTITableAdapter.ClearBeforeFill = true;
            // 
            // UC_form_Clienti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(5F, 11F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Segoe UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "UC_form_Clienti";
            this.Size = new System.Drawing.Size(816, 520);
            this.Load += new System.EventHandler(this.UC_form_Clienti_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sMVANAGRAFICACLIENTIBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mastroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sOTTOCONTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARTITAIVADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cODICEFISCALEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rAGIONESOCIALEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cODICENOMINATIVODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNDIRIZZODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROCIVICODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fRAZIONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cAPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMUNEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pROVINCIADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rEGIONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cODISONAZIONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nAZIONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cODICEPAGAMENTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dESCRIZIONEPAGAMENTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aGENTEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fIDODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREFISSOTELEFONODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROTELEFONODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROVERDEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREFISSOFAXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROFAXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNDIRIZZOINTERNETDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMAILPECDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMAILPECCAMERACOMMERCIODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tIPOLOGIACLIENTEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cATEGORIAECONOMICACLIENTEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lISTINODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sCONTO1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sCONTO2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sCONTO3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sCONTO4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pORTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sPEDIZIONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sMVANAGRAFICACLIENTIBindingSource;
        private DB_FactoryDataSet dB_FactoryDataSet;
        private DB_FactoryDataSetTableAdapters.SM_V_ANAGRAFICA_CLIENTITableAdapter sM_V_ANAGRAFICA_CLIENTITableAdapter;
    }
}
