﻿namespace SE_Factory
{


    partial class DB_FactoryDataSet
    {
        partial class xls_SerialsDataTable
        {
        }

        partial class JLabelDataTable
        {
        }

        partial class SoftwareDataTable
        {
        }
    }
}

namespace SE_Factory.DB_FactoryDataSetTableAdapters {
    
    
    public partial class SoftwareTableAdapter {
    }
}
