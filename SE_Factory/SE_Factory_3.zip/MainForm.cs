﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace SE_Factory
{
    public partial class MainForm : MetroForm
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            panel_Application.Visible = false;
        }

        private void menu_btn_ID_Click(object sender, EventArgs e)
        {
            ID_uc_form frm_child = new ID_uc_form();
            //frm_child.FormBorderStyle = FormBorderStyle.None;
            //frm_child.TopLevel = false;
            frm_child.AutoSize = true;
            frm_child.Dock = DockStyle.Fill;

            //frm_child.WindowState = FormWindowState.Maximized;

            frm_child.Visible = true;

            //this.Controls.Add(panel_ID);
            panel_Application.Controls.Add(frm_child);
            panel_Application.Dock = DockStyle.Fill;
            frm_child.Show();

            panel_Menu.Visible = false;
            panel_Application.Dock = DockStyle.Fill;
            panel_Application.Visible = true;
        }
    }
}
