﻿namespace SE_Factory
{
    partial class UC_form_Sw
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_form_Sw));
            this.pan_SW_C = new MetroFramework.Controls.MetroPanel();
            this.C_sch_image = new System.Windows.Forms.PictureBox();
            this.lab_Des_Scheda_C = new MetroFramework.Controls.MetroLabel();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.ID_radio_868_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_433_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_915_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_toggle_Prop = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_CanBus = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_AntExt = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_GuidaLuce = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_TastEmerg = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_PlugPLE = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_PlugExp = new MetroFramework.Controls.MetroToggle();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.famProdSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.famProdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dB_FactoryDataSet = new SE_Factory.DB_FactoryDataSet();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.pan_SW_P = new MetroFramework.Controls.MetroPanel();
            this.pan_P_Dx = new MetroFramework.Controls.MetroPanel();
            this.pan_P_Dx_Funzionamento = new MetroFramework.Controls.MetroPanel();
            this.funz_fill = new MetroFramework.Controls.MetroPanel();
            this.richtb_Funzioni = new System.Windows.Forms.RichTextBox();
            this.funz_top = new MetroFramework.Controls.MetroPanel();
            this.metroLabel32 = new MetroFramework.Controls.MetroLabel();
            this.pan_P_Dx_revisioni = new MetroFramework.Controls.MetroPanel();
            this.rev_fill = new MetroFramework.Controls.MetroPanel();
            this.richtb_Revisioni = new System.Windows.Forms.RichTextBox();
            this.rev_top = new MetroFramework.Controls.MetroPanel();
            this.metroLabel33 = new MetroFramework.Controls.MetroLabel();
            this.pan_P_Sx = new MetroFramework.Controls.MetroPanel();
            this.pan_P_middle = new MetroFramework.Controls.MetroPanel();
            this.tb_Max_Pairable = new System.Windows.Forms.TextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.ID_toggle_ShiftPage = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Torch = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Vibracall = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Buzzer = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_SP = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Accel = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Backlight = new MetroFramework.Controls.MetroToggle();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.ID_radio_868_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_433_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_915_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_toggle_Fungo = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Torcia = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Vibracall = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Buzzer = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_SP = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Accel = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Display = new MetroFramework.Controls.MetroToggle();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.pan_P_top = new MetroFramework.Controls.MetroPanel();
            this.ID_lab_Palmare = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.grid_SchedeCompatibili = new MetroFramework.Controls.MetroGrid();
            this.prodSch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodDescrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SchedaCompatibile = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.grid_SW_codificati = new MetroFramework.Controls.MetroGrid();
            this.sWCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SW_Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famProdSoftwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pan_SW_Codifica = new MetroFramework.Controls.MetroPanel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.SW_lab_codice_SW = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.tbox_Sw_name = new System.Windows.Forms.MaskedTextBox();
            this.tbox_Sw_version = new System.Windows.Forms.MaskedTextBox();
            this.tbox_Sw_frequency = new System.Windows.Forms.MaskedTextBox();
            this.SW_lab_Famiglia = new MetroFramework.Controls.MetroLabel();
            this.ID_combo_Famiglia = new System.Windows.Forms.ComboBox();
            this.pan_SW_Titolo = new MetroFramework.Controls.MetroPanel();
            this.titolo_ID = new MetroFramework.Controls.MetroLabel();
            this.fam_ProdTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter();
            this.schedeTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SchedeTableAdapter();
            this.softwareTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SoftwareTableAdapter();
            this.metroContextMenu1 = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.SW_Layout = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaCodiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_radio_Filo_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_None_P = new MetroFramework.Controls.MetroRadioButton();
            this.creaPdfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_SW_C.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.C_sch_image)).BeginInit();
            this.metroPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).BeginInit();
            this.pan_SW_P.SuspendLayout();
            this.pan_P_Dx.SuspendLayout();
            this.pan_P_Dx_Funzionamento.SuspendLayout();
            this.funz_fill.SuspendLayout();
            this.funz_top.SuspendLayout();
            this.pan_P_Dx_revisioni.SuspendLayout();
            this.rev_fill.SuspendLayout();
            this.rev_top.SuspendLayout();
            this.pan_P_Sx.SuspendLayout();
            this.pan_P_middle.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            this.pan_P_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SchedeCompatibili)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SW_codificati)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSoftwareBindingSource)).BeginInit();
            this.pan_SW_Codifica.SuspendLayout();
            this.pan_SW_Titolo.SuspendLayout();
            this.SW_Layout.SuspendLayout();
            this.pan_Menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.SuspendLayout();
            // 
            // pan_SW_C
            // 
            this.pan_SW_C.BackColor = System.Drawing.SystemColors.Window;
            this.SW_Layout.SetColumnSpan(this.pan_SW_C, 10);
            this.pan_SW_C.Controls.Add(this.C_sch_image);
            this.pan_SW_C.Controls.Add(this.lab_Des_Scheda_C);
            this.pan_SW_C.Controls.Add(this.metroPanel3);
            this.pan_SW_C.Controls.Add(this.ID_toggle_Prop);
            this.pan_SW_C.Controls.Add(this.ID_toggle_CanBus);
            this.pan_SW_C.Controls.Add(this.ID_toggle_AntExt);
            this.pan_SW_C.Controls.Add(this.ID_toggle_GuidaLuce);
            this.pan_SW_C.Controls.Add(this.ID_toggle_TastEmerg);
            this.pan_SW_C.Controls.Add(this.ID_toggle_PlugPLE);
            this.pan_SW_C.Controls.Add(this.ID_toggle_PlugExp);
            this.pan_SW_C.Controls.Add(this.metroLabel11);
            this.pan_SW_C.Controls.Add(this.metroLabel12);
            this.pan_SW_C.Controls.Add(this.metroLabel13);
            this.pan_SW_C.Controls.Add(this.metroLabel14);
            this.pan_SW_C.Controls.Add(this.metroLabel15);
            this.pan_SW_C.Controls.Add(this.metroLabel16);
            this.pan_SW_C.Controls.Add(this.metroLabel17);
            this.pan_SW_C.Controls.Add(this.metroLabel18);
            this.pan_SW_C.Controls.Add(this.label1);
            this.pan_SW_C.Controls.Add(this.comboBox1);
            this.pan_SW_C.Controls.Add(this.metroLabel19);
            this.pan_SW_C.Controls.Add(this.metroLabel20);
            this.pan_SW_C.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_C.ForeColor = System.Drawing.SystemColors.Control;
            this.pan_SW_C.HorizontalScrollbarBarColor = true;
            this.pan_SW_C.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_C.HorizontalScrollbarSize = 10;
            this.pan_SW_C.Location = new System.Drawing.Point(3, 626);
            this.pan_SW_C.Name = "pan_SW_C";
            this.pan_SW_C.Size = new System.Drawing.Size(1120, 415);
            this.pan_SW_C.TabIndex = 8;
            this.pan_SW_C.UseCustomBackColor = true;
            this.pan_SW_C.VerticalScrollbarBarColor = true;
            this.pan_SW_C.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_C.VerticalScrollbarSize = 10;
            this.pan_SW_C.Visible = false;
            // 
            // C_sch_image
            // 
            this.C_sch_image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.C_sch_image.Dock = System.Windows.Forms.DockStyle.Right;
            this.C_sch_image.Location = new System.Drawing.Point(720, 0);
            this.C_sch_image.Name = "C_sch_image";
            this.C_sch_image.Size = new System.Drawing.Size(400, 415);
            this.C_sch_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C_sch_image.TabIndex = 40;
            this.C_sch_image.TabStop = false;
            // 
            // lab_Des_Scheda_C
            // 
            this.lab_Des_Scheda_C.AutoSize = true;
            this.lab_Des_Scheda_C.Location = new System.Drawing.Point(360, 31);
            this.lab_Des_Scheda_C.Name = "lab_Des_Scheda_C";
            this.lab_Des_Scheda_C.Size = new System.Drawing.Size(88, 19);
            this.lab_Des_Scheda_C.TabIndex = 37;
            this.lab_Des_Scheda_C.Text = "metroLabel21";
            // 
            // metroPanel3
            // 
            this.metroPanel3.Controls.Add(this.ID_radio_868_C);
            this.metroPanel3.Controls.Add(this.ID_radio_433_C);
            this.metroPanel3.Controls.Add(this.ID_radio_915_C);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(150, 63);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(170, 20);
            this.metroPanel3.TabIndex = 36;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // ID_radio_868_C
            // 
            this.ID_radio_868_C.AutoSize = true;
            this.ID_radio_868_C.Location = new System.Drawing.Point(0, 0);
            this.ID_radio_868_C.Name = "ID_radio_868_C";
            this.ID_radio_868_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_868_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_868_C.TabIndex = 32;
            this.ID_radio_868_C.Text = "868";
            this.ID_radio_868_C.UseCustomBackColor = true;
            this.ID_radio_868_C.UseSelectable = true;
            this.ID_radio_868_C.UseStyleColors = true;
            // 
            // ID_radio_433_C
            // 
            this.ID_radio_433_C.AutoSize = true;
            this.ID_radio_433_C.Location = new System.Drawing.Point(120, 0);
            this.ID_radio_433_C.Name = "ID_radio_433_C";
            this.ID_radio_433_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_433_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_433_C.TabIndex = 34;
            this.ID_radio_433_C.Text = "433";
            this.ID_radio_433_C.UseCustomBackColor = true;
            this.ID_radio_433_C.UseSelectable = true;
            this.ID_radio_433_C.UseStyleColors = true;
            // 
            // ID_radio_915_C
            // 
            this.ID_radio_915_C.AutoSize = true;
            this.ID_radio_915_C.Location = new System.Drawing.Point(60, 0);
            this.ID_radio_915_C.Name = "ID_radio_915_C";
            this.ID_radio_915_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_915_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_915_C.TabIndex = 33;
            this.ID_radio_915_C.Text = "915";
            this.ID_radio_915_C.UseCustomBackColor = true;
            this.ID_radio_915_C.UseSelectable = true;
            this.ID_radio_915_C.UseStyleColors = true;
            // 
            // ID_toggle_Prop
            // 
            this.ID_toggle_Prop.AutoSize = true;
            this.ID_toggle_Prop.Location = new System.Drawing.Point(150, 270);
            this.ID_toggle_Prop.Name = "ID_toggle_Prop";
            this.ID_toggle_Prop.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Prop.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Prop.TabIndex = 28;
            this.ID_toggle_Prop.Text = "Off";
            this.ID_toggle_Prop.UseSelectable = true;
            // 
            // ID_toggle_CanBus
            // 
            this.ID_toggle_CanBus.AutoSize = true;
            this.ID_toggle_CanBus.Location = new System.Drawing.Point(150, 240);
            this.ID_toggle_CanBus.Name = "ID_toggle_CanBus";
            this.ID_toggle_CanBus.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_CanBus.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_CanBus.TabIndex = 27;
            this.ID_toggle_CanBus.Text = "Off";
            this.ID_toggle_CanBus.UseSelectable = true;
            // 
            // ID_toggle_AntExt
            // 
            this.ID_toggle_AntExt.AutoSize = true;
            this.ID_toggle_AntExt.Location = new System.Drawing.Point(150, 210);
            this.ID_toggle_AntExt.Name = "ID_toggle_AntExt";
            this.ID_toggle_AntExt.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_AntExt.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_AntExt.TabIndex = 26;
            this.ID_toggle_AntExt.Text = "Off";
            this.ID_toggle_AntExt.UseSelectable = true;
            // 
            // ID_toggle_GuidaLuce
            // 
            this.ID_toggle_GuidaLuce.AutoSize = true;
            this.ID_toggle_GuidaLuce.Location = new System.Drawing.Point(150, 180);
            this.ID_toggle_GuidaLuce.Name = "ID_toggle_GuidaLuce";
            this.ID_toggle_GuidaLuce.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_GuidaLuce.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_GuidaLuce.TabIndex = 25;
            this.ID_toggle_GuidaLuce.Text = "Off";
            this.ID_toggle_GuidaLuce.UseSelectable = true;
            // 
            // ID_toggle_TastEmerg
            // 
            this.ID_toggle_TastEmerg.AutoSize = true;
            this.ID_toggle_TastEmerg.Location = new System.Drawing.Point(150, 150);
            this.ID_toggle_TastEmerg.Name = "ID_toggle_TastEmerg";
            this.ID_toggle_TastEmerg.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_TastEmerg.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_TastEmerg.TabIndex = 24;
            this.ID_toggle_TastEmerg.Text = "Off";
            this.ID_toggle_TastEmerg.UseSelectable = true;
            // 
            // ID_toggle_PlugPLE
            // 
            this.ID_toggle_PlugPLE.AutoSize = true;
            this.ID_toggle_PlugPLE.Location = new System.Drawing.Point(150, 120);
            this.ID_toggle_PlugPLE.Name = "ID_toggle_PlugPLE";
            this.ID_toggle_PlugPLE.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_PlugPLE.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_PlugPLE.TabIndex = 23;
            this.ID_toggle_PlugPLE.Text = "Off";
            this.ID_toggle_PlugPLE.UseSelectable = true;
            // 
            // ID_toggle_PlugExp
            // 
            this.ID_toggle_PlugExp.AutoSize = true;
            this.ID_toggle_PlugExp.Checked = true;
            this.ID_toggle_PlugExp.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ID_toggle_PlugExp.Location = new System.Drawing.Point(150, 90);
            this.ID_toggle_PlugExp.Name = "ID_toggle_PlugExp";
            this.ID_toggle_PlugExp.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_PlugExp.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_PlugExp.TabIndex = 22;
            this.ID_toggle_PlugExp.Text = "On";
            this.ID_toggle_PlugExp.UseSelectable = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(5, 270);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(95, 19);
            this.metroLabel11.TabIndex = 20;
            this.metroLabel11.Text = "Proporzionale:";
            this.metroLabel11.UseCustomBackColor = true;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(5, 240);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(64, 19);
            this.metroLabel12.TabIndex = 19;
            this.metroLabel12.Text = "CAN Bus:";
            this.metroLabel12.UseCustomBackColor = true;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(5, 210);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(106, 19);
            this.metroLabel13.TabIndex = 18;
            this.metroLabel13.Text = "Antenna Esterna:";
            this.metroLabel13.UseCustomBackColor = true;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(5, 180);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(76, 19);
            this.metroLabel14.TabIndex = 17;
            this.metroLabel14.Text = "Guida Luce:";
            this.metroLabel14.UseCustomBackColor = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(5, 150);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(136, 19);
            this.metroLabel15.TabIndex = 16;
            this.metroLabel15.Text = "Tastiera d\'emergenza:";
            this.metroLabel15.UseCustomBackColor = true;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(5, 120);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(63, 19);
            this.metroLabel16.TabIndex = 15;
            this.metroLabel16.Text = "Plug PLE:";
            this.metroLabel16.UseCustomBackColor = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(5, 90);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(63, 19);
            this.metroLabel17.TabIndex = 14;
            this.metroLabel17.Text = "Plug Exp:";
            this.metroLabel17.UseCustomBackColor = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(5, 60);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(111, 19);
            this.metroLabel18.TabIndex = 13;
            this.metroLabel18.Text = "Frequenza Radio:";
            this.metroLabel18.UseCustomBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(160, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "label1";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.famProdSchedeBindingSource;
            this.comboBox1.DisplayMember = "Prod_Sch";
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 15;
            this.comboBox1.Location = new System.Drawing.Point(150, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 23);
            this.comboBox1.TabIndex = 11;
            // 
            // famProdSchedeBindingSource
            // 
            this.famProdSchedeBindingSource.DataMember = "Fam_Prod_Schede";
            this.famProdSchedeBindingSource.DataSource = this.famProdBindingSource;
            // 
            // famProdBindingSource
            // 
            this.famProdBindingSource.DataMember = "Fam_Prod";
            this.famProdBindingSource.DataSource = this.dB_FactoryDataSet;
            this.famProdBindingSource.CurrentChanged += new System.EventHandler(this.famProdBindingSource_CurrentChanged);
            // 
            // dB_FactoryDataSet
            // 
            this.dB_FactoryDataSet.DataSetName = "DB_FactoryDataSet";
            this.dB_FactoryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(5, 30);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(108, 19);
            this.metroLabel19.TabIndex = 9;
            this.metroLabel19.Text = "Scheda utilizzata:";
            this.metroLabel19.UseCustomBackColor = true;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel20.Location = new System.Drawing.Point(0, 0);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(90, 25);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel20.TabIndex = 7;
            this.metroLabel20.Text = "Controller";
            this.metroLabel20.UseCustomBackColor = true;
            this.metroLabel20.UseStyleColors = true;
            // 
            // pan_SW_P
            // 
            this.pan_SW_P.BackColor = System.Drawing.SystemColors.Window;
            this.SW_Layout.SetColumnSpan(this.pan_SW_P, 10);
            this.pan_SW_P.Controls.Add(this.pan_P_Dx);
            this.pan_SW_P.Controls.Add(this.pan_P_Sx);
            this.pan_SW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_P.ForeColor = System.Drawing.SystemColors.Control;
            this.pan_SW_P.HorizontalScrollbarBarColor = true;
            this.pan_SW_P.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_P.HorizontalScrollbarSize = 10;
            this.pan_SW_P.Location = new System.Drawing.Point(3, 205);
            this.pan_SW_P.Name = "pan_SW_P";
            this.pan_SW_P.Size = new System.Drawing.Size(1120, 415);
            this.pan_SW_P.TabIndex = 5;
            this.pan_SW_P.UseCustomBackColor = true;
            this.pan_SW_P.VerticalScrollbarBarColor = true;
            this.pan_SW_P.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_P.VerticalScrollbarSize = 10;
            this.pan_SW_P.Visible = false;
            // 
            // pan_P_Dx
            // 
            this.pan_P_Dx.BackColor = System.Drawing.Color.Linen;
            this.pan_P_Dx.Controls.Add(this.pan_P_Dx_Funzionamento);
            this.pan_P_Dx.Controls.Add(this.pan_P_Dx_revisioni);
            this.pan_P_Dx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_Dx.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx.HorizontalScrollbarSize = 10;
            this.pan_P_Dx.Location = new System.Drawing.Point(700, 0);
            this.pan_P_Dx.Name = "pan_P_Dx";
            this.pan_P_Dx.Size = new System.Drawing.Size(420, 415);
            this.pan_P_Dx.TabIndex = 54;
            this.pan_P_Dx.UseCustomBackColor = true;
            this.pan_P_Dx.VerticalScrollbarBarColor = true;
            this.pan_P_Dx.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx.VerticalScrollbarSize = 10;
            // 
            // pan_P_Dx_Funzionamento
            // 
            this.pan_P_Dx_Funzionamento.BackColor = System.Drawing.Color.Transparent;
            this.pan_P_Dx_Funzionamento.Controls.Add(this.funz_fill);
            this.pan_P_Dx_Funzionamento.Controls.Add(this.funz_top);
            this.pan_P_Dx_Funzionamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarSize = 10;
            this.pan_P_Dx_Funzionamento.Location = new System.Drawing.Point(0, 150);
            this.pan_P_Dx_Funzionamento.Name = "pan_P_Dx_Funzionamento";
            this.pan_P_Dx_Funzionamento.Size = new System.Drawing.Size(420, 265);
            this.pan_P_Dx_Funzionamento.TabIndex = 12;
            this.pan_P_Dx_Funzionamento.UseCustomBackColor = true;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarBarColor = true;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarSize = 10;
            // 
            // funz_fill
            // 
            this.funz_fill.BackColor = System.Drawing.Color.Linen;
            this.funz_fill.Controls.Add(this.richtb_Funzioni);
            this.funz_fill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.funz_fill.HorizontalScrollbarBarColor = true;
            this.funz_fill.HorizontalScrollbarHighlightOnWheel = false;
            this.funz_fill.HorizontalScrollbarSize = 10;
            this.funz_fill.Location = new System.Drawing.Point(0, 15);
            this.funz_fill.Name = "funz_fill";
            this.funz_fill.Size = new System.Drawing.Size(420, 250);
            this.funz_fill.TabIndex = 13;
            this.funz_fill.UseCustomBackColor = true;
            this.funz_fill.VerticalScrollbarBarColor = true;
            this.funz_fill.VerticalScrollbarHighlightOnWheel = false;
            this.funz_fill.VerticalScrollbarSize = 10;
            // 
            // richtb_Funzioni
            // 
            this.richtb_Funzioni.BackColor = System.Drawing.Color.Linen;
            this.richtb_Funzioni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richtb_Funzioni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richtb_Funzioni.Location = new System.Drawing.Point(0, 0);
            this.richtb_Funzioni.Name = "richtb_Funzioni";
            this.richtb_Funzioni.Size = new System.Drawing.Size(420, 250);
            this.richtb_Funzioni.TabIndex = 11;
            this.richtb_Funzioni.Text = "";
            // 
            // funz_top
            // 
            this.funz_top.BackColor = System.Drawing.Color.Linen;
            this.funz_top.Controls.Add(this.metroLabel32);
            this.funz_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.funz_top.HorizontalScrollbarBarColor = true;
            this.funz_top.HorizontalScrollbarHighlightOnWheel = false;
            this.funz_top.HorizontalScrollbarSize = 10;
            this.funz_top.Location = new System.Drawing.Point(0, 0);
            this.funz_top.Name = "funz_top";
            this.funz_top.Size = new System.Drawing.Size(420, 15);
            this.funz_top.TabIndex = 12;
            this.funz_top.UseCustomBackColor = true;
            this.funz_top.VerticalScrollbarBarColor = true;
            this.funz_top.VerticalScrollbarHighlightOnWheel = false;
            this.funz_top.VerticalScrollbarSize = 10;
            // 
            // metroLabel32
            // 
            this.metroLabel32.AutoSize = true;
            this.metroLabel32.Location = new System.Drawing.Point(0, 0);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(102, 19);
            this.metroLabel32.TabIndex = 10;
            this.metroLabel32.Text = "Funzionamento:";
            this.metroLabel32.UseCustomBackColor = true;
            // 
            // pan_P_Dx_revisioni
            // 
            this.pan_P_Dx_revisioni.BackColor = System.Drawing.Color.Transparent;
            this.pan_P_Dx_revisioni.Controls.Add(this.rev_fill);
            this.pan_P_Dx_revisioni.Controls.Add(this.rev_top);
            this.pan_P_Dx_revisioni.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_P_Dx_revisioni.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx_revisioni.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_revisioni.HorizontalScrollbarSize = 10;
            this.pan_P_Dx_revisioni.Location = new System.Drawing.Point(0, 0);
            this.pan_P_Dx_revisioni.Name = "pan_P_Dx_revisioni";
            this.pan_P_Dx_revisioni.Size = new System.Drawing.Size(420, 150);
            this.pan_P_Dx_revisioni.TabIndex = 11;
            this.pan_P_Dx_revisioni.UseCustomBackColor = true;
            this.pan_P_Dx_revisioni.VerticalScrollbarBarColor = true;
            this.pan_P_Dx_revisioni.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_revisioni.VerticalScrollbarSize = 10;
            // 
            // rev_fill
            // 
            this.rev_fill.Controls.Add(this.richtb_Revisioni);
            this.rev_fill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rev_fill.HorizontalScrollbarBarColor = true;
            this.rev_fill.HorizontalScrollbarHighlightOnWheel = false;
            this.rev_fill.HorizontalScrollbarSize = 10;
            this.rev_fill.Location = new System.Drawing.Point(0, 20);
            this.rev_fill.Name = "rev_fill";
            this.rev_fill.Size = new System.Drawing.Size(420, 130);
            this.rev_fill.TabIndex = 13;
            this.rev_fill.VerticalScrollbarBarColor = true;
            this.rev_fill.VerticalScrollbarHighlightOnWheel = false;
            this.rev_fill.VerticalScrollbarSize = 10;
            // 
            // richtb_Revisioni
            // 
            this.richtb_Revisioni.BackColor = System.Drawing.Color.Linen;
            this.richtb_Revisioni.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.richtb_Revisioni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richtb_Revisioni.Location = new System.Drawing.Point(0, 0);
            this.richtb_Revisioni.Name = "richtb_Revisioni";
            this.richtb_Revisioni.Size = new System.Drawing.Size(420, 130);
            this.richtb_Revisioni.TabIndex = 11;
            this.richtb_Revisioni.Text = "";
            // 
            // rev_top
            // 
            this.rev_top.BackColor = System.Drawing.Color.Linen;
            this.rev_top.Controls.Add(this.metroLabel33);
            this.rev_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.rev_top.HorizontalScrollbarBarColor = true;
            this.rev_top.HorizontalScrollbarHighlightOnWheel = false;
            this.rev_top.HorizontalScrollbarSize = 10;
            this.rev_top.Location = new System.Drawing.Point(0, 0);
            this.rev_top.Name = "rev_top";
            this.rev_top.Size = new System.Drawing.Size(420, 20);
            this.rev_top.TabIndex = 12;
            this.rev_top.UseCustomBackColor = true;
            this.rev_top.VerticalScrollbarBarColor = true;
            this.rev_top.VerticalScrollbarHighlightOnWheel = false;
            this.rev_top.VerticalScrollbarSize = 10;
            // 
            // metroLabel33
            // 
            this.metroLabel33.AutoSize = true;
            this.metroLabel33.Location = new System.Drawing.Point(0, 0);
            this.metroLabel33.Name = "metroLabel33";
            this.metroLabel33.Size = new System.Drawing.Size(62, 19);
            this.metroLabel33.TabIndex = 10;
            this.metroLabel33.Text = "Revisioni:";
            this.metroLabel33.UseCustomBackColor = true;
            // 
            // pan_P_Sx
            // 
            this.pan_P_Sx.Controls.Add(this.pan_P_middle);
            this.pan_P_Sx.Controls.Add(this.pan_P_top);
            this.pan_P_Sx.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_P_Sx.HorizontalScrollbarBarColor = true;
            this.pan_P_Sx.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Sx.HorizontalScrollbarSize = 10;
            this.pan_P_Sx.Location = new System.Drawing.Point(0, 0);
            this.pan_P_Sx.Name = "pan_P_Sx";
            this.pan_P_Sx.Size = new System.Drawing.Size(700, 415);
            this.pan_P_Sx.TabIndex = 53;
            this.pan_P_Sx.VerticalScrollbarBarColor = true;
            this.pan_P_Sx.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Sx.VerticalScrollbarSize = 10;
            // 
            // pan_P_middle
            // 
            this.pan_P_middle.Controls.Add(this.tb_Max_Pairable);
            this.pan_P_middle.Controls.Add(this.metroButton1);
            this.pan_P_middle.Controls.Add(this.metroLabel30);
            this.pan_P_middle.Controls.Add(this.ID_toggle_ShiftPage);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Torch);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Vibracall);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Buzzer);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_SP);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Accel);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Backlight);
            this.pan_P_middle.Controls.Add(this.metroLabel23);
            this.pan_P_middle.Controls.Add(this.metroLabel24);
            this.pan_P_middle.Controls.Add(this.metroLabel25);
            this.pan_P_middle.Controls.Add(this.metroLabel26);
            this.pan_P_middle.Controls.Add(this.metroLabel27);
            this.pan_P_middle.Controls.Add(this.metroLabel28);
            this.pan_P_middle.Controls.Add(this.metroLabel29);
            this.pan_P_middle.Controls.Add(this.metroPanel1);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Fungo);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Torcia);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Vibracall);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Buzzer);
            this.pan_P_middle.Controls.Add(this.ID_toggle_SP);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Accel);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Display);
            this.pan_P_middle.Controls.Add(this.metroLabel9);
            this.pan_P_middle.Controls.Add(this.metroLabel8);
            this.pan_P_middle.Controls.Add(this.metroLabel7);
            this.pan_P_middle.Controls.Add(this.metroLabel6);
            this.pan_P_middle.Controls.Add(this.metroLabel5);
            this.pan_P_middle.Controls.Add(this.metroLabel4);
            this.pan_P_middle.Controls.Add(this.metroLabel3);
            this.pan_P_middle.Controls.Add(this.metroLabel2);
            this.pan_P_middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_middle.HorizontalScrollbarBarColor = true;
            this.pan_P_middle.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_middle.HorizontalScrollbarSize = 10;
            this.pan_P_middle.Location = new System.Drawing.Point(0, 160);
            this.pan_P_middle.Name = "pan_P_middle";
            this.pan_P_middle.Size = new System.Drawing.Size(700, 255);
            this.pan_P_middle.TabIndex = 42;
            this.pan_P_middle.VerticalScrollbarBarColor = true;
            this.pan_P_middle.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_middle.VerticalScrollbarSize = 10;
            // 
            // tb_Max_Pairable
            // 
            this.tb_Max_Pairable.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Max_Pairable.Location = new System.Drawing.Point(424, 188);
            this.tb_Max_Pairable.Name = "tb_Max_Pairable";
            this.tb_Max_Pairable.Size = new System.Drawing.Size(52, 23);
            this.tb_Max_Pairable.TabIndex = 54;
            this.tb_Max_Pairable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(559, 213);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 53;
            this.metroButton1.Text = "metroButton1";
            this.metroButton1.UseSelectable = true;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.Location = new System.Drawing.Point(251, 185);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(139, 19);
            this.metroLabel30.TabIndex = 51;
            this.metroLabel30.Text = "MAX pairable devices:";
            this.metroLabel30.UseCustomBackColor = true;
            // 
            // ID_toggle_ShiftPage
            // 
            this.ID_toggle_ShiftPage.AutoSize = true;
            this.ID_toggle_ShiftPage.Location = new System.Drawing.Point(396, 165);
            this.ID_toggle_ShiftPage.Name = "ID_toggle_ShiftPage";
            this.ID_toggle_ShiftPage.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_ShiftPage.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_ShiftPage.TabIndex = 50;
            this.ID_toggle_ShiftPage.Text = "Off";
            this.ID_toggle_ShiftPage.UseSelectable = true;
            // 
            // ID_toggle_use_Torch
            // 
            this.ID_toggle_use_Torch.AutoSize = true;
            this.ID_toggle_use_Torch.Location = new System.Drawing.Point(396, 125);
            this.ID_toggle_use_Torch.Name = "ID_toggle_use_Torch";
            this.ID_toggle_use_Torch.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Torch.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Torch.TabIndex = 49;
            this.ID_toggle_use_Torch.Text = "Off";
            this.ID_toggle_use_Torch.UseSelectable = true;
            // 
            // ID_toggle_use_Vibracall
            // 
            this.ID_toggle_use_Vibracall.AutoSize = true;
            this.ID_toggle_use_Vibracall.Location = new System.Drawing.Point(396, 105);
            this.ID_toggle_use_Vibracall.Name = "ID_toggle_use_Vibracall";
            this.ID_toggle_use_Vibracall.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Vibracall.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Vibracall.TabIndex = 48;
            this.ID_toggle_use_Vibracall.Text = "Off";
            this.ID_toggle_use_Vibracall.UseSelectable = true;
            // 
            // ID_toggle_use_Buzzer
            // 
            this.ID_toggle_use_Buzzer.AutoSize = true;
            this.ID_toggle_use_Buzzer.Location = new System.Drawing.Point(396, 85);
            this.ID_toggle_use_Buzzer.Name = "ID_toggle_use_Buzzer";
            this.ID_toggle_use_Buzzer.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Buzzer.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Buzzer.TabIndex = 47;
            this.ID_toggle_use_Buzzer.Text = "Off";
            this.ID_toggle_use_Buzzer.UseSelectable = true;
            // 
            // ID_toggle_use_SP
            // 
            this.ID_toggle_use_SP.AutoSize = true;
            this.ID_toggle_use_SP.Location = new System.Drawing.Point(396, 65);
            this.ID_toggle_use_SP.Name = "ID_toggle_use_SP";
            this.ID_toggle_use_SP.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_SP.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_SP.TabIndex = 46;
            this.ID_toggle_use_SP.Text = "Off";
            this.ID_toggle_use_SP.UseSelectable = true;
            // 
            // ID_toggle_use_Accel
            // 
            this.ID_toggle_use_Accel.AutoSize = true;
            this.ID_toggle_use_Accel.Location = new System.Drawing.Point(396, 45);
            this.ID_toggle_use_Accel.Name = "ID_toggle_use_Accel";
            this.ID_toggle_use_Accel.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Accel.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Accel.TabIndex = 45;
            this.ID_toggle_use_Accel.Text = "Off";
            this.ID_toggle_use_Accel.UseSelectable = true;
            // 
            // ID_toggle_use_Backlight
            // 
            this.ID_toggle_use_Backlight.AutoSize = true;
            this.ID_toggle_use_Backlight.Location = new System.Drawing.Point(396, 25);
            this.ID_toggle_use_Backlight.Name = "ID_toggle_use_Backlight";
            this.ID_toggle_use_Backlight.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Backlight.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Backlight.TabIndex = 44;
            this.ID_toggle_use_Backlight.Text = "Off";
            this.ID_toggle_use_Backlight.UseSelectable = true;
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.Location = new System.Drawing.Point(251, 165);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(102, 19);
            this.metroLabel23.TabIndex = 43;
            this.metroLabel23.Text = "Cambio Pagina:";
            this.metroLabel23.UseCustomBackColor = true;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(251, 125);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(71, 19);
            this.metroLabel24.TabIndex = 42;
            this.metroLabel24.Text = "Usa Torcia:";
            this.metroLabel24.UseCustomBackColor = true;
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(251, 105);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(87, 19);
            this.metroLabel25.TabIndex = 41;
            this.metroLabel25.Text = "Usa Vibracall:";
            this.metroLabel25.UseCustomBackColor = true;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(251, 85);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(77, 19);
            this.metroLabel26.TabIndex = 40;
            this.metroLabel26.Text = "Usa Buzzer:";
            this.metroLabel26.UseCustomBackColor = true;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.Location = new System.Drawing.Point(251, 65);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(105, 19);
            this.metroLabel27.TabIndex = 39;
            this.metroLabel27.Text = "Usa Safety Point:";
            this.metroLabel27.UseCustomBackColor = true;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.Location = new System.Drawing.Point(251, 45);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(124, 19);
            this.metroLabel28.TabIndex = 38;
            this.metroLabel28.Text = "Usa Accelerometro:";
            this.metroLabel28.UseCustomBackColor = true;
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(251, 25);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(89, 19);
            this.metroLabel29.TabIndex = 37;
            this.metroLabel29.Text = "Use Backlight:";
            this.metroLabel29.UseCustomBackColor = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.ID_radio_None_P);
            this.metroPanel1.Controls.Add(this.ID_radio_Filo_P);
            this.metroPanel1.Controls.Add(this.ID_radio_868_P);
            this.metroPanel1.Controls.Add(this.ID_radio_433_P);
            this.metroPanel1.Controls.Add(this.ID_radio_915_P);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(150, 8);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(353, 16);
            this.metroPanel1.TabIndex = 36;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // ID_radio_868_P
            // 
            this.ID_radio_868_P.AutoSize = true;
            this.ID_radio_868_P.Location = new System.Drawing.Point(0, 0);
            this.ID_radio_868_P.Name = "ID_radio_868_P";
            this.ID_radio_868_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_868_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_868_P.TabIndex = 32;
            this.ID_radio_868_P.Text = "868";
            this.ID_radio_868_P.UseCustomBackColor = true;
            this.ID_radio_868_P.UseSelectable = true;
            this.ID_radio_868_P.UseStyleColors = true;
            // 
            // ID_radio_433_P
            // 
            this.ID_radio_433_P.AutoSize = true;
            this.ID_radio_433_P.Location = new System.Drawing.Point(120, 0);
            this.ID_radio_433_P.Name = "ID_radio_433_P";
            this.ID_radio_433_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_433_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_433_P.TabIndex = 34;
            this.ID_radio_433_P.Text = "433";
            this.ID_radio_433_P.UseCustomBackColor = true;
            this.ID_radio_433_P.UseSelectable = true;
            this.ID_radio_433_P.UseStyleColors = true;
            // 
            // ID_radio_915_P
            // 
            this.ID_radio_915_P.AutoSize = true;
            this.ID_radio_915_P.Location = new System.Drawing.Point(60, 0);
            this.ID_radio_915_P.Name = "ID_radio_915_P";
            this.ID_radio_915_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_915_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_915_P.TabIndex = 33;
            this.ID_radio_915_P.Text = "915";
            this.ID_radio_915_P.UseCustomBackColor = true;
            this.ID_radio_915_P.UseSelectable = true;
            this.ID_radio_915_P.UseStyleColors = true;
            // 
            // ID_toggle_Fungo
            // 
            this.ID_toggle_Fungo.AutoSize = true;
            this.ID_toggle_Fungo.Location = new System.Drawing.Point(150, 145);
            this.ID_toggle_Fungo.Name = "ID_toggle_Fungo";
            this.ID_toggle_Fungo.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Fungo.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Fungo.TabIndex = 28;
            this.ID_toggle_Fungo.Text = "Off";
            this.ID_toggle_Fungo.UseSelectable = true;
            // 
            // ID_toggle_Torcia
            // 
            this.ID_toggle_Torcia.AutoSize = true;
            this.ID_toggle_Torcia.Location = new System.Drawing.Point(150, 125);
            this.ID_toggle_Torcia.Name = "ID_toggle_Torcia";
            this.ID_toggle_Torcia.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Torcia.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Torcia.TabIndex = 27;
            this.ID_toggle_Torcia.Text = "Off";
            this.ID_toggle_Torcia.UseSelectable = true;
            // 
            // ID_toggle_Vibracall
            // 
            this.ID_toggle_Vibracall.AutoSize = true;
            this.ID_toggle_Vibracall.Location = new System.Drawing.Point(150, 105);
            this.ID_toggle_Vibracall.Name = "ID_toggle_Vibracall";
            this.ID_toggle_Vibracall.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Vibracall.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Vibracall.TabIndex = 26;
            this.ID_toggle_Vibracall.Text = "Off";
            this.ID_toggle_Vibracall.UseSelectable = true;
            // 
            // ID_toggle_Buzzer
            // 
            this.ID_toggle_Buzzer.AutoSize = true;
            this.ID_toggle_Buzzer.Location = new System.Drawing.Point(150, 85);
            this.ID_toggle_Buzzer.Name = "ID_toggle_Buzzer";
            this.ID_toggle_Buzzer.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Buzzer.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Buzzer.TabIndex = 25;
            this.ID_toggle_Buzzer.Text = "Off";
            this.ID_toggle_Buzzer.UseSelectable = true;
            // 
            // ID_toggle_SP
            // 
            this.ID_toggle_SP.AutoSize = true;
            this.ID_toggle_SP.Location = new System.Drawing.Point(150, 65);
            this.ID_toggle_SP.Name = "ID_toggle_SP";
            this.ID_toggle_SP.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_SP.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_SP.TabIndex = 24;
            this.ID_toggle_SP.Text = "Off";
            this.ID_toggle_SP.UseSelectable = true;
            // 
            // ID_toggle_Accel
            // 
            this.ID_toggle_Accel.AutoSize = true;
            this.ID_toggle_Accel.Location = new System.Drawing.Point(150, 45);
            this.ID_toggle_Accel.Name = "ID_toggle_Accel";
            this.ID_toggle_Accel.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Accel.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Accel.TabIndex = 23;
            this.ID_toggle_Accel.Text = "Off";
            this.ID_toggle_Accel.UseSelectable = true;
            // 
            // ID_toggle_Display
            // 
            this.ID_toggle_Display.AutoSize = true;
            this.ID_toggle_Display.Location = new System.Drawing.Point(150, 25);
            this.ID_toggle_Display.Name = "ID_toggle_Display";
            this.ID_toggle_Display.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Display.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Display.TabIndex = 22;
            this.ID_toggle_Display.Text = "Off";
            this.ID_toggle_Display.UseSelectable = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(5, 145);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(119, 19);
            this.metroLabel9.TabIndex = 20;
            this.metroLabel9.Text = "Fungo Emergenza:";
            this.metroLabel9.UseCustomBackColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(5, 125);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(46, 19);
            this.metroLabel8.TabIndex = 19;
            this.metroLabel8.Text = "Torcia:";
            this.metroLabel8.UseCustomBackColor = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(5, 105);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(62, 19);
            this.metroLabel7.TabIndex = 18;
            this.metroLabel7.Text = "Vibracall:";
            this.metroLabel7.UseCustomBackColor = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(5, 85);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(52, 19);
            this.metroLabel6.TabIndex = 17;
            this.metroLabel6.Text = "Buzzer:";
            this.metroLabel6.UseCustomBackColor = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(5, 65);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(80, 19);
            this.metroLabel5.TabIndex = 16;
            this.metroLabel5.Text = "Safety Point:";
            this.metroLabel5.UseCustomBackColor = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(5, 45);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(99, 19);
            this.metroLabel4.TabIndex = 15;
            this.metroLabel4.Text = "Accelerometro:";
            this.metroLabel4.UseCustomBackColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(5, 25);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(86, 19);
            this.metroLabel3.TabIndex = 14;
            this.metroLabel3.Text = "Display Oled:";
            this.metroLabel3.UseCustomBackColor = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(5, 5);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(111, 19);
            this.metroLabel2.TabIndex = 13;
            this.metroLabel2.Text = "Frequenza Radio:";
            this.metroLabel2.UseCustomBackColor = true;
            // 
            // pan_P_top
            // 
            this.pan_P_top.BackColor = System.Drawing.Color.White;
            this.pan_P_top.Controls.Add(this.ID_lab_Palmare);
            this.pan_P_top.Controls.Add(this.metroLabel1);
            this.pan_P_top.Controls.Add(this.grid_SchedeCompatibili);
            this.pan_P_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_P_top.HorizontalScrollbarBarColor = true;
            this.pan_P_top.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_top.HorizontalScrollbarSize = 10;
            this.pan_P_top.Location = new System.Drawing.Point(0, 0);
            this.pan_P_top.Name = "pan_P_top";
            this.pan_P_top.Size = new System.Drawing.Size(700, 160);
            this.pan_P_top.TabIndex = 41;
            this.pan_P_top.VerticalScrollbarBarColor = true;
            this.pan_P_top.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_top.VerticalScrollbarSize = 10;
            // 
            // ID_lab_Palmare
            // 
            this.ID_lab_Palmare.AutoSize = true;
            this.ID_lab_Palmare.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.ID_lab_Palmare.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.ID_lab_Palmare.Location = new System.Drawing.Point(0, 0);
            this.ID_lab_Palmare.Name = "ID_lab_Palmare";
            this.ID_lab_Palmare.Size = new System.Drawing.Size(74, 25);
            this.ID_lab_Palmare.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_lab_Palmare.TabIndex = 7;
            this.ID_lab_Palmare.Text = "Palmare";
            this.ID_lab_Palmare.UseCustomBackColor = true;
            this.ID_lab_Palmare.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(5, 30);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(108, 19);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Scheda utilizzata:";
            this.metroLabel1.UseCustomBackColor = true;
            // 
            // grid_SchedeCompatibili
            // 
            this.grid_SchedeCompatibili.AllowUserToAddRows = false;
            this.grid_SchedeCompatibili.AllowUserToDeleteRows = false;
            this.grid_SchedeCompatibili.AllowUserToResizeRows = false;
            this.grid_SchedeCompatibili.AutoGenerateColumns = false;
            this.grid_SchedeCompatibili.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid_SchedeCompatibili.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SchedeCompatibili.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_SchedeCompatibili.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_SchedeCompatibili.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SchedeCompatibili.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.grid_SchedeCompatibili.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_SchedeCompatibili.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodSch,
            this.prodDescrizione,
            this.SchedaCompatibile});
            this.grid_SchedeCompatibili.DataSource = this.famProdSchedeBindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_SchedeCompatibili.DefaultCellStyle = dataGridViewCellStyle5;
            this.grid_SchedeCompatibili.EnableHeadersVisualStyles = false;
            this.grid_SchedeCompatibili.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_SchedeCompatibili.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SchedeCompatibili.HighLightPercentage = 1.5F;
            this.grid_SchedeCompatibili.Location = new System.Drawing.Point(150, 31);
            this.grid_SchedeCompatibili.Name = "grid_SchedeCompatibili";
            this.grid_SchedeCompatibili.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SchedeCompatibili.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.grid_SchedeCompatibili.RowHeadersVisible = false;
            this.grid_SchedeCompatibili.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_SchedeCompatibili.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_SchedeCompatibili.Size = new System.Drawing.Size(537, 126);
            this.grid_SchedeCompatibili.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_SchedeCompatibili.TabIndex = 40;
            this.grid_SchedeCompatibili.UseCustomBackColor = true;
            this.grid_SchedeCompatibili.UseStyleColors = true;
            this.grid_SchedeCompatibili.Validated += new System.EventHandler(this.grid_SchedeCompatibili_Validated);
            // 
            // prodSch
            // 
            this.prodSch.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.prodSch.DataPropertyName = "Prod_Sch";
            this.prodSch.FillWeight = 20F;
            this.prodSch.HeaderText = "Scheda";
            this.prodSch.Name = "prodSch";
            this.prodSch.ReadOnly = true;
            this.prodSch.Width = 67;
            // 
            // prodDescrizione
            // 
            this.prodDescrizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.prodDescrizione.DataPropertyName = "Prod_Descrizione";
            this.prodDescrizione.FillWeight = 60F;
            this.prodDescrizione.HeaderText = "Descrizione Scheda";
            this.prodDescrizione.Name = "prodDescrizione";
            this.prodDescrizione.ReadOnly = true;
            this.prodDescrizione.Width = 118;
            // 
            // SchedaCompatibile
            // 
            this.SchedaCompatibile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.SchedaCompatibile.FillWeight = 20F;
            this.SchedaCompatibile.HeaderText = "Comp.";
            this.SchedaCompatibile.Name = "SchedaCompatibile";
            this.SchedaCompatibile.Width = 44;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroLabel22.Location = new System.Drawing.Point(339, 52);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(106, 19);
            this.metroLabel22.TabIndex = 13;
            this.metroLabel22.Text = "Software già codificati:";
            this.metroLabel22.UseCustomBackColor = true;
            // 
            // grid_SW_codificati
            // 
            this.grid_SW_codificati.AllowUserToAddRows = false;
            this.grid_SW_codificati.AllowUserToDeleteRows = false;
            this.grid_SW_codificati.AllowUserToResizeRows = false;
            this.grid_SW_codificati.AutoGenerateColumns = false;
            this.grid_SW_codificati.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid_SW_codificati.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SW_codificati.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_SW_codificati.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_SW_codificati.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SW_codificati.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grid_SW_codificati.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_SW_codificati.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sWCodeDataGridViewTextBoxColumn,
            this.SW_Customer});
            this.SW_Layout.SetColumnSpan(this.grid_SW_codificati, 6);
            this.grid_SW_codificati.DataSource = this.famProdSoftwareBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_SW_codificati.DefaultCellStyle = dataGridViewCellStyle2;
            this.grid_SW_codificati.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_SW_codificati.EnableHeadersVisualStyles = false;
            this.grid_SW_codificati.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_SW_codificati.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SW_codificati.HighLightPercentage = 1.5F;
            this.grid_SW_codificati.Location = new System.Drawing.Point(451, 55);
            this.grid_SW_codificati.MultiSelect = false;
            this.grid_SW_codificati.Name = "grid_SW_codificati";
            this.grid_SW_codificati.ReadOnly = true;
            this.grid_SW_codificati.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SW_codificati.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grid_SW_codificati.RowHeadersVisible = false;
            this.grid_SW_codificati.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_SW_codificati.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_SW_codificati.Size = new System.Drawing.Size(672, 144);
            this.grid_SW_codificati.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_SW_codificati.TabIndex = 15;
            // 
            // sWCodeDataGridViewTextBoxColumn
            // 
            this.sWCodeDataGridViewTextBoxColumn.DataPropertyName = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn.HeaderText = "Codice SW";
            this.sWCodeDataGridViewTextBoxColumn.Name = "sWCodeDataGridViewTextBoxColumn";
            this.sWCodeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // SW_Customer
            // 
            this.SW_Customer.DataPropertyName = "SW_Customer";
            this.SW_Customer.HeaderText = "Cliente";
            this.SW_Customer.Name = "SW_Customer";
            this.SW_Customer.ReadOnly = true;
            // 
            // famProdSoftwareBindingSource
            // 
            this.famProdSoftwareBindingSource.DataMember = "Fam_Prod_Software";
            this.famProdSoftwareBindingSource.DataSource = this.famProdBindingSource;
            this.famProdSoftwareBindingSource.CurrentChanged += new System.EventHandler(this.famProdSoftwareBindingSource_CurrentChanged);
            // 
            // pan_SW_Codifica
            // 
            this.SW_Layout.SetColumnSpan(this.pan_SW_Codifica, 4);
            this.pan_SW_Codifica.Controls.Add(this.metroLabel10);
            this.pan_SW_Codifica.Controls.Add(this.SW_lab_codice_SW);
            this.pan_SW_Codifica.Controls.Add(this.metroLabel21);
            this.pan_SW_Codifica.Controls.Add(this.tbox_Sw_name);
            this.pan_SW_Codifica.Controls.Add(this.tbox_Sw_version);
            this.pan_SW_Codifica.Controls.Add(this.tbox_Sw_frequency);
            this.pan_SW_Codifica.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_Codifica.HorizontalScrollbarBarColor = true;
            this.pan_SW_Codifica.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_Codifica.HorizontalScrollbarSize = 10;
            this.pan_SW_Codifica.Location = new System.Drawing.Point(3, 1047);
            this.pan_SW_Codifica.Name = "pan_SW_Codifica";
            this.pan_SW_Codifica.Size = new System.Drawing.Size(442, 99);
            this.pan_SW_Codifica.TabIndex = 17;
            this.pan_SW_Codifica.UseCustomBackColor = true;
            this.pan_SW_Codifica.VerticalScrollbarBarColor = true;
            this.pan_SW_Codifica.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_Codifica.VerticalScrollbarSize = 10;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel10.Location = new System.Drawing.Point(359, 40);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(30, 19);
            this.metroLabel10.TabIndex = 13;
            this.metroLabel10.Text = "_SL";
            this.metroLabel10.UseCustomBackColor = true;
            // 
            // SW_lab_codice_SW
            // 
            this.SW_lab_codice_SW.AutoSize = true;
            this.SW_lab_codice_SW.Location = new System.Drawing.Point(5, 40);
            this.SW_lab_codice_SW.Name = "SW_lab_codice_SW";
            this.SW_lab_codice_SW.Size = new System.Drawing.Size(108, 19);
            this.SW_lab_codice_SW.TabIndex = 7;
            this.SW_lab_codice_SW.Text = "Codice Software:";
            this.SW_lab_codice_SW.UseCustomBackColor = true;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel21.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel21.Location = new System.Drawing.Point(148, 40);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(49, 19);
            this.metroLabel21.TabIndex = 8;
            this.metroLabel21.Text = "XSWR";
            this.metroLabel21.UseCustomBackColor = true;
            // 
            // tbox_Sw_name
            // 
            this.tbox_Sw_name.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_name.Location = new System.Drawing.Point(199, 40);
            this.tbox_Sw_name.Mask = ">AAAAA";
            this.tbox_Sw_name.Name = "tbox_Sw_name";
            this.tbox_Sw_name.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_name.TabIndex = 10;
            this.tbox_Sw_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_name.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_name_Validating);
            // 
            // tbox_Sw_version
            // 
            this.tbox_Sw_version.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_version.Location = new System.Drawing.Point(254, 40);
            this.tbox_Sw_version.Mask = ">AAA";
            this.tbox_Sw_version.Name = "tbox_Sw_version";
            this.tbox_Sw_version.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_version.TabIndex = 11;
            this.tbox_Sw_version.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_version.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_version_Validating);
            // 
            // tbox_Sw_frequency
            // 
            this.tbox_Sw_frequency.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_frequency.Location = new System.Drawing.Point(309, 40);
            this.tbox_Sw_frequency.Mask = ">&";
            this.tbox_Sw_frequency.Name = "tbox_Sw_frequency";
            this.tbox_Sw_frequency.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_frequency.TabIndex = 12;
            this.tbox_Sw_frequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_frequency.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_frequency_Validating);
            // 
            // SW_lab_Famiglia
            // 
            this.SW_lab_Famiglia.AutoSize = true;
            this.SW_lab_Famiglia.Dock = System.Windows.Forms.DockStyle.Top;
            this.SW_lab_Famiglia.Location = new System.Drawing.Point(3, 52);
            this.SW_lab_Famiglia.Name = "SW_lab_Famiglia";
            this.SW_lab_Famiglia.Size = new System.Drawing.Size(106, 19);
            this.SW_lab_Famiglia.TabIndex = 3;
            this.SW_lab_Famiglia.Text = "Famiglia di prodotto:";
            this.SW_lab_Famiglia.UseCustomBackColor = true;
            // 
            // ID_combo_Famiglia
            // 
            this.ID_combo_Famiglia.BackColor = System.Drawing.SystemColors.Window;
            this.SW_Layout.SetColumnSpan(this.ID_combo_Famiglia, 2);
            this.ID_combo_Famiglia.DataSource = this.famProdBindingSource;
            this.ID_combo_Famiglia.DisplayMember = "Fam_Name";
            this.ID_combo_Famiglia.Dock = System.Windows.Forms.DockStyle.Top;
            this.ID_combo_Famiglia.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ID_combo_Famiglia.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_combo_Famiglia.FormattingEnabled = true;
            this.ID_combo_Famiglia.ItemHeight = 15;
            this.ID_combo_Famiglia.Location = new System.Drawing.Point(115, 55);
            this.ID_combo_Famiglia.Name = "ID_combo_Famiglia";
            this.ID_combo_Famiglia.Size = new System.Drawing.Size(218, 23);
            this.ID_combo_Famiglia.TabIndex = 6;
            // 
            // pan_SW_Titolo
            // 
            this.SW_Layout.SetColumnSpan(this.pan_SW_Titolo, 10);
            this.pan_SW_Titolo.Controls.Add(this.titolo_ID);
            this.pan_SW_Titolo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_Titolo.HorizontalScrollbarBarColor = true;
            this.pan_SW_Titolo.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_Titolo.HorizontalScrollbarSize = 10;
            this.pan_SW_Titolo.Location = new System.Drawing.Point(3, 3);
            this.pan_SW_Titolo.Name = "pan_SW_Titolo";
            this.pan_SW_Titolo.Size = new System.Drawing.Size(1120, 22);
            this.pan_SW_Titolo.TabIndex = 18;
            this.pan_SW_Titolo.UseCustomBackColor = true;
            this.pan_SW_Titolo.VerticalScrollbarBarColor = true;
            this.pan_SW_Titolo.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_Titolo.VerticalScrollbarSize = 10;
            // 
            // titolo_ID
            // 
            this.titolo_ID.AutoSize = true;
            this.titolo_ID.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.titolo_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.titolo_ID.Location = new System.Drawing.Point(0, 0);
            this.titolo_ID.Name = "titolo_ID";
            this.titolo_ID.Size = new System.Drawing.Size(166, 25);
            this.titolo_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.titolo_ID.TabIndex = 2;
            this.titolo_ID.Text = "Datasheet Software";
            this.titolo_ID.UseCustomBackColor = true;
            this.titolo_ID.UseStyleColors = true;
            // 
            // fam_ProdTableAdapter
            // 
            this.fam_ProdTableAdapter.ClearBeforeFill = true;
            // 
            // schedeTableAdapter
            // 
            this.schedeTableAdapter.ClearBeforeFill = true;
            // 
            // softwareTableAdapter
            // 
            this.softwareTableAdapter.ClearBeforeFill = true;
            // 
            // metroContextMenu1
            // 
            this.metroContextMenu1.Name = "metroContextMenu1";
            this.metroContextMenu1.Size = new System.Drawing.Size(61, 4);
            // 
            // SW_Layout
            // 
            this.SW_Layout.ColumnCount = 10;
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.Controls.Add(this.SW_lab_Famiglia, 0, 3);
            this.SW_Layout.Controls.Add(this.ID_combo_Famiglia, 1, 3);
            this.SW_Layout.Controls.Add(this.metroLabel22, 3, 3);
            this.SW_Layout.Controls.Add(this.grid_SW_codificati, 4, 3);
            this.SW_Layout.Controls.Add(this.pan_SW_Titolo, 0, 0);
            this.SW_Layout.Controls.Add(this.pan_Menu, 0, 2);
            this.SW_Layout.Controls.Add(this.pan_Menu_exit, 9, 2);
            this.SW_Layout.Controls.Add(this.pan_SW_P, 0, 4);
            this.SW_Layout.Controls.Add(this.pan_SW_C, 0, 5);
            this.SW_Layout.Controls.Add(this.pan_SW_Codifica, 0, 6);
            this.SW_Layout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SW_Layout.Location = new System.Drawing.Point(0, 0);
            this.SW_Layout.Name = "SW_Layout";
            this.SW_Layout.RowCount = 11;
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.SW_Layout.Size = new System.Drawing.Size(1126, 1500);
            this.SW_Layout.TabIndex = 16;
            // 
            // pan_Menu
            // 
            this.SW_Layout.SetColumnSpan(this.pan_Menu, 9);
            this.pan_Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.modificaCodiceToolStripMenuItem,
            this.creaPdfToolStripMenuItem});
            this.pan_Menu.Location = new System.Drawing.Point(0, 28);
            this.pan_Menu.Name = "pan_Menu";
            this.pan_Menu.Size = new System.Drawing.Size(1008, 24);
            this.pan_Menu.TabIndex = 12;
            this.pan_Menu.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(111, 20);
            this.toolStripMenuItem1.Text = "Nuovo Codice";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Enabled = false;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(22, 20);
            this.toolStripMenuItem2.Text = "|";
            // 
            // modificaCodiceToolStripMenuItem
            // 
            this.modificaCodiceToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("modificaCodiceToolStripMenuItem.Image")));
            this.modificaCodiceToolStripMenuItem.Name = "modificaCodiceToolStripMenuItem";
            this.modificaCodiceToolStripMenuItem.Size = new System.Drawing.Size(122, 20);
            this.modificaCodiceToolStripMenuItem.Text = "Modifica Codice";
            this.modificaCodiceToolStripMenuItem.Click += new System.EventHandler(this.modificaCodiceToolStripMenuItem_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.pan_Menu_exit.Location = new System.Drawing.Point(1008, 28);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(118, 24);
            this.pan_Menu_exit.TabIndex = 19;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Enabled = false;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.ShowShortcutKeys = false;
            this.toolStripMenuItem5.Size = new System.Drawing.Size(22, 20);
            this.toolStripMenuItem5.Text = "|";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem6.Image")));
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(67, 20);
            this.toolStripMenuItem6.Text = "Uscita";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // ID_radio_Filo_P
            // 
            this.ID_radio_Filo_P.AutoSize = true;
            this.ID_radio_Filo_P.Location = new System.Drawing.Point(180, 0);
            this.ID_radio_Filo_P.Name = "ID_radio_Filo_P";
            this.ID_radio_Filo_P.Size = new System.Drawing.Size(42, 15);
            this.ID_radio_Filo_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_Filo_P.TabIndex = 35;
            this.ID_radio_Filo_P.Text = "Filo";
            this.ID_radio_Filo_P.UseCustomBackColor = true;
            this.ID_radio_Filo_P.UseSelectable = true;
            this.ID_radio_Filo_P.UseStyleColors = true;
            // 
            // ID_radio_None_P
            // 
            this.ID_radio_None_P.AutoSize = true;
            this.ID_radio_None_P.Location = new System.Drawing.Point(240, 0);
            this.ID_radio_None_P.Name = "ID_radio_None_P";
            this.ID_radio_None_P.Size = new System.Drawing.Size(52, 15);
            this.ID_radio_None_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_None_P.TabIndex = 36;
            this.ID_radio_None_P.Text = "None";
            this.ID_radio_None_P.UseCustomBackColor = true;
            this.ID_radio_None_P.UseSelectable = true;
            this.ID_radio_None_P.UseStyleColors = true;
            // 
            // creaPdfToolStripMenuItem
            // 
            this.creaPdfToolStripMenuItem.Name = "creaPdfToolStripMenuItem";
            this.creaPdfToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.creaPdfToolStripMenuItem.Text = "crea pdf";
            this.creaPdfToolStripMenuItem.Click += new System.EventHandler(this.creaPdfToolStripMenuItem_Click);
            // 
            // UC_form_Sw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.SW_Layout);
            this.Name = "UC_form_Sw";
            this.Size = new System.Drawing.Size(1126, 1500);
            this.Load += new System.EventHandler(this.UC_form_Sw_Load);
            this.pan_SW_C.ResumeLayout(false);
            this.pan_SW_C.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.C_sch_image)).EndInit();
            this.metroPanel3.ResumeLayout(false);
            this.metroPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).EndInit();
            this.pan_SW_P.ResumeLayout(false);
            this.pan_P_Dx.ResumeLayout(false);
            this.pan_P_Dx_Funzionamento.ResumeLayout(false);
            this.funz_fill.ResumeLayout(false);
            this.funz_top.ResumeLayout(false);
            this.funz_top.PerformLayout();
            this.pan_P_Dx_revisioni.ResumeLayout(false);
            this.rev_fill.ResumeLayout(false);
            this.rev_top.ResumeLayout(false);
            this.rev_top.PerformLayout();
            this.pan_P_Sx.ResumeLayout(false);
            this.pan_P_middle.ResumeLayout(false);
            this.pan_P_middle.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.pan_P_top.ResumeLayout(false);
            this.pan_P_top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SchedeCompatibili)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SW_codificati)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSoftwareBindingSource)).EndInit();
            this.pan_SW_Codifica.ResumeLayout(false);
            this.pan_SW_Codifica.PerformLayout();
            this.pan_SW_Titolo.ResumeLayout(false);
            this.pan_SW_Titolo.PerformLayout();
            this.SW_Layout.ResumeLayout(false);
            this.SW_Layout.PerformLayout();
            this.pan_Menu.ResumeLayout(false);
            this.pan_Menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel pan_SW_C;
        private MetroFramework.Controls.MetroLabel lab_Des_Scheda_C;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroRadioButton ID_radio_868_C;
        private MetroFramework.Controls.MetroRadioButton ID_radio_433_C;
        private MetroFramework.Controls.MetroRadioButton ID_radio_915_C;
        private MetroFramework.Controls.MetroToggle ID_toggle_Prop;
        private MetroFramework.Controls.MetroToggle ID_toggle_CanBus;
        private MetroFramework.Controls.MetroToggle ID_toggle_AntExt;
        private MetroFramework.Controls.MetroToggle ID_toggle_GuidaLuce;
        private MetroFramework.Controls.MetroToggle ID_toggle_TastEmerg;
        private MetroFramework.Controls.MetroToggle ID_toggle_PlugPLE;
        private MetroFramework.Controls.MetroToggle ID_toggle_PlugExp;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroPanel pan_SW_P;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroRadioButton ID_radio_868_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_433_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_915_P;
        private MetroFramework.Controls.MetroToggle ID_toggle_Fungo;
        private MetroFramework.Controls.MetroToggle ID_toggle_Torcia;
        private MetroFramework.Controls.MetroToggle ID_toggle_Vibracall;
        private MetroFramework.Controls.MetroToggle ID_toggle_Buzzer;
        private MetroFramework.Controls.MetroToggle ID_toggle_SP;
        private MetroFramework.Controls.MetroToggle ID_toggle_Accel;
        private MetroFramework.Controls.MetroToggle ID_toggle_Display;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel ID_lab_Palmare;
        private System.Windows.Forms.ComboBox ID_combo_Famiglia;
        private MetroFramework.Controls.MetroLabel titolo_ID;
        private MetroFramework.Controls.MetroLabel SW_lab_Famiglia;
        private System.Windows.Forms.PictureBox C_sch_image;
        private MetroFramework.Controls.MetroLabel SW_lab_codice_SW;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_frequency;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_version;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_name;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroGrid grid_SW_codificati;
        private MetroFramework.Controls.MetroPanel pan_SW_Codifica;
        private MetroFramework.Controls.MetroPanel pan_SW_Titolo;
        private System.Windows.Forms.BindingSource famProdSchedeBindingSource;
        private System.Windows.Forms.BindingSource famProdBindingSource;
        private DB_FactoryDataSet dB_FactoryDataSet;
        private System.Windows.Forms.BindingSource famProdSoftwareBindingSource;
        private DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter fam_ProdTableAdapter;
        private DB_FactoryDataSetTableAdapters.SchedeTableAdapter schedeTableAdapter;
        private DB_FactoryDataSetTableAdapters.SoftwareTableAdapter softwareTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SW_Customer;
        private MetroFramework.Controls.MetroGrid grid_SchedeCompatibili;
        private MetroFramework.Controls.MetroPanel pan_P_middle;
        private MetroFramework.Controls.MetroPanel pan_P_top;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private MetroFramework.Controls.MetroToggle ID_toggle_ShiftPage;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Torch;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Vibracall;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Buzzer;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_SP;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Accel;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Backlight;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroPanel pan_P_Sx;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodSch;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodDescrizione;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SchedaCompatibile;
        private MetroFramework.Controls.MetroPanel pan_P_Dx;
        private MetroFramework.Controls.MetroPanel pan_P_Dx_revisioni;
        private System.Windows.Forms.RichTextBox richtb_Revisioni;
        private MetroFramework.Controls.MetroContextMenu metroContextMenu1;
        private MetroFramework.Controls.MetroPanel pan_P_Dx_Funzionamento;
        private System.Windows.Forms.RichTextBox richtb_Funzioni;
        private MetroFramework.Controls.MetroLabel metroLabel32;
        private MetroFramework.Controls.MetroPanel rev_fill;
        private MetroFramework.Controls.MetroPanel rev_top;
        private MetroFramework.Controls.MetroLabel metroLabel33;
        private MetroFramework.Controls.MetroPanel funz_fill;
        private MetroFramework.Controls.MetroPanel funz_top;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.TableLayoutPanel SW_Layout;
        private System.Windows.Forms.MenuStrip pan_Menu;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem modificaCodiceToolStripMenuItem;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.TextBox tb_Max_Pairable;
        private MetroFramework.Controls.MetroRadioButton ID_radio_None_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_Filo_P;
        private System.Windows.Forms.ToolStripMenuItem creaPdfToolStripMenuItem;
    }
}
