﻿namespace SE_Factory
{


    partial class DB_FactoryDataSet
    {
        partial class SoftwareDataTable
        {
        }
    }
}
