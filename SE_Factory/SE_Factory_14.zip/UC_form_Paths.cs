﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SE_Factory
{
    public partial class UC_form_Paths : UserControl
    {
        public UC_form_Paths()
        {
            InitializeComponent();
        }

        private void pan_Menu_exit_Click(object sender, EventArgs e)
        {
            this.Parent.Controls.Remove(this);
        }

        private void UC_form_Paths_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'dB_FactoryDataSet.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.pathsTableAdapter.Fill(this.dB_FactoryDataSet.Paths);

            GVar.glob_form_status = "V";
            Setting_Form();
        }

        private void Setting_Form()
        {
            switch (GVar.glob_form_status)
            {
                case "N":
                    tb_Paths_Doc.Enabled = true;
                    tb_Paths_Sw.Enabled = true;
                    pan_Menu_comandi.Enabled = false;
                    pan_Menu_salva.Enabled = true;
                    pan_Menu_exit.Enabled = false;
                    break;
                case "E":
                    tb_Paths_Doc.Enabled = true;
                    tb_Paths_Sw.Enabled = true;
                    pan_Menu_comandi.Enabled = false;
                    pan_Menu_salva.Enabled = true;
                    pan_Menu_exit.Enabled = false;
                    break;
                case "V":
                    tb_Paths_Doc.Enabled = false;
                    tb_Paths_Sw.Enabled = false;
                    pan_Menu_comandi.Enabled = true;
                    pan_Menu_salva.Enabled = false;
                    pan_Menu_exit.Enabled = true;
                    break;
            }
        }

        private void menu_sw_edit_Click(object sender, EventArgs e)
        {
            GVar.glob_form_status = "E";
            Setting_Form();
        }

        private void pathsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            //Visualizzo i dati in base ai valori del record
            if (pathsBindingSource.Current != null)
            {
                DataRow Path_view = ((DataRowView)pathsBindingSource.Current).Row;

                tb_Paths_Doc.Text = Path_view["Path_URL_Documentazione"].ToString();
                tb_Paths_Sw.Text = Path_view["Path_URL_Software"].ToString();
            }
        }

        private void menu_sw_annulla_Click(object sender, EventArgs e)
        {
            GVar.glob_form_status = "V";
            Setting_Form();
        }
    }
}