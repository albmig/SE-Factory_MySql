﻿namespace SE_Factory
{
    partial class UC_form_Printers
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_form_Printers));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ID_pan_Top = new MetroFramework.Controls.MetroPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.menu_btn_Save = new MetroFramework.Controls.MetroTile();
            this.menu_btn_Abort = new MetroFramework.Controls.MetroTile();
            this.panel_save = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.bt_Home = new MetroFramework.Controls.MetroTile();
            this.panel_printers = new MetroFramework.Controls.MetroPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.printersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dB_FactoryDataSet = new SE_Factory.DB_FactoryDataSet();
            this.printersTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.PrintersTableAdapter();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prnNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prnAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prnDefaultDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Prn_Active = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ID_pan_Top.SuspendLayout();
            this.panel_save.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel_printers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.printersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // ID_pan_Top
            // 
            this.ID_pan_Top.Controls.Add(this.metroLabel1);
            this.ID_pan_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.ID_pan_Top.HorizontalScrollbarBarColor = true;
            this.ID_pan_Top.HorizontalScrollbarHighlightOnWheel = false;
            this.ID_pan_Top.HorizontalScrollbarSize = 10;
            this.ID_pan_Top.Location = new System.Drawing.Point(0, 0);
            this.ID_pan_Top.Name = "ID_pan_Top";
            this.ID_pan_Top.Size = new System.Drawing.Size(800, 60);
            this.ID_pan_Top.TabIndex = 5;
            this.ID_pan_Top.UseCustomBackColor = true;
            this.ID_pan_Top.VerticalScrollbarBarColor = true;
            this.ID_pan_Top.VerticalScrollbarHighlightOnWheel = false;
            this.ID_pan_Top.VerticalScrollbarSize = 10;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(0, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(249, 25);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Settaggio Stampante barcode";
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseStyleColors = true;
            // 
            // menu_btn_Save
            // 
            this.menu_btn_Save.ActiveControl = null;
            this.menu_btn_Save.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menu_btn_Save.Location = new System.Drawing.Point(117, 3);
            this.menu_btn_Save.Name = "menu_btn_Save";
            this.menu_btn_Save.Size = new System.Drawing.Size(108, 42);
            this.menu_btn_Save.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_Save.TabIndex = 3;
            this.menu_btn_Save.Text = "Salva";
            this.menu_btn_Save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_Save.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_Save.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_Save.TileImage")));
            this.menu_btn_Save.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_Save.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_Save.UseCustomForeColor = true;
            this.menu_btn_Save.UseSelectable = true;
            this.menu_btn_Save.UseTileImage = true;
            // 
            // menu_btn_Abort
            // 
            this.menu_btn_Abort.ActiveControl = null;
            this.menu_btn_Abort.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menu_btn_Abort.Location = new System.Drawing.Point(345, 3);
            this.menu_btn_Abort.Name = "menu_btn_Abort";
            this.menu_btn_Abort.Size = new System.Drawing.Size(108, 42);
            this.menu_btn_Abort.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_Abort.TabIndex = 5;
            this.menu_btn_Abort.Text = "Annulla";
            this.menu_btn_Abort.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_Abort.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_Abort.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_Abort.TileImage")));
            this.menu_btn_Abort.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_Abort.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_Abort.UseCustomForeColor = true;
            this.menu_btn_Abort.UseSelectable = true;
            this.menu_btn_Abort.UseTileImage = true;
            // 
            // panel_save
            // 
            this.panel_save.Controls.Add(this.tableLayoutPanel1);
            this.panel_save.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_save.HorizontalScrollbarBarColor = true;
            this.panel_save.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_save.HorizontalScrollbarSize = 10;
            this.panel_save.Location = new System.Drawing.Point(0, 418);
            this.panel_save.Name = "panel_save";
            this.panel_save.Size = new System.Drawing.Size(800, 48);
            this.panel_save.TabIndex = 7;
            this.panel_save.VerticalScrollbarBarColor = true;
            this.panel_save.VerticalScrollbarHighlightOnWheel = false;
            this.panel_save.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.menu_btn_Save, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.menu_btn_Abort, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.bt_Home, 5, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 48);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // bt_Home
            // 
            this.bt_Home.ActiveControl = null;
            this.bt_Home.BackColor = System.Drawing.SystemColors.Control;
            this.bt_Home.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Home.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bt_Home.Location = new System.Drawing.Point(573, 3);
            this.bt_Home.Name = "bt_Home";
            this.bt_Home.Size = new System.Drawing.Size(108, 42);
            this.bt_Home.Style = MetroFramework.MetroColorStyle.White;
            this.bt_Home.TabIndex = 8;
            this.bt_Home.Text = "Uscita";
            this.bt_Home.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bt_Home.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bt_Home.TileImage = ((System.Drawing.Image)(resources.GetObject("bt_Home.TileImage")));
            this.bt_Home.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_Home.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.bt_Home.UseCustomForeColor = true;
            this.bt_Home.UseSelectable = true;
            this.bt_Home.UseTileImage = true;
            this.bt_Home.Click += new System.EventHandler(this.bt_Home_Click);
            // 
            // panel_printers
            // 
            this.panel_printers.Controls.Add(this.dataGridView1);
            this.panel_printers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_printers.HorizontalScrollbarBarColor = true;
            this.panel_printers.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_printers.HorizontalScrollbarSize = 10;
            this.panel_printers.Location = new System.Drawing.Point(0, 60);
            this.panel_printers.Name = "panel_printers";
            this.panel_printers.Size = new System.Drawing.Size(800, 358);
            this.panel_printers.TabIndex = 8;
            this.panel_printers.VerticalScrollbarBarColor = true;
            this.panel_printers.VerticalScrollbarHighlightOnWheel = false;
            this.panel_printers.VerticalScrollbarSize = 10;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.prnNameDataGridViewTextBoxColumn,
            this.prnAddressDataGridViewTextBoxColumn,
            this.prnDefaultDataGridViewCheckBoxColumn,
            this.Prn_Active});
            this.dataGridView1.DataSource = this.printersBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(800, 150);
            this.dataGridView1.TabIndex = 2;
            // 
            // printersBindingSource
            // 
            this.printersBindingSource.DataMember = "Printers";
            this.printersBindingSource.DataSource = this.dB_FactoryDataSet;
            // 
            // dB_FactoryDataSet
            // 
            this.dB_FactoryDataSet.DataSetName = "DB_FactoryDataSet";
            this.dB_FactoryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // printersTableAdapter
            // 
            this.printersTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // prnNameDataGridViewTextBoxColumn
            // 
            this.prnNameDataGridViewTextBoxColumn.DataPropertyName = "Prn_Name";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.prnNameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.prnNameDataGridViewTextBoxColumn.FillWeight = 200F;
            this.prnNameDataGridViewTextBoxColumn.HeaderText = "Nome della stampante";
            this.prnNameDataGridViewTextBoxColumn.Name = "prnNameDataGridViewTextBoxColumn";
            this.prnNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prnAddressDataGridViewTextBoxColumn
            // 
            this.prnAddressDataGridViewTextBoxColumn.DataPropertyName = "Prn_Address";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.prnAddressDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.prnAddressDataGridViewTextBoxColumn.HeaderText = "Indirizzo IP";
            this.prnAddressDataGridViewTextBoxColumn.Name = "prnAddressDataGridViewTextBoxColumn";
            this.prnAddressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prnDefaultDataGridViewCheckBoxColumn
            // 
            this.prnDefaultDataGridViewCheckBoxColumn.DataPropertyName = "Prn_Default";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            dataGridViewCellStyle4.NullValue = false;
            this.prnDefaultDataGridViewCheckBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.prnDefaultDataGridViewCheckBoxColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prnDefaultDataGridViewCheckBoxColumn.HeaderText = "Stampante di default";
            this.prnDefaultDataGridViewCheckBoxColumn.Name = "prnDefaultDataGridViewCheckBoxColumn";
            this.prnDefaultDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // Prn_Active
            // 
            this.Prn_Active.DataPropertyName = "Prn_Active";
            this.Prn_Active.HeaderText = "Stampante attiva";
            this.Prn_Active.Name = "Prn_Active";
            this.Prn_Active.ReadOnly = true;
            // 
            // UC_form_Printers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel_printers);
            this.Controls.Add(this.panel_save);
            this.Controls.Add(this.ID_pan_Top);
            this.Name = "UC_form_Printers";
            this.Size = new System.Drawing.Size(800, 466);
            this.Load += new System.EventHandler(this.UC_form_Printers_Load);
            this.ID_pan_Top.ResumeLayout(false);
            this.ID_pan_Top.PerformLayout();
            this.panel_save.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel_printers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.printersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel ID_pan_Top;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTile menu_btn_Save;
        private MetroFramework.Controls.MetroTile menu_btn_Abort;
        private MetroFramework.Controls.MetroPanel panel_save;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroTile bt_Home;
        private MetroFramework.Controls.MetroPanel panel_printers;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource printersBindingSource;
        private DB_FactoryDataSet dB_FactoryDataSet;
        private DB_FactoryDataSetTableAdapters.PrintersTableAdapter printersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prnNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prnAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn prnDefaultDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Prn_Active;
    }
}
