﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace SE_Factory
{
    public partial class MainForm : MetroForm
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            panel_Main.Visible = true;
            panel_ID.Visible = false;
        }

        private void menu_btn_ID_Click(object sender, EventArgs e)
        {
            ID_Form frm_child = new ID_Form();
            //frm_child.FormBorderStyle = FormBorderStyle.None;
            frm_child.TopLevel = false;
            frm_child.Visible = true;
            //frm_child.AutoScroll = true;

            //this.Controls.Add(panel_ID);
            panel_ID.Controls.Add(frm_child);
            frm_child.Show();

            panel_Menu.Visible = false;
            panel_Main.Visible = false;
            panel_ID.Visible = true;
        }
    }
}
