﻿namespace SE_Factory
{
    partial class MainForm
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel_Menu = new MetroFramework.Controls.MetroPanel();
            this.menu_spacer_01 = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_ID = new MetroFramework.Controls.MetroTile();
            this.panel_Main = new MetroFramework.Controls.MetroPanel();
            this.panel_ID = new MetroFramework.Controls.MetroUserControl();
            this.panel_Menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Menu
            // 
            this.panel_Menu.BackColor = System.Drawing.Color.Transparent;
            this.panel_Menu.Controls.Add(this.menu_spacer_01);
            this.panel_Menu.Controls.Add(this.menu_btn_ID);
            this.panel_Menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Menu.HorizontalScrollbarBarColor = true;
            this.panel_Menu.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Menu.HorizontalScrollbarSize = 10;
            this.panel_Menu.Location = new System.Drawing.Point(23, 83);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(150, 590);
            this.panel_Menu.TabIndex = 1;
            this.panel_Menu.VerticalScrollbarBarColor = true;
            this.panel_Menu.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Menu.VerticalScrollbarSize = 10;
            // 
            // menu_spacer_01
            // 
            this.menu_spacer_01.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_spacer_01.HorizontalScrollbarBarColor = true;
            this.menu_spacer_01.HorizontalScrollbarHighlightOnWheel = false;
            this.menu_spacer_01.HorizontalScrollbarSize = 10;
            this.menu_spacer_01.Location = new System.Drawing.Point(0, 50);
            this.menu_spacer_01.Name = "menu_spacer_01";
            this.menu_spacer_01.Size = new System.Drawing.Size(150, 10);
            this.menu_spacer_01.TabIndex = 3;
            this.menu_spacer_01.VerticalScrollbarBarColor = true;
            this.menu_spacer_01.VerticalScrollbarHighlightOnWheel = false;
            this.menu_spacer_01.VerticalScrollbarSize = 10;
            // 
            // menu_btn_ID
            // 
            this.menu_btn_ID.ActiveControl = null;
            this.menu_btn_ID.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_ID.Location = new System.Drawing.Point(0, 0);
            this.menu_btn_ID.Name = "menu_btn_ID";
            this.menu_btn_ID.Size = new System.Drawing.Size(150, 50);
            this.menu_btn_ID.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_ID.TabIndex = 2;
            this.menu_btn_ID.Text = "Calcolo ID";
            this.menu_btn_ID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_ID.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_ID.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_ID.TileImage")));
            this.menu_btn_ID.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_ID.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_ID.UseCustomForeColor = true;
            this.menu_btn_ID.UseSelectable = true;
            this.menu_btn_ID.UseTileImage = true;
            this.menu_btn_ID.Click += new System.EventHandler(this.menu_btn_ID_Click);
            // 
            // panel_Main
            // 
            this.panel_Main.BackColor = System.Drawing.Color.White;
            this.panel_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main.HorizontalScrollbarBarColor = true;
            this.panel_Main.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Main.HorizontalScrollbarSize = 10;
            this.panel_Main.Location = new System.Drawing.Point(173, 83);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(770, 590);
            this.panel_Main.TabIndex = 2;
            this.panel_Main.UseCustomBackColor = true;
            this.panel_Main.VerticalScrollbarBarColor = true;
            this.panel_Main.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Main.VerticalScrollbarSize = 10;
            // 
            // panel_ID
            // 
            this.panel_ID.AutoScroll = true;
            this.panel_ID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ID.Location = new System.Drawing.Point(173, 83);
            this.panel_ID.Name = "panel_ID";
            this.panel_ID.Size = new System.Drawing.Size(770, 590);
            this.panel_ID.TabIndex = 4;
            this.panel_ID.UseSelectable = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 701);
            this.Controls.Add(this.panel_ID);
            this.Controls.Add(this.panel_Main);
            this.Controls.Add(this.panel_Menu);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(23, 83, 23, 28);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica Factory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel_Menu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel panel_Menu;
        private MetroFramework.Controls.MetroTile menu_btn_ID;
        private MetroFramework.Controls.MetroPanel panel_Main;
        private MetroFramework.Controls.MetroPanel menu_spacer_01;
        private MetroFramework.Controls.MetroUserControl panel_ID;
    }
}

