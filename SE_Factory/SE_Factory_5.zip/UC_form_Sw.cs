﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using MetroFramework.Forms;
using iTextSharp.text.pdf;

namespace SE_Factory
{
    public partial class UC_form_Sw : UserControl
    {
        public string SchedeCompatibili_SW = "";
        public string TemplateFolder = @"C:\Users\documentazione\Desktop\___Alberto___\Indesign\Prova Moduli SW\Template_PDF_Software.pdf";
        
        public UC_form_Sw()
        {
            InitializeComponent();
        }

        private void famProdBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            {
                AzzeraVariabili();
                if (famProdBindingSource.Current != null)
                {
                    DataRow currentRow = ((DataRowView)famProdBindingSource.Current).Row;

                    GVar.glob_tipo_item = currentRow["Fam_Tipo"].ToString();
                    GVar.glob_hex_id = currentRow["Fam_Hex_ID"].ToString();
                    GVar.glob_result_id[0] = Convert.ToChar(currentRow["Fam_Hex_ID"]);

                    if (GVar.glob_tipo_item == "P")
                    {
                        SW_pan_C.Visible = false;
                        SW_pan_P.Visible = true;
                    }
                    if (GVar.glob_tipo_item == "C")
                    {
                        SW_pan_P.Visible = false;
                        SW_pan_C.Visible = true;
                    }
                }
            }
        }

        private void ID_timer_Tick(object sender, EventArgs e)
        {
            Calcola_ID_Palmare();
        }

        private void Calcola_ID_Palmare()
        {
            if (GVar.glob_tipo_item == "P")
            {
                Array.Clear(GVar.glob_bin_id, 0, 12);
                if (ID_radio_868_P.Checked) { GVar.glob_bin_id[0] = '1'; } else { GVar.glob_bin_id[0] = '0'; }
                if (ID_radio_915_P.Checked) { GVar.glob_bin_id[1] = '1'; } else { GVar.glob_bin_id[1] = '0'; }
                if (ID_radio_433_P.Checked) { GVar.glob_bin_id[2] = '1'; } else { GVar.glob_bin_id[2] = '0'; }
                if (ID_toggle_Display.Checked) { GVar.glob_bin_id[3] = '1'; } else { GVar.glob_bin_id[3] = '0'; }
                if (ID_toggle_Accel.Checked) { GVar.glob_bin_id[4] = '1'; } else { GVar.glob_bin_id[4] = '0'; }
                if (ID_toggle_SP.Checked) { GVar.glob_bin_id[5] = '1'; } else { GVar.glob_bin_id[5] = '0'; }
                if (ID_toggle_Buzzer.Checked) { GVar.glob_bin_id[6] = '1'; } else { GVar.glob_bin_id[6] = '0'; }
                if (ID_toggle_Vibracall.Checked) { GVar.glob_bin_id[7] = '1'; } else { GVar.glob_bin_id[7] = '0'; }
                if (ID_toggle_Torcia.Checked) { GVar.glob_bin_id[8] = '1'; } else { GVar.glob_bin_id[8] = '0'; }
                if (ID_toggle_Fungo.Checked) { GVar.glob_bin_id[9] = '1'; } else { GVar.glob_bin_id[9] = '0'; }
                GVar.glob_bin_id[10] = '0';
                GVar.glob_bin_id[11] = '0';
            }
            if (GVar.glob_tipo_item == "C")
            {
                Array.Clear(GVar.glob_bin_id, 0, 12);
                if (ID_radio_868_C.Checked) { GVar.glob_bin_id[0] = '1'; } else { GVar.glob_bin_id[0] = '0'; }
                if (ID_radio_915_C.Checked) { GVar.glob_bin_id[1] = '1'; } else { GVar.glob_bin_id[1] = '0'; }
                if (ID_radio_433_C.Checked) { GVar.glob_bin_id[2] = '1'; } else { GVar.glob_bin_id[2] = '0'; }
                if (ID_toggle_PlugExp.Checked) { GVar.glob_bin_id[3] = '1'; } else { GVar.glob_bin_id[3] = '0'; }
                if (ID_toggle_PlugPLE.Checked) { GVar.glob_bin_id[4] = '1'; } else { GVar.glob_bin_id[4] = '0'; }
                if (ID_toggle_TastEmerg.Checked) { GVar.glob_bin_id[5] = '1'; } else { GVar.glob_bin_id[5] = '0'; }
                if (ID_toggle_GuidaLuce.Checked) { GVar.glob_bin_id[6] = '1'; } else { GVar.glob_bin_id[6] = '0'; }
                if (ID_toggle_AntExt.Checked) { GVar.glob_bin_id[7] = '1'; } else { GVar.glob_bin_id[7] = '0'; }
                if (ID_toggle_CanBus.Checked) { GVar.glob_bin_id[8] = '1'; } else { GVar.glob_bin_id[8] = '0'; }
                if (ID_toggle_Prop.Checked) { GVar.glob_bin_id[9] = '1'; } else { GVar.glob_bin_id[9] = '0'; }
                GVar.glob_bin_id[10] = '0';
                GVar.glob_bin_id[11] = '0';
            }

            string binary = "";
            for (int i = 0; i < 12; i++)
            {
                binary = binary + GVar.glob_bin_id[i].ToString();
            }

            // Binary to Hex conversion
            string myhex = Convert.ToString(Convert.ToInt32(binary, 2), 16);
            GVar.glob_result_id[0] = GVar.glob_hex_id[0];
            GVar.glob_result_id[1] = Convert.ToChar(myhex.ToUpper().Substring(0, 1));
            GVar.glob_result_id[2] = Convert.ToChar(myhex.ToUpper().Substring(1, 1));
            GVar.glob_result_id[3] = Convert.ToChar(myhex.ToUpper().Substring(2, 1));
        }

        private void AzzeraVariabili()
        {
            ID_radio_868_P.Checked = true;
            ID_radio_868_C.Checked = true;

            //Azzero Palmari
            ID_toggle_Display.Checked = false;
            ID_toggle_Accel.Checked = false;
            ID_toggle_SP.Checked = false;
            ID_toggle_Buzzer.Checked = false;
            ID_toggle_Vibracall.Checked = false;
            ID_toggle_Torcia.Checked = false;
            ID_toggle_Fungo.Checked = false;

            //Azzero Controller
            ID_toggle_PlugExp.Checked = false;
            ID_toggle_PlugPLE.Checked = false;
            ID_toggle_TastEmerg.Checked = false;
            ID_toggle_GuidaLuce.Checked = false;
            ID_toggle_AntExt.Checked = false;
            ID_toggle_CanBus.Checked = false;
            ID_toggle_Prop.Checked = false;

            grid_SchedeCompatibili.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void bt_Home_Click(object sender, EventArgs e)
        {
            this.Parent.Controls.Remove(this);
        }

        private void tbox_Sw_name_Validating(object sender, CancelEventArgs e)
        {
            if ((!tbox_Sw_name.MaskFull) && (tbox_Sw_name.Text != ""))
            {
                MessageBox.Show("Campo non compilato completamente!");
                tbox_Sw_name.Focus();
            }
        }

        private void tbox_Sw_version_Validating(object sender, CancelEventArgs e)
        {
            if ((!tbox_Sw_version.MaskFull) && (tbox_Sw_version.Text != ""))
            {
                MessageBox.Show("Campo non compilato completamente!");
                tbox_Sw_version.Focus();
            }
        }

        private void tbox_Sw_frequency_Validating(object sender, CancelEventArgs e)
        {
            if ((!tbox_Sw_frequency.MaskFull) && (tbox_Sw_frequency.Text != ""))
            {
                MessageBox.Show("Campo non compilato completamente!");
                tbox_Sw_frequency.Focus();
            }
        }

        private void UC_form_Sw_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'dB_FactoryDataSet.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.fam_ProdTableAdapter.Fill(this.dB_FactoryDataSet.Fam_Prod);
            // TODO: questa riga di codice carica i dati nella tabella 'dB_FactoryDataSet.Schede'. È possibile spostarla o rimuoverla se necessario.
            this.schedeTableAdapter.Fill(this.dB_FactoryDataSet.Schede);
            // TODO: questa riga di codice carica i dati nella tabella 'dB_FactoryDataSet.Software'. È possibile spostarla o rimuoverla se necessario.
            this.softwareTableAdapter.Fill(this.dB_FactoryDataSet.Software);

            AzzeraVariabili();
        }

        private void grid_SchedeCompatibili_Validated(object sender, EventArgs e)
        {
            if (grid_SchedeCompatibili.Rows.Count > 0)
            {
                SchedeCompatibili_SW = "";
                string testo = "";
                for (int i = 0; i < grid_SchedeCompatibili.Rows.Count; i++)
                {
                    DataGridViewRow selectedRow = grid_SchedeCompatibili.Rows[i];
                    bool isChecked = Convert.ToBoolean(selectedRow.Cells["SchedaCompatibile"].Value);

                    if (isChecked)
                    {
                        if (testo == "")
                        {
                            testo = selectedRow.Cells["prodSch"].Value.ToString();
                        }
                        else
                        {
                            testo = testo + "|";
                            testo = testo + selectedRow.Cells["prodSch"].Value.ToString();
                        }
                    }
                }
                SchedeCompatibili_SW = testo;
            }
        }

        private void CreaPDF()
        {
            System.Threading.Thread.Sleep(1000);

            string P_InputStream = TemplateFolder;

            string P_OutputStream = @"C:\Users\documentazione\Desktop\___Alberto___\Indesign\Prova Moduli SW\FolderOut\result.pdf";

            using (FileStream outFile = new FileStream(P_OutputStream, FileMode.Create))
            {
                PdfReader pdfReader = new PdfReader(P_InputStream);
                PdfStamper pdfStamper = new PdfStamper(pdfReader, outFile);
                AcroFields fields = pdfStamper.AcroFields;
                //fields.SetField("Customer", Config_Nome_Cli);
                //string sw_txt = "LSWR" + tbox_Sw_name + tbox_Sw_version + tbox_Sw_frequency;
                //fields.SetField("Software", sw_txt);


                ////Master Output
                //for (int i = 0; i < 14; i++)
                //{
                //    if ((Config_Tipo_Cntrl == "CTRL8") && (i > 5))
                //        break;

                //    string uscita = Config_Outputs.Substring(i, 1);
                //    if (uscita == "T")
                //    {
                //        int valorecampo = i + 1;
                //        string campo = "Out_" + valorecampo.ToString();
                //        fields.SetField(campo, "1");
                //    }
                //}
                ////Maintened-Latched
                //for (int i = 0; i < 14; i++)
                //{
                //    if ((Config_Tipo_Cntrl == "CTRL8") && (i > 5))
                //        break;

                //    string uscita = Config_LM.Substring(i, 1);
                //    if (uscita == "M")
                //    {
                //        int valorecampo = i + 1;
                //        string campo = "M_Out" + valorecampo.ToString();
                //        fields.SetField(campo, "M");
                //    }
                //    if (uscita == "L")
                //    {
                //        int valorecampo = i + 1;
                //        string campo = "L_Out" + valorecampo.ToString();
                //        fields.SetField(campo, "L");
                //    }
                //}

                ////TimeOut
                //fields.SetField("TimeOut", Config_TimeOut);

                //displaytext = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss") + " - Scrittura del file: " + Path.GetFileName(P_OutputStream) + "\n";
                //tb_Main.AppendText(displaytext);

                pdfStamper.Close();
                pdfReader.Close();
            }

        }

    }
}
