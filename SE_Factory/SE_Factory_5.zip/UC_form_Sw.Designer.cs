﻿namespace SE_Factory
{
    partial class UC_form_Sw
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_form_Sw));
            this.SW_pan_C = new MetroFramework.Controls.MetroPanel();
            this.C_sch_image = new System.Windows.Forms.PictureBox();
            this.lab_Des_Scheda_C = new MetroFramework.Controls.MetroLabel();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.ID_radio_868_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_433_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_915_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_toggle_Prop = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_CanBus = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_AntExt = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_GuidaLuce = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_TastEmerg = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_PlugPLE = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_PlugExp = new MetroFramework.Controls.MetroToggle();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.famProdSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.famProdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dB_FactoryDataSet = new SE_Factory.DB_FactoryDataSet();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.SW_pan_P = new MetroFramework.Controls.MetroPanel();
            this.pan_P_Sx = new MetroFramework.Controls.MetroPanel();
            this.pan_P_middle = new MetroFramework.Controls.MetroPanel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.metroToggle1 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle2 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle3 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle4 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle5 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle6 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle7 = new MetroFramework.Controls.MetroToggle();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.ID_radio_868_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_433_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_915_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_toggle_Fungo = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Torcia = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Vibracall = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Buzzer = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_SP = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Accel = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Display = new MetroFramework.Controls.MetroToggle();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.pan_P_top = new MetroFramework.Controls.MetroPanel();
            this.ID_lab_Palmare = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.grid_SchedeCompatibili = new MetroFramework.Controls.MetroGrid();
            this.SW_pan_Top = new MetroFramework.Controls.MetroPanel();
            this.pan_top_Dx = new MetroFramework.Controls.MetroPanel();
            this.pan_top_Dx_2 = new MetroFramework.Controls.MetroPanel();
            this.grid_SW_codificati = new MetroFramework.Controls.MetroGrid();
            this.sWCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SW_Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famProdSoftwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pan_top_Dx_1 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.pan_top_Sx = new MetroFramework.Controls.MetroPanel();
            this.SW_lab_Famiglia = new MetroFramework.Controls.MetroLabel();
            this.ID_combo_Famiglia = new System.Windows.Forms.ComboBox();
            this.SW_lab_codice_SW = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.tbox_Sw_name = new System.Windows.Forms.MaskedTextBox();
            this.tbox_Sw_version = new System.Windows.Forms.MaskedTextBox();
            this.tbox_Sw_frequency = new System.Windows.Forms.MaskedTextBox();
            this.pan_top_top = new MetroFramework.Controls.MetroPanel();
            this.titolo_ID = new MetroFramework.Controls.MetroLabel();
            this.SW_pan_bottom = new MetroFramework.Controls.MetroPanel();
            this.bt_Home = new MetroFramework.Controls.MetroTile();
            this.fam_ProdTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter();
            this.schedeTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SchedeTableAdapter();
            this.softwareTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SoftwareTableAdapter();
            this.prodSch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodDescrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SchedaCompatibile = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pan_P_Dx = new MetroFramework.Controls.MetroPanel();
            this.pan_P_Dx_revisioni = new MetroFramework.Controls.MetroPanel();
            this.metroContextMenu1 = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.pan_P_Dx_Funzionamento = new MetroFramework.Controls.MetroPanel();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.metroLabel32 = new MetroFramework.Controls.MetroLabel();
            this.rev_top = new MetroFramework.Controls.MetroPanel();
            this.rev_fill = new MetroFramework.Controls.MetroPanel();
            this.metroLabel33 = new MetroFramework.Controls.MetroLabel();
            this.funz_top = new MetroFramework.Controls.MetroPanel();
            this.funz_fill = new MetroFramework.Controls.MetroPanel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.SW_pan_C.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.C_sch_image)).BeginInit();
            this.metroPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).BeginInit();
            this.SW_pan_P.SuspendLayout();
            this.pan_P_Sx.SuspendLayout();
            this.pan_P_middle.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            this.pan_P_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SchedeCompatibili)).BeginInit();
            this.SW_pan_Top.SuspendLayout();
            this.pan_top_Dx.SuspendLayout();
            this.pan_top_Dx_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SW_codificati)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSoftwareBindingSource)).BeginInit();
            this.pan_top_Dx_1.SuspendLayout();
            this.pan_top_Sx.SuspendLayout();
            this.pan_top_top.SuspendLayout();
            this.SW_pan_bottom.SuspendLayout();
            this.pan_P_Dx.SuspendLayout();
            this.pan_P_Dx_revisioni.SuspendLayout();
            this.pan_P_Dx_Funzionamento.SuspendLayout();
            this.rev_top.SuspendLayout();
            this.rev_fill.SuspendLayout();
            this.funz_top.SuspendLayout();
            this.funz_fill.SuspendLayout();
            this.SuspendLayout();
            // 
            // SW_pan_C
            // 
            this.SW_pan_C.BackColor = System.Drawing.SystemColors.Window;
            this.SW_pan_C.Controls.Add(this.C_sch_image);
            this.SW_pan_C.Controls.Add(this.lab_Des_Scheda_C);
            this.SW_pan_C.Controls.Add(this.metroPanel3);
            this.SW_pan_C.Controls.Add(this.ID_toggle_Prop);
            this.SW_pan_C.Controls.Add(this.ID_toggle_CanBus);
            this.SW_pan_C.Controls.Add(this.ID_toggle_AntExt);
            this.SW_pan_C.Controls.Add(this.ID_toggle_GuidaLuce);
            this.SW_pan_C.Controls.Add(this.ID_toggle_TastEmerg);
            this.SW_pan_C.Controls.Add(this.ID_toggle_PlugPLE);
            this.SW_pan_C.Controls.Add(this.ID_toggle_PlugExp);
            this.SW_pan_C.Controls.Add(this.metroLabel11);
            this.SW_pan_C.Controls.Add(this.metroLabel12);
            this.SW_pan_C.Controls.Add(this.metroLabel13);
            this.SW_pan_C.Controls.Add(this.metroLabel14);
            this.SW_pan_C.Controls.Add(this.metroLabel15);
            this.SW_pan_C.Controls.Add(this.metroLabel16);
            this.SW_pan_C.Controls.Add(this.metroLabel17);
            this.SW_pan_C.Controls.Add(this.metroLabel18);
            this.SW_pan_C.Controls.Add(this.label1);
            this.SW_pan_C.Controls.Add(this.comboBox1);
            this.SW_pan_C.Controls.Add(this.metroLabel19);
            this.SW_pan_C.Controls.Add(this.metroLabel20);
            this.SW_pan_C.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SW_pan_C.ForeColor = System.Drawing.SystemColors.Control;
            this.SW_pan_C.HorizontalScrollbarBarColor = true;
            this.SW_pan_C.HorizontalScrollbarHighlightOnWheel = false;
            this.SW_pan_C.HorizontalScrollbarSize = 10;
            this.SW_pan_C.Location = new System.Drawing.Point(0, 150);
            this.SW_pan_C.Name = "SW_pan_C";
            this.SW_pan_C.Size = new System.Drawing.Size(1126, 415);
            this.SW_pan_C.TabIndex = 8;
            this.SW_pan_C.UseCustomBackColor = true;
            this.SW_pan_C.VerticalScrollbarBarColor = true;
            this.SW_pan_C.VerticalScrollbarHighlightOnWheel = false;
            this.SW_pan_C.VerticalScrollbarSize = 10;
            this.SW_pan_C.Visible = false;
            // 
            // C_sch_image
            // 
            this.C_sch_image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.C_sch_image.Dock = System.Windows.Forms.DockStyle.Right;
            this.C_sch_image.Location = new System.Drawing.Point(726, 0);
            this.C_sch_image.Name = "C_sch_image";
            this.C_sch_image.Size = new System.Drawing.Size(400, 415);
            this.C_sch_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.C_sch_image.TabIndex = 40;
            this.C_sch_image.TabStop = false;
            // 
            // lab_Des_Scheda_C
            // 
            this.lab_Des_Scheda_C.AutoSize = true;
            this.lab_Des_Scheda_C.Location = new System.Drawing.Point(360, 31);
            this.lab_Des_Scheda_C.Name = "lab_Des_Scheda_C";
            this.lab_Des_Scheda_C.Size = new System.Drawing.Size(88, 19);
            this.lab_Des_Scheda_C.TabIndex = 37;
            this.lab_Des_Scheda_C.Text = "metroLabel21";
            // 
            // metroPanel3
            // 
            this.metroPanel3.Controls.Add(this.ID_radio_868_C);
            this.metroPanel3.Controls.Add(this.ID_radio_433_C);
            this.metroPanel3.Controls.Add(this.ID_radio_915_C);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(150, 63);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(170, 20);
            this.metroPanel3.TabIndex = 36;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // ID_radio_868_C
            // 
            this.ID_radio_868_C.AutoSize = true;
            this.ID_radio_868_C.Location = new System.Drawing.Point(0, 0);
            this.ID_radio_868_C.Name = "ID_radio_868_C";
            this.ID_radio_868_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_868_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_868_C.TabIndex = 32;
            this.ID_radio_868_C.Text = "868";
            this.ID_radio_868_C.UseCustomBackColor = true;
            this.ID_radio_868_C.UseSelectable = true;
            this.ID_radio_868_C.UseStyleColors = true;
            // 
            // ID_radio_433_C
            // 
            this.ID_radio_433_C.AutoSize = true;
            this.ID_radio_433_C.Location = new System.Drawing.Point(120, 0);
            this.ID_radio_433_C.Name = "ID_radio_433_C";
            this.ID_radio_433_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_433_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_433_C.TabIndex = 34;
            this.ID_radio_433_C.Text = "433";
            this.ID_radio_433_C.UseCustomBackColor = true;
            this.ID_radio_433_C.UseSelectable = true;
            this.ID_radio_433_C.UseStyleColors = true;
            // 
            // ID_radio_915_C
            // 
            this.ID_radio_915_C.AutoSize = true;
            this.ID_radio_915_C.Location = new System.Drawing.Point(60, 0);
            this.ID_radio_915_C.Name = "ID_radio_915_C";
            this.ID_radio_915_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_915_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_915_C.TabIndex = 33;
            this.ID_radio_915_C.Text = "915";
            this.ID_radio_915_C.UseCustomBackColor = true;
            this.ID_radio_915_C.UseSelectable = true;
            this.ID_radio_915_C.UseStyleColors = true;
            // 
            // ID_toggle_Prop
            // 
            this.ID_toggle_Prop.AutoSize = true;
            this.ID_toggle_Prop.Location = new System.Drawing.Point(150, 270);
            this.ID_toggle_Prop.Name = "ID_toggle_Prop";
            this.ID_toggle_Prop.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Prop.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Prop.TabIndex = 28;
            this.ID_toggle_Prop.Text = "Off";
            this.ID_toggle_Prop.UseSelectable = true;
            // 
            // ID_toggle_CanBus
            // 
            this.ID_toggle_CanBus.AutoSize = true;
            this.ID_toggle_CanBus.Location = new System.Drawing.Point(150, 240);
            this.ID_toggle_CanBus.Name = "ID_toggle_CanBus";
            this.ID_toggle_CanBus.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_CanBus.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_CanBus.TabIndex = 27;
            this.ID_toggle_CanBus.Text = "Off";
            this.ID_toggle_CanBus.UseSelectable = true;
            // 
            // ID_toggle_AntExt
            // 
            this.ID_toggle_AntExt.AutoSize = true;
            this.ID_toggle_AntExt.Location = new System.Drawing.Point(150, 210);
            this.ID_toggle_AntExt.Name = "ID_toggle_AntExt";
            this.ID_toggle_AntExt.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_AntExt.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_AntExt.TabIndex = 26;
            this.ID_toggle_AntExt.Text = "Off";
            this.ID_toggle_AntExt.UseSelectable = true;
            // 
            // ID_toggle_GuidaLuce
            // 
            this.ID_toggle_GuidaLuce.AutoSize = true;
            this.ID_toggle_GuidaLuce.Location = new System.Drawing.Point(150, 180);
            this.ID_toggle_GuidaLuce.Name = "ID_toggle_GuidaLuce";
            this.ID_toggle_GuidaLuce.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_GuidaLuce.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_GuidaLuce.TabIndex = 25;
            this.ID_toggle_GuidaLuce.Text = "Off";
            this.ID_toggle_GuidaLuce.UseSelectable = true;
            // 
            // ID_toggle_TastEmerg
            // 
            this.ID_toggle_TastEmerg.AutoSize = true;
            this.ID_toggle_TastEmerg.Location = new System.Drawing.Point(150, 150);
            this.ID_toggle_TastEmerg.Name = "ID_toggle_TastEmerg";
            this.ID_toggle_TastEmerg.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_TastEmerg.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_TastEmerg.TabIndex = 24;
            this.ID_toggle_TastEmerg.Text = "Off";
            this.ID_toggle_TastEmerg.UseSelectable = true;
            // 
            // ID_toggle_PlugPLE
            // 
            this.ID_toggle_PlugPLE.AutoSize = true;
            this.ID_toggle_PlugPLE.Location = new System.Drawing.Point(150, 120);
            this.ID_toggle_PlugPLE.Name = "ID_toggle_PlugPLE";
            this.ID_toggle_PlugPLE.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_PlugPLE.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_PlugPLE.TabIndex = 23;
            this.ID_toggle_PlugPLE.Text = "Off";
            this.ID_toggle_PlugPLE.UseSelectable = true;
            // 
            // ID_toggle_PlugExp
            // 
            this.ID_toggle_PlugExp.AutoSize = true;
            this.ID_toggle_PlugExp.Checked = true;
            this.ID_toggle_PlugExp.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ID_toggle_PlugExp.Location = new System.Drawing.Point(150, 90);
            this.ID_toggle_PlugExp.Name = "ID_toggle_PlugExp";
            this.ID_toggle_PlugExp.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_PlugExp.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_PlugExp.TabIndex = 22;
            this.ID_toggle_PlugExp.Text = "On";
            this.ID_toggle_PlugExp.UseSelectable = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(5, 270);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(95, 19);
            this.metroLabel11.TabIndex = 20;
            this.metroLabel11.Text = "Proporzionale:";
            this.metroLabel11.UseCustomBackColor = true;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(5, 240);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(64, 19);
            this.metroLabel12.TabIndex = 19;
            this.metroLabel12.Text = "CAN Bus:";
            this.metroLabel12.UseCustomBackColor = true;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(5, 210);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(106, 19);
            this.metroLabel13.TabIndex = 18;
            this.metroLabel13.Text = "Antenna Esterna:";
            this.metroLabel13.UseCustomBackColor = true;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(5, 180);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(76, 19);
            this.metroLabel14.TabIndex = 17;
            this.metroLabel14.Text = "Guida Luce:";
            this.metroLabel14.UseCustomBackColor = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(5, 150);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(136, 19);
            this.metroLabel15.TabIndex = 16;
            this.metroLabel15.Text = "Tastiera d\'emergenza:";
            this.metroLabel15.UseCustomBackColor = true;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(5, 120);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(63, 19);
            this.metroLabel16.TabIndex = 15;
            this.metroLabel16.Text = "Plug PLE:";
            this.metroLabel16.UseCustomBackColor = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(5, 90);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(63, 19);
            this.metroLabel17.TabIndex = 14;
            this.metroLabel17.Text = "Plug Exp:";
            this.metroLabel17.UseCustomBackColor = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(5, 60);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(111, 19);
            this.metroLabel18.TabIndex = 13;
            this.metroLabel18.Text = "Frequenza Radio:";
            this.metroLabel18.UseCustomBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(160, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "label1";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.famProdSchedeBindingSource;
            this.comboBox1.DisplayMember = "Prod_Sch";
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 15;
            this.comboBox1.Location = new System.Drawing.Point(150, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 23);
            this.comboBox1.TabIndex = 11;
            // 
            // famProdSchedeBindingSource
            // 
            this.famProdSchedeBindingSource.DataMember = "Fam_Prod_Schede";
            this.famProdSchedeBindingSource.DataSource = this.famProdBindingSource;
            // 
            // famProdBindingSource
            // 
            this.famProdBindingSource.DataMember = "Fam_Prod";
            this.famProdBindingSource.DataSource = this.dB_FactoryDataSet;
            this.famProdBindingSource.CurrentChanged += new System.EventHandler(this.famProdBindingSource_CurrentChanged);
            // 
            // dB_FactoryDataSet
            // 
            this.dB_FactoryDataSet.DataSetName = "DB_FactoryDataSet";
            this.dB_FactoryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(5, 30);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(108, 19);
            this.metroLabel19.TabIndex = 9;
            this.metroLabel19.Text = "Scheda utilizzata:";
            this.metroLabel19.UseCustomBackColor = true;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel20.Location = new System.Drawing.Point(0, 0);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(90, 25);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel20.TabIndex = 7;
            this.metroLabel20.Text = "Controller";
            this.metroLabel20.UseCustomBackColor = true;
            this.metroLabel20.UseStyleColors = true;
            // 
            // SW_pan_P
            // 
            this.SW_pan_P.BackColor = System.Drawing.SystemColors.Window;
            this.SW_pan_P.Controls.Add(this.pan_P_Dx);
            this.SW_pan_P.Controls.Add(this.pan_P_Sx);
            this.SW_pan_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SW_pan_P.ForeColor = System.Drawing.SystemColors.Control;
            this.SW_pan_P.HorizontalScrollbarBarColor = true;
            this.SW_pan_P.HorizontalScrollbarHighlightOnWheel = false;
            this.SW_pan_P.HorizontalScrollbarSize = 10;
            this.SW_pan_P.Location = new System.Drawing.Point(0, 150);
            this.SW_pan_P.Name = "SW_pan_P";
            this.SW_pan_P.Size = new System.Drawing.Size(1126, 415);
            this.SW_pan_P.TabIndex = 5;
            this.SW_pan_P.UseCustomBackColor = true;
            this.SW_pan_P.VerticalScrollbarBarColor = true;
            this.SW_pan_P.VerticalScrollbarHighlightOnWheel = false;
            this.SW_pan_P.VerticalScrollbarSize = 10;
            this.SW_pan_P.Visible = false;
            // 
            // pan_P_Sx
            // 
            this.pan_P_Sx.Controls.Add(this.pan_P_middle);
            this.pan_P_Sx.Controls.Add(this.pan_P_top);
            this.pan_P_Sx.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_P_Sx.HorizontalScrollbarBarColor = true;
            this.pan_P_Sx.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Sx.HorizontalScrollbarSize = 10;
            this.pan_P_Sx.Location = new System.Drawing.Point(0, 0);
            this.pan_P_Sx.Name = "pan_P_Sx";
            this.pan_P_Sx.Size = new System.Drawing.Size(700, 415);
            this.pan_P_Sx.TabIndex = 53;
            this.pan_P_Sx.VerticalScrollbarBarColor = true;
            this.pan_P_Sx.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Sx.VerticalScrollbarSize = 10;
            // 
            // pan_P_middle
            // 
            this.pan_P_middle.Controls.Add(this.metroButton1);
            this.pan_P_middle.Controls.Add(this.metroTextBox1);
            this.pan_P_middle.Controls.Add(this.metroLabel30);
            this.pan_P_middle.Controls.Add(this.metroToggle1);
            this.pan_P_middle.Controls.Add(this.metroToggle2);
            this.pan_P_middle.Controls.Add(this.metroToggle3);
            this.pan_P_middle.Controls.Add(this.metroToggle4);
            this.pan_P_middle.Controls.Add(this.metroToggle5);
            this.pan_P_middle.Controls.Add(this.metroToggle6);
            this.pan_P_middle.Controls.Add(this.metroToggle7);
            this.pan_P_middle.Controls.Add(this.metroLabel23);
            this.pan_P_middle.Controls.Add(this.metroLabel24);
            this.pan_P_middle.Controls.Add(this.metroLabel25);
            this.pan_P_middle.Controls.Add(this.metroLabel26);
            this.pan_P_middle.Controls.Add(this.metroLabel27);
            this.pan_P_middle.Controls.Add(this.metroLabel28);
            this.pan_P_middle.Controls.Add(this.metroLabel29);
            this.pan_P_middle.Controls.Add(this.metroPanel1);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Fungo);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Torcia);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Vibracall);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Buzzer);
            this.pan_P_middle.Controls.Add(this.ID_toggle_SP);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Accel);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Display);
            this.pan_P_middle.Controls.Add(this.metroLabel9);
            this.pan_P_middle.Controls.Add(this.metroLabel8);
            this.pan_P_middle.Controls.Add(this.metroLabel7);
            this.pan_P_middle.Controls.Add(this.metroLabel6);
            this.pan_P_middle.Controls.Add(this.metroLabel5);
            this.pan_P_middle.Controls.Add(this.metroLabel4);
            this.pan_P_middle.Controls.Add(this.metroLabel3);
            this.pan_P_middle.Controls.Add(this.metroLabel2);
            this.pan_P_middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_middle.HorizontalScrollbarBarColor = true;
            this.pan_P_middle.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_middle.HorizontalScrollbarSize = 10;
            this.pan_P_middle.Location = new System.Drawing.Point(0, 160);
            this.pan_P_middle.Name = "pan_P_middle";
            this.pan_P_middle.Size = new System.Drawing.Size(700, 255);
            this.pan_P_middle.TabIndex = 42;
            this.pan_P_middle.VerticalScrollbarBarColor = true;
            this.pan_P_middle.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_middle.VerticalScrollbarSize = 10;
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[] {
        "metroTextBox1"};
            this.metroTextBox1.Location = new System.Drawing.Point(401, 185);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox1.TabIndex = 52;
            this.metroTextBox1.Text = "metroTextBox1";
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.Location = new System.Drawing.Point(251, 185);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(139, 19);
            this.metroLabel30.TabIndex = 51;
            this.metroLabel30.Text = "MAX pairable devices:";
            this.metroLabel30.UseCustomBackColor = true;
            // 
            // metroToggle1
            // 
            this.metroToggle1.AutoSize = true;
            this.metroToggle1.Location = new System.Drawing.Point(396, 165);
            this.metroToggle1.Name = "metroToggle1";
            this.metroToggle1.Size = new System.Drawing.Size(80, 17);
            this.metroToggle1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle1.TabIndex = 50;
            this.metroToggle1.Text = "Off";
            this.metroToggle1.UseSelectable = true;
            // 
            // metroToggle2
            // 
            this.metroToggle2.AutoSize = true;
            this.metroToggle2.Location = new System.Drawing.Point(396, 125);
            this.metroToggle2.Name = "metroToggle2";
            this.metroToggle2.Size = new System.Drawing.Size(80, 17);
            this.metroToggle2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle2.TabIndex = 49;
            this.metroToggle2.Text = "Off";
            this.metroToggle2.UseSelectable = true;
            // 
            // metroToggle3
            // 
            this.metroToggle3.AutoSize = true;
            this.metroToggle3.Location = new System.Drawing.Point(396, 105);
            this.metroToggle3.Name = "metroToggle3";
            this.metroToggle3.Size = new System.Drawing.Size(80, 17);
            this.metroToggle3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle3.TabIndex = 48;
            this.metroToggle3.Text = "Off";
            this.metroToggle3.UseSelectable = true;
            // 
            // metroToggle4
            // 
            this.metroToggle4.AutoSize = true;
            this.metroToggle4.Location = new System.Drawing.Point(396, 85);
            this.metroToggle4.Name = "metroToggle4";
            this.metroToggle4.Size = new System.Drawing.Size(80, 17);
            this.metroToggle4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle4.TabIndex = 47;
            this.metroToggle4.Text = "Off";
            this.metroToggle4.UseSelectable = true;
            // 
            // metroToggle5
            // 
            this.metroToggle5.AutoSize = true;
            this.metroToggle5.Location = new System.Drawing.Point(396, 65);
            this.metroToggle5.Name = "metroToggle5";
            this.metroToggle5.Size = new System.Drawing.Size(80, 17);
            this.metroToggle5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle5.TabIndex = 46;
            this.metroToggle5.Text = "Off";
            this.metroToggle5.UseSelectable = true;
            // 
            // metroToggle6
            // 
            this.metroToggle6.AutoSize = true;
            this.metroToggle6.Location = new System.Drawing.Point(396, 45);
            this.metroToggle6.Name = "metroToggle6";
            this.metroToggle6.Size = new System.Drawing.Size(80, 17);
            this.metroToggle6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle6.TabIndex = 45;
            this.metroToggle6.Text = "Off";
            this.metroToggle6.UseSelectable = true;
            // 
            // metroToggle7
            // 
            this.metroToggle7.AutoSize = true;
            this.metroToggle7.Location = new System.Drawing.Point(396, 25);
            this.metroToggle7.Name = "metroToggle7";
            this.metroToggle7.Size = new System.Drawing.Size(80, 17);
            this.metroToggle7.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle7.TabIndex = 44;
            this.metroToggle7.Text = "Off";
            this.metroToggle7.UseSelectable = true;
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.Location = new System.Drawing.Point(251, 165);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(102, 19);
            this.metroLabel23.TabIndex = 43;
            this.metroLabel23.Text = "Cambio Pagina:";
            this.metroLabel23.UseCustomBackColor = true;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(251, 125);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(71, 19);
            this.metroLabel24.TabIndex = 42;
            this.metroLabel24.Text = "Usa Torcia:";
            this.metroLabel24.UseCustomBackColor = true;
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(251, 105);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(87, 19);
            this.metroLabel25.TabIndex = 41;
            this.metroLabel25.Text = "Usa Vibracall:";
            this.metroLabel25.UseCustomBackColor = true;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(251, 85);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(77, 19);
            this.metroLabel26.TabIndex = 40;
            this.metroLabel26.Text = "Usa Buzzer:";
            this.metroLabel26.UseCustomBackColor = true;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.Location = new System.Drawing.Point(251, 65);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(105, 19);
            this.metroLabel27.TabIndex = 39;
            this.metroLabel27.Text = "Usa Safety Point:";
            this.metroLabel27.UseCustomBackColor = true;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.Location = new System.Drawing.Point(251, 45);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(124, 19);
            this.metroLabel28.TabIndex = 38;
            this.metroLabel28.Text = "Usa Accelerometro:";
            this.metroLabel28.UseCustomBackColor = true;
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(251, 25);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(89, 19);
            this.metroLabel29.TabIndex = 37;
            this.metroLabel29.Text = "Use Backlight:";
            this.metroLabel29.UseCustomBackColor = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.ID_radio_868_P);
            this.metroPanel1.Controls.Add(this.ID_radio_433_P);
            this.metroPanel1.Controls.Add(this.ID_radio_915_P);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(150, 8);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(170, 16);
            this.metroPanel1.TabIndex = 36;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // ID_radio_868_P
            // 
            this.ID_radio_868_P.AutoSize = true;
            this.ID_radio_868_P.Location = new System.Drawing.Point(0, 0);
            this.ID_radio_868_P.Name = "ID_radio_868_P";
            this.ID_radio_868_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_868_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_868_P.TabIndex = 32;
            this.ID_radio_868_P.Text = "868";
            this.ID_radio_868_P.UseCustomBackColor = true;
            this.ID_radio_868_P.UseSelectable = true;
            this.ID_radio_868_P.UseStyleColors = true;
            // 
            // ID_radio_433_P
            // 
            this.ID_radio_433_P.AutoSize = true;
            this.ID_radio_433_P.Location = new System.Drawing.Point(120, 0);
            this.ID_radio_433_P.Name = "ID_radio_433_P";
            this.ID_radio_433_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_433_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_433_P.TabIndex = 34;
            this.ID_radio_433_P.Text = "433";
            this.ID_radio_433_P.UseCustomBackColor = true;
            this.ID_radio_433_P.UseSelectable = true;
            this.ID_radio_433_P.UseStyleColors = true;
            // 
            // ID_radio_915_P
            // 
            this.ID_radio_915_P.AutoSize = true;
            this.ID_radio_915_P.Location = new System.Drawing.Point(60, 0);
            this.ID_radio_915_P.Name = "ID_radio_915_P";
            this.ID_radio_915_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_915_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_915_P.TabIndex = 33;
            this.ID_radio_915_P.Text = "915";
            this.ID_radio_915_P.UseCustomBackColor = true;
            this.ID_radio_915_P.UseSelectable = true;
            this.ID_radio_915_P.UseStyleColors = true;
            // 
            // ID_toggle_Fungo
            // 
            this.ID_toggle_Fungo.AutoSize = true;
            this.ID_toggle_Fungo.Location = new System.Drawing.Point(150, 145);
            this.ID_toggle_Fungo.Name = "ID_toggle_Fungo";
            this.ID_toggle_Fungo.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Fungo.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Fungo.TabIndex = 28;
            this.ID_toggle_Fungo.Text = "Off";
            this.ID_toggle_Fungo.UseSelectable = true;
            // 
            // ID_toggle_Torcia
            // 
            this.ID_toggle_Torcia.AutoSize = true;
            this.ID_toggle_Torcia.Location = new System.Drawing.Point(150, 125);
            this.ID_toggle_Torcia.Name = "ID_toggle_Torcia";
            this.ID_toggle_Torcia.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Torcia.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Torcia.TabIndex = 27;
            this.ID_toggle_Torcia.Text = "Off";
            this.ID_toggle_Torcia.UseSelectable = true;
            // 
            // ID_toggle_Vibracall
            // 
            this.ID_toggle_Vibracall.AutoSize = true;
            this.ID_toggle_Vibracall.Location = new System.Drawing.Point(150, 105);
            this.ID_toggle_Vibracall.Name = "ID_toggle_Vibracall";
            this.ID_toggle_Vibracall.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Vibracall.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Vibracall.TabIndex = 26;
            this.ID_toggle_Vibracall.Text = "Off";
            this.ID_toggle_Vibracall.UseSelectable = true;
            // 
            // ID_toggle_Buzzer
            // 
            this.ID_toggle_Buzzer.AutoSize = true;
            this.ID_toggle_Buzzer.Location = new System.Drawing.Point(150, 85);
            this.ID_toggle_Buzzer.Name = "ID_toggle_Buzzer";
            this.ID_toggle_Buzzer.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Buzzer.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Buzzer.TabIndex = 25;
            this.ID_toggle_Buzzer.Text = "Off";
            this.ID_toggle_Buzzer.UseSelectable = true;
            // 
            // ID_toggle_SP
            // 
            this.ID_toggle_SP.AutoSize = true;
            this.ID_toggle_SP.Location = new System.Drawing.Point(150, 65);
            this.ID_toggle_SP.Name = "ID_toggle_SP";
            this.ID_toggle_SP.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_SP.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_SP.TabIndex = 24;
            this.ID_toggle_SP.Text = "Off";
            this.ID_toggle_SP.UseSelectable = true;
            // 
            // ID_toggle_Accel
            // 
            this.ID_toggle_Accel.AutoSize = true;
            this.ID_toggle_Accel.Location = new System.Drawing.Point(150, 45);
            this.ID_toggle_Accel.Name = "ID_toggle_Accel";
            this.ID_toggle_Accel.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Accel.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Accel.TabIndex = 23;
            this.ID_toggle_Accel.Text = "Off";
            this.ID_toggle_Accel.UseSelectable = true;
            // 
            // ID_toggle_Display
            // 
            this.ID_toggle_Display.AutoSize = true;
            this.ID_toggle_Display.Location = new System.Drawing.Point(150, 25);
            this.ID_toggle_Display.Name = "ID_toggle_Display";
            this.ID_toggle_Display.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Display.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Display.TabIndex = 22;
            this.ID_toggle_Display.Text = "Off";
            this.ID_toggle_Display.UseSelectable = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(5, 145);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(119, 19);
            this.metroLabel9.TabIndex = 20;
            this.metroLabel9.Text = "Fungo Emergenza:";
            this.metroLabel9.UseCustomBackColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(5, 125);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(46, 19);
            this.metroLabel8.TabIndex = 19;
            this.metroLabel8.Text = "Torcia:";
            this.metroLabel8.UseCustomBackColor = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(5, 105);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(62, 19);
            this.metroLabel7.TabIndex = 18;
            this.metroLabel7.Text = "Vibracall:";
            this.metroLabel7.UseCustomBackColor = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(5, 85);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(52, 19);
            this.metroLabel6.TabIndex = 17;
            this.metroLabel6.Text = "Buzzer:";
            this.metroLabel6.UseCustomBackColor = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(5, 65);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(80, 19);
            this.metroLabel5.TabIndex = 16;
            this.metroLabel5.Text = "Safety Point:";
            this.metroLabel5.UseCustomBackColor = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(5, 45);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(99, 19);
            this.metroLabel4.TabIndex = 15;
            this.metroLabel4.Text = "Accelerometro:";
            this.metroLabel4.UseCustomBackColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(5, 25);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(86, 19);
            this.metroLabel3.TabIndex = 14;
            this.metroLabel3.Text = "Display Oled:";
            this.metroLabel3.UseCustomBackColor = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(5, 5);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(111, 19);
            this.metroLabel2.TabIndex = 13;
            this.metroLabel2.Text = "Frequenza Radio:";
            this.metroLabel2.UseCustomBackColor = true;
            // 
            // pan_P_top
            // 
            this.pan_P_top.BackColor = System.Drawing.Color.White;
            this.pan_P_top.Controls.Add(this.ID_lab_Palmare);
            this.pan_P_top.Controls.Add(this.metroLabel1);
            this.pan_P_top.Controls.Add(this.grid_SchedeCompatibili);
            this.pan_P_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_P_top.HorizontalScrollbarBarColor = true;
            this.pan_P_top.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_top.HorizontalScrollbarSize = 10;
            this.pan_P_top.Location = new System.Drawing.Point(0, 0);
            this.pan_P_top.Name = "pan_P_top";
            this.pan_P_top.Size = new System.Drawing.Size(700, 160);
            this.pan_P_top.TabIndex = 41;
            this.pan_P_top.VerticalScrollbarBarColor = true;
            this.pan_P_top.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_top.VerticalScrollbarSize = 10;
            // 
            // ID_lab_Palmare
            // 
            this.ID_lab_Palmare.AutoSize = true;
            this.ID_lab_Palmare.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.ID_lab_Palmare.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.ID_lab_Palmare.Location = new System.Drawing.Point(0, 0);
            this.ID_lab_Palmare.Name = "ID_lab_Palmare";
            this.ID_lab_Palmare.Size = new System.Drawing.Size(74, 25);
            this.ID_lab_Palmare.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_lab_Palmare.TabIndex = 7;
            this.ID_lab_Palmare.Text = "Palmare";
            this.ID_lab_Palmare.UseCustomBackColor = true;
            this.ID_lab_Palmare.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(5, 30);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(108, 19);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Scheda utilizzata:";
            this.metroLabel1.UseCustomBackColor = true;
            // 
            // grid_SchedeCompatibili
            // 
            this.grid_SchedeCompatibili.AllowUserToAddRows = false;
            this.grid_SchedeCompatibili.AllowUserToDeleteRows = false;
            this.grid_SchedeCompatibili.AllowUserToResizeRows = false;
            this.grid_SchedeCompatibili.AutoGenerateColumns = false;
            this.grid_SchedeCompatibili.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid_SchedeCompatibili.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SchedeCompatibili.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_SchedeCompatibili.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_SchedeCompatibili.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SchedeCompatibili.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.grid_SchedeCompatibili.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_SchedeCompatibili.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodSch,
            this.prodDescrizione,
            this.SchedaCompatibile});
            this.grid_SchedeCompatibili.DataSource = this.famProdSchedeBindingSource;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_SchedeCompatibili.DefaultCellStyle = dataGridViewCellStyle26;
            this.grid_SchedeCompatibili.EnableHeadersVisualStyles = false;
            this.grid_SchedeCompatibili.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_SchedeCompatibili.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SchedeCompatibili.Location = new System.Drawing.Point(150, 31);
            this.grid_SchedeCompatibili.Name = "grid_SchedeCompatibili";
            this.grid_SchedeCompatibili.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SchedeCompatibili.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.grid_SchedeCompatibili.RowHeadersVisible = false;
            this.grid_SchedeCompatibili.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_SchedeCompatibili.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_SchedeCompatibili.Size = new System.Drawing.Size(537, 126);
            this.grid_SchedeCompatibili.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_SchedeCompatibili.TabIndex = 40;
            this.grid_SchedeCompatibili.UseCustomBackColor = true;
            this.grid_SchedeCompatibili.UseStyleColors = true;
            this.grid_SchedeCompatibili.Validated += new System.EventHandler(this.grid_SchedeCompatibili_Validated);
            // 
            // SW_pan_Top
            // 
            this.SW_pan_Top.Controls.Add(this.pan_top_Dx);
            this.SW_pan_Top.Controls.Add(this.pan_top_Sx);
            this.SW_pan_Top.Controls.Add(this.pan_top_top);
            this.SW_pan_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.SW_pan_Top.HorizontalScrollbarBarColor = true;
            this.SW_pan_Top.HorizontalScrollbarHighlightOnWheel = false;
            this.SW_pan_Top.HorizontalScrollbarSize = 10;
            this.SW_pan_Top.Location = new System.Drawing.Point(0, 0);
            this.SW_pan_Top.Name = "SW_pan_Top";
            this.SW_pan_Top.Size = new System.Drawing.Size(1126, 150);
            this.SW_pan_Top.TabIndex = 4;
            this.SW_pan_Top.UseCustomBackColor = true;
            this.SW_pan_Top.VerticalScrollbarBarColor = true;
            this.SW_pan_Top.VerticalScrollbarHighlightOnWheel = false;
            this.SW_pan_Top.VerticalScrollbarSize = 10;
            // 
            // pan_top_Dx
            // 
            this.pan_top_Dx.Controls.Add(this.pan_top_Dx_2);
            this.pan_top_Dx.Controls.Add(this.pan_top_Dx_1);
            this.pan_top_Dx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_top_Dx.HorizontalScrollbarBarColor = true;
            this.pan_top_Dx.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_top_Dx.HorizontalScrollbarSize = 10;
            this.pan_top_Dx.Location = new System.Drawing.Point(400, 22);
            this.pan_top_Dx.Name = "pan_top_Dx";
            this.pan_top_Dx.Size = new System.Drawing.Size(726, 128);
            this.pan_top_Dx.TabIndex = 16;
            this.pan_top_Dx.VerticalScrollbarBarColor = true;
            this.pan_top_Dx.VerticalScrollbarHighlightOnWheel = false;
            this.pan_top_Dx.VerticalScrollbarSize = 10;
            // 
            // pan_top_Dx_2
            // 
            this.pan_top_Dx_2.Controls.Add(this.grid_SW_codificati);
            this.pan_top_Dx_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_top_Dx_2.HorizontalScrollbarBarColor = true;
            this.pan_top_Dx_2.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_top_Dx_2.HorizontalScrollbarSize = 10;
            this.pan_top_Dx_2.Location = new System.Drawing.Point(140, 0);
            this.pan_top_Dx_2.Name = "pan_top_Dx_2";
            this.pan_top_Dx_2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.pan_top_Dx_2.Size = new System.Drawing.Size(586, 128);
            this.pan_top_Dx_2.TabIndex = 17;
            this.pan_top_Dx_2.UseCustomBackColor = true;
            this.pan_top_Dx_2.VerticalScrollbarBarColor = true;
            this.pan_top_Dx_2.VerticalScrollbarHighlightOnWheel = false;
            this.pan_top_Dx_2.VerticalScrollbarSize = 10;
            // 
            // grid_SW_codificati
            // 
            this.grid_SW_codificati.AllowUserToAddRows = false;
            this.grid_SW_codificati.AllowUserToDeleteRows = false;
            this.grid_SW_codificati.AllowUserToResizeRows = false;
            this.grid_SW_codificati.AutoGenerateColumns = false;
            this.grid_SW_codificati.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid_SW_codificati.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SW_codificati.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_SW_codificati.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_SW_codificati.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(18)))), ((int)(((byte)(69)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SW_codificati.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.grid_SW_codificati.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_SW_codificati.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sWCodeDataGridViewTextBoxColumn,
            this.SW_Customer});
            this.grid_SW_codificati.DataSource = this.famProdSoftwareBindingSource;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(18)))), ((int)(((byte)(69)))));
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_SW_codificati.DefaultCellStyle = dataGridViewCellStyle29;
            this.grid_SW_codificati.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_SW_codificati.EnableHeadersVisualStyles = false;
            this.grid_SW_codificati.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_SW_codificati.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SW_codificati.HighLightPercentage = 0.1F;
            this.grid_SW_codificati.Location = new System.Drawing.Point(0, 10);
            this.grid_SW_codificati.Name = "grid_SW_codificati";
            this.grid_SW_codificati.ReadOnly = true;
            this.grid_SW_codificati.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(18)))), ((int)(((byte)(69)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SW_codificati.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.grid_SW_codificati.RowHeadersVisible = false;
            this.grid_SW_codificati.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_SW_codificati.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_SW_codificati.Size = new System.Drawing.Size(586, 118);
            this.grid_SW_codificati.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_SW_codificati.TabIndex = 15;
            this.grid_SW_codificati.UseStyleColors = true;
            // 
            // sWCodeDataGridViewTextBoxColumn
            // 
            this.sWCodeDataGridViewTextBoxColumn.DataPropertyName = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn.HeaderText = "Codice SW";
            this.sWCodeDataGridViewTextBoxColumn.Name = "sWCodeDataGridViewTextBoxColumn";
            this.sWCodeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // SW_Customer
            // 
            this.SW_Customer.DataPropertyName = "SW_Customer";
            this.SW_Customer.HeaderText = "Cliente";
            this.SW_Customer.Name = "SW_Customer";
            this.SW_Customer.ReadOnly = true;
            // 
            // famProdSoftwareBindingSource
            // 
            this.famProdSoftwareBindingSource.DataMember = "Fam_Prod_Software";
            this.famProdSoftwareBindingSource.DataSource = this.famProdBindingSource;
            // 
            // pan_top_Dx_1
            // 
            this.pan_top_Dx_1.Controls.Add(this.metroLabel22);
            this.pan_top_Dx_1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_top_Dx_1.HorizontalScrollbarBarColor = true;
            this.pan_top_Dx_1.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_top_Dx_1.HorizontalScrollbarSize = 10;
            this.pan_top_Dx_1.Location = new System.Drawing.Point(0, 0);
            this.pan_top_Dx_1.Name = "pan_top_Dx_1";
            this.pan_top_Dx_1.Size = new System.Drawing.Size(140, 128);
            this.pan_top_Dx_1.TabIndex = 16;
            this.pan_top_Dx_1.UseCustomBackColor = true;
            this.pan_top_Dx_1.VerticalScrollbarBarColor = true;
            this.pan_top_Dx_1.VerticalScrollbarHighlightOnWheel = false;
            this.pan_top_Dx_1.VerticalScrollbarSize = 10;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.Location = new System.Drawing.Point(0, 10);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(141, 19);
            this.metroLabel22.TabIndex = 13;
            this.metroLabel22.Text = "Software già codificati:";
            this.metroLabel22.UseCustomBackColor = true;
            // 
            // pan_top_Sx
            // 
            this.pan_top_Sx.Controls.Add(this.SW_lab_Famiglia);
            this.pan_top_Sx.Controls.Add(this.ID_combo_Famiglia);
            this.pan_top_Sx.Controls.Add(this.SW_lab_codice_SW);
            this.pan_top_Sx.Controls.Add(this.metroLabel21);
            this.pan_top_Sx.Controls.Add(this.tbox_Sw_name);
            this.pan_top_Sx.Controls.Add(this.tbox_Sw_version);
            this.pan_top_Sx.Controls.Add(this.tbox_Sw_frequency);
            this.pan_top_Sx.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_top_Sx.HorizontalScrollbarBarColor = true;
            this.pan_top_Sx.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_top_Sx.HorizontalScrollbarSize = 10;
            this.pan_top_Sx.Location = new System.Drawing.Point(0, 22);
            this.pan_top_Sx.Name = "pan_top_Sx";
            this.pan_top_Sx.Size = new System.Drawing.Size(400, 128);
            this.pan_top_Sx.TabIndex = 17;
            this.pan_top_Sx.UseCustomBackColor = true;
            this.pan_top_Sx.VerticalScrollbarBarColor = true;
            this.pan_top_Sx.VerticalScrollbarHighlightOnWheel = false;
            this.pan_top_Sx.VerticalScrollbarSize = 10;
            // 
            // SW_lab_Famiglia
            // 
            this.SW_lab_Famiglia.AutoSize = true;
            this.SW_lab_Famiglia.Location = new System.Drawing.Point(5, 10);
            this.SW_lab_Famiglia.Name = "SW_lab_Famiglia";
            this.SW_lab_Famiglia.Size = new System.Drawing.Size(133, 19);
            this.SW_lab_Famiglia.TabIndex = 3;
            this.SW_lab_Famiglia.Text = "Famiglia di prodotto:";
            this.SW_lab_Famiglia.UseCustomBackColor = true;
            // 
            // ID_combo_Famiglia
            // 
            this.ID_combo_Famiglia.BackColor = System.Drawing.SystemColors.Window;
            this.ID_combo_Famiglia.DataSource = this.famProdBindingSource;
            this.ID_combo_Famiglia.DisplayMember = "Fam_Name";
            this.ID_combo_Famiglia.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ID_combo_Famiglia.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_combo_Famiglia.FormattingEnabled = true;
            this.ID_combo_Famiglia.ItemHeight = 15;
            this.ID_combo_Famiglia.Location = new System.Drawing.Point(150, 10);
            this.ID_combo_Famiglia.Name = "ID_combo_Famiglia";
            this.ID_combo_Famiglia.Size = new System.Drawing.Size(200, 23);
            this.ID_combo_Famiglia.TabIndex = 6;
            // 
            // SW_lab_codice_SW
            // 
            this.SW_lab_codice_SW.AutoSize = true;
            this.SW_lab_codice_SW.Location = new System.Drawing.Point(5, 40);
            this.SW_lab_codice_SW.Name = "SW_lab_codice_SW";
            this.SW_lab_codice_SW.Size = new System.Drawing.Size(108, 19);
            this.SW_lab_codice_SW.TabIndex = 7;
            this.SW_lab_codice_SW.Text = "Codice Software:";
            this.SW_lab_codice_SW.UseCustomBackColor = true;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel21.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel21.Location = new System.Drawing.Point(148, 40);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(47, 19);
            this.metroLabel21.TabIndex = 8;
            this.metroLabel21.Text = "LSWR";
            this.metroLabel21.UseCustomBackColor = true;
            // 
            // tbox_Sw_name
            // 
            this.tbox_Sw_name.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_name.Location = new System.Drawing.Point(196, 40);
            this.tbox_Sw_name.Mask = ">AAAAA";
            this.tbox_Sw_name.Name = "tbox_Sw_name";
            this.tbox_Sw_name.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_name.TabIndex = 10;
            this.tbox_Sw_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_name.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_name_Validating);
            // 
            // tbox_Sw_version
            // 
            this.tbox_Sw_version.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_version.Location = new System.Drawing.Point(251, 40);
            this.tbox_Sw_version.Mask = ">AAA";
            this.tbox_Sw_version.Name = "tbox_Sw_version";
            this.tbox_Sw_version.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_version.TabIndex = 11;
            this.tbox_Sw_version.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_version.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_version_Validating);
            // 
            // tbox_Sw_frequency
            // 
            this.tbox_Sw_frequency.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_frequency.Location = new System.Drawing.Point(306, 40);
            this.tbox_Sw_frequency.Mask = ">&";
            this.tbox_Sw_frequency.Name = "tbox_Sw_frequency";
            this.tbox_Sw_frequency.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_frequency.TabIndex = 12;
            this.tbox_Sw_frequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_frequency.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_frequency_Validating);
            // 
            // pan_top_top
            // 
            this.pan_top_top.Controls.Add(this.titolo_ID);
            this.pan_top_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_top_top.HorizontalScrollbarBarColor = true;
            this.pan_top_top.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_top_top.HorizontalScrollbarSize = 10;
            this.pan_top_top.Location = new System.Drawing.Point(0, 0);
            this.pan_top_top.Name = "pan_top_top";
            this.pan_top_top.Size = new System.Drawing.Size(1126, 22);
            this.pan_top_top.TabIndex = 18;
            this.pan_top_top.UseCustomBackColor = true;
            this.pan_top_top.VerticalScrollbarBarColor = true;
            this.pan_top_top.VerticalScrollbarHighlightOnWheel = false;
            this.pan_top_top.VerticalScrollbarSize = 10;
            // 
            // titolo_ID
            // 
            this.titolo_ID.AutoSize = true;
            this.titolo_ID.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.titolo_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.titolo_ID.Location = new System.Drawing.Point(0, 0);
            this.titolo_ID.Name = "titolo_ID";
            this.titolo_ID.Size = new System.Drawing.Size(166, 25);
            this.titolo_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.titolo_ID.TabIndex = 2;
            this.titolo_ID.Text = "Datasheet Software";
            this.titolo_ID.UseCustomBackColor = true;
            this.titolo_ID.UseStyleColors = true;
            // 
            // SW_pan_bottom
            // 
            this.SW_pan_bottom.BackColor = System.Drawing.Color.LightSteelBlue;
            this.SW_pan_bottom.Controls.Add(this.bt_Home);
            this.SW_pan_bottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.SW_pan_bottom.HorizontalScrollbarBarColor = true;
            this.SW_pan_bottom.HorizontalScrollbarHighlightOnWheel = false;
            this.SW_pan_bottom.HorizontalScrollbarSize = 10;
            this.SW_pan_bottom.Location = new System.Drawing.Point(0, 565);
            this.SW_pan_bottom.Name = "SW_pan_bottom";
            this.SW_pan_bottom.Size = new System.Drawing.Size(1126, 40);
            this.SW_pan_bottom.TabIndex = 7;
            this.SW_pan_bottom.UseCustomBackColor = true;
            this.SW_pan_bottom.VerticalScrollbarBarColor = true;
            this.SW_pan_bottom.VerticalScrollbarHighlightOnWheel = false;
            this.SW_pan_bottom.VerticalScrollbarSize = 10;
            // 
            // bt_Home
            // 
            this.bt_Home.ActiveControl = null;
            this.bt_Home.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_Home.Dock = System.Windows.Forms.DockStyle.Right;
            this.bt_Home.ForeColor = System.Drawing.Color.White;
            this.bt_Home.Location = new System.Drawing.Point(976, 0);
            this.bt_Home.Name = "bt_Home";
            this.bt_Home.Size = new System.Drawing.Size(150, 40);
            this.bt_Home.Style = MetroFramework.MetroColorStyle.White;
            this.bt_Home.TabIndex = 6;
            this.bt_Home.Text = "Uscita";
            this.bt_Home.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bt_Home.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bt_Home.TileImage = ((System.Drawing.Image)(resources.GetObject("bt_Home.TileImage")));
            this.bt_Home.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_Home.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.bt_Home.UseCustomBackColor = true;
            this.bt_Home.UseCustomForeColor = true;
            this.bt_Home.UseSelectable = true;
            this.bt_Home.UseTileImage = true;
            this.bt_Home.Click += new System.EventHandler(this.bt_Home_Click);
            // 
            // fam_ProdTableAdapter
            // 
            this.fam_ProdTableAdapter.ClearBeforeFill = true;
            // 
            // schedeTableAdapter
            // 
            this.schedeTableAdapter.ClearBeforeFill = true;
            // 
            // softwareTableAdapter
            // 
            this.softwareTableAdapter.ClearBeforeFill = true;
            // 
            // prodSch
            // 
            this.prodSch.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.prodSch.DataPropertyName = "Prod_Sch";
            this.prodSch.FillWeight = 20F;
            this.prodSch.HeaderText = "Scheda";
            this.prodSch.Name = "prodSch";
            this.prodSch.ReadOnly = true;
            this.prodSch.Width = 67;
            // 
            // prodDescrizione
            // 
            this.prodDescrizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.prodDescrizione.DataPropertyName = "Prod_Descrizione";
            this.prodDescrizione.FillWeight = 60F;
            this.prodDescrizione.HeaderText = "Descrizione Scheda";
            this.prodDescrizione.Name = "prodDescrizione";
            this.prodDescrizione.ReadOnly = true;
            this.prodDescrizione.Width = 118;
            // 
            // SchedaCompatibile
            // 
            this.SchedaCompatibile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.SchedaCompatibile.FillWeight = 20F;
            this.SchedaCompatibile.HeaderText = "Comp.";
            this.SchedaCompatibile.Name = "SchedaCompatibile";
            this.SchedaCompatibile.Width = 44;
            // 
            // pan_P_Dx
            // 
            this.pan_P_Dx.BackColor = System.Drawing.Color.Linen;
            this.pan_P_Dx.Controls.Add(this.pan_P_Dx_Funzionamento);
            this.pan_P_Dx.Controls.Add(this.pan_P_Dx_revisioni);
            this.pan_P_Dx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_Dx.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx.HorizontalScrollbarSize = 10;
            this.pan_P_Dx.Location = new System.Drawing.Point(700, 0);
            this.pan_P_Dx.Name = "pan_P_Dx";
            this.pan_P_Dx.Size = new System.Drawing.Size(426, 415);
            this.pan_P_Dx.TabIndex = 54;
            this.pan_P_Dx.UseCustomBackColor = true;
            this.pan_P_Dx.VerticalScrollbarBarColor = true;
            this.pan_P_Dx.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx.VerticalScrollbarSize = 10;
            // 
            // pan_P_Dx_revisioni
            // 
            this.pan_P_Dx_revisioni.BackColor = System.Drawing.Color.Transparent;
            this.pan_P_Dx_revisioni.Controls.Add(this.rev_fill);
            this.pan_P_Dx_revisioni.Controls.Add(this.rev_top);
            this.pan_P_Dx_revisioni.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_P_Dx_revisioni.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx_revisioni.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_revisioni.HorizontalScrollbarSize = 10;
            this.pan_P_Dx_revisioni.Location = new System.Drawing.Point(0, 0);
            this.pan_P_Dx_revisioni.Name = "pan_P_Dx_revisioni";
            this.pan_P_Dx_revisioni.Size = new System.Drawing.Size(426, 150);
            this.pan_P_Dx_revisioni.TabIndex = 11;
            this.pan_P_Dx_revisioni.UseCustomBackColor = true;
            this.pan_P_Dx_revisioni.VerticalScrollbarBarColor = true;
            this.pan_P_Dx_revisioni.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_revisioni.VerticalScrollbarSize = 10;
            // 
            // metroContextMenu1
            // 
            this.metroContextMenu1.Name = "metroContextMenu1";
            this.metroContextMenu1.Size = new System.Drawing.Size(61, 4);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.Linen;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(426, 130);
            this.richTextBox1.TabIndex = 11;
            this.richTextBox1.Text = "";
            // 
            // pan_P_Dx_Funzionamento
            // 
            this.pan_P_Dx_Funzionamento.BackColor = System.Drawing.Color.Transparent;
            this.pan_P_Dx_Funzionamento.Controls.Add(this.funz_fill);
            this.pan_P_Dx_Funzionamento.Controls.Add(this.funz_top);
            this.pan_P_Dx_Funzionamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarSize = 10;
            this.pan_P_Dx_Funzionamento.Location = new System.Drawing.Point(0, 150);
            this.pan_P_Dx_Funzionamento.Name = "pan_P_Dx_Funzionamento";
            this.pan_P_Dx_Funzionamento.Size = new System.Drawing.Size(426, 265);
            this.pan_P_Dx_Funzionamento.TabIndex = 12;
            this.pan_P_Dx_Funzionamento.UseCustomBackColor = true;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarBarColor = true;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarSize = 10;
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Linen;
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox2.Location = new System.Drawing.Point(0, 0);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(426, 250);
            this.richTextBox2.TabIndex = 11;
            this.richTextBox2.Text = "";
            // 
            // metroLabel32
            // 
            this.metroLabel32.AutoSize = true;
            this.metroLabel32.Location = new System.Drawing.Point(0, 0);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(102, 19);
            this.metroLabel32.TabIndex = 10;
            this.metroLabel32.Text = "Funzionamento:";
            this.metroLabel32.UseCustomBackColor = true;
            // 
            // rev_top
            // 
            this.rev_top.BackColor = System.Drawing.Color.Linen;
            this.rev_top.Controls.Add(this.metroLabel33);
            this.rev_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.rev_top.HorizontalScrollbarBarColor = true;
            this.rev_top.HorizontalScrollbarHighlightOnWheel = false;
            this.rev_top.HorizontalScrollbarSize = 10;
            this.rev_top.Location = new System.Drawing.Point(0, 0);
            this.rev_top.Name = "rev_top";
            this.rev_top.Size = new System.Drawing.Size(426, 20);
            this.rev_top.TabIndex = 12;
            this.rev_top.UseCustomBackColor = true;
            this.rev_top.VerticalScrollbarBarColor = true;
            this.rev_top.VerticalScrollbarHighlightOnWheel = false;
            this.rev_top.VerticalScrollbarSize = 10;
            // 
            // rev_fill
            // 
            this.rev_fill.Controls.Add(this.richTextBox1);
            this.rev_fill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rev_fill.HorizontalScrollbarBarColor = true;
            this.rev_fill.HorizontalScrollbarHighlightOnWheel = false;
            this.rev_fill.HorizontalScrollbarSize = 10;
            this.rev_fill.Location = new System.Drawing.Point(0, 20);
            this.rev_fill.Name = "rev_fill";
            this.rev_fill.Size = new System.Drawing.Size(426, 130);
            this.rev_fill.TabIndex = 13;
            this.rev_fill.VerticalScrollbarBarColor = true;
            this.rev_fill.VerticalScrollbarHighlightOnWheel = false;
            this.rev_fill.VerticalScrollbarSize = 10;
            // 
            // metroLabel33
            // 
            this.metroLabel33.AutoSize = true;
            this.metroLabel33.Location = new System.Drawing.Point(0, 0);
            this.metroLabel33.Name = "metroLabel33";
            this.metroLabel33.Size = new System.Drawing.Size(62, 19);
            this.metroLabel33.TabIndex = 10;
            this.metroLabel33.Text = "Revisioni:";
            this.metroLabel33.UseCustomBackColor = true;
            // 
            // funz_top
            // 
            this.funz_top.BackColor = System.Drawing.Color.Linen;
            this.funz_top.Controls.Add(this.metroLabel32);
            this.funz_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.funz_top.HorizontalScrollbarBarColor = true;
            this.funz_top.HorizontalScrollbarHighlightOnWheel = false;
            this.funz_top.HorizontalScrollbarSize = 10;
            this.funz_top.Location = new System.Drawing.Point(0, 0);
            this.funz_top.Name = "funz_top";
            this.funz_top.Size = new System.Drawing.Size(426, 15);
            this.funz_top.TabIndex = 12;
            this.funz_top.UseCustomBackColor = true;
            this.funz_top.VerticalScrollbarBarColor = true;
            this.funz_top.VerticalScrollbarHighlightOnWheel = false;
            this.funz_top.VerticalScrollbarSize = 10;
            // 
            // funz_fill
            // 
            this.funz_fill.BackColor = System.Drawing.Color.Linen;
            this.funz_fill.Controls.Add(this.richTextBox2);
            this.funz_fill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.funz_fill.HorizontalScrollbarBarColor = true;
            this.funz_fill.HorizontalScrollbarHighlightOnWheel = false;
            this.funz_fill.HorizontalScrollbarSize = 10;
            this.funz_fill.Location = new System.Drawing.Point(0, 15);
            this.funz_fill.Name = "funz_fill";
            this.funz_fill.Size = new System.Drawing.Size(426, 250);
            this.funz_fill.TabIndex = 13;
            this.funz_fill.UseCustomBackColor = true;
            this.funz_fill.VerticalScrollbarBarColor = true;
            this.funz_fill.VerticalScrollbarHighlightOnWheel = false;
            this.funz_fill.VerticalScrollbarSize = 10;
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(559, 213);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 53;
            this.metroButton1.Text = "metroButton1";
            this.metroButton1.UseSelectable = true;
            // 
            // UC_form_Sw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.SW_pan_P);
            this.Controls.Add(this.SW_pan_C);
            this.Controls.Add(this.SW_pan_Top);
            this.Controls.Add(this.SW_pan_bottom);
            this.Name = "UC_form_Sw";
            this.Size = new System.Drawing.Size(1126, 605);
            this.Load += new System.EventHandler(this.UC_form_Sw_Load);
            this.SW_pan_C.ResumeLayout(false);
            this.SW_pan_C.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.C_sch_image)).EndInit();
            this.metroPanel3.ResumeLayout(false);
            this.metroPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).EndInit();
            this.SW_pan_P.ResumeLayout(false);
            this.pan_P_Sx.ResumeLayout(false);
            this.pan_P_middle.ResumeLayout(false);
            this.pan_P_middle.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.pan_P_top.ResumeLayout(false);
            this.pan_P_top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SchedeCompatibili)).EndInit();
            this.SW_pan_Top.ResumeLayout(false);
            this.pan_top_Dx.ResumeLayout(false);
            this.pan_top_Dx_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_SW_codificati)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSoftwareBindingSource)).EndInit();
            this.pan_top_Dx_1.ResumeLayout(false);
            this.pan_top_Dx_1.PerformLayout();
            this.pan_top_Sx.ResumeLayout(false);
            this.pan_top_Sx.PerformLayout();
            this.pan_top_top.ResumeLayout(false);
            this.pan_top_top.PerformLayout();
            this.SW_pan_bottom.ResumeLayout(false);
            this.pan_P_Dx.ResumeLayout(false);
            this.pan_P_Dx_revisioni.ResumeLayout(false);
            this.pan_P_Dx_Funzionamento.ResumeLayout(false);
            this.rev_top.ResumeLayout(false);
            this.rev_top.PerformLayout();
            this.rev_fill.ResumeLayout(false);
            this.funz_top.ResumeLayout(false);
            this.funz_top.PerformLayout();
            this.funz_fill.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel SW_pan_C;
        private MetroFramework.Controls.MetroLabel lab_Des_Scheda_C;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroRadioButton ID_radio_868_C;
        private MetroFramework.Controls.MetroRadioButton ID_radio_433_C;
        private MetroFramework.Controls.MetroRadioButton ID_radio_915_C;
        private MetroFramework.Controls.MetroToggle ID_toggle_Prop;
        private MetroFramework.Controls.MetroToggle ID_toggle_CanBus;
        private MetroFramework.Controls.MetroToggle ID_toggle_AntExt;
        private MetroFramework.Controls.MetroToggle ID_toggle_GuidaLuce;
        private MetroFramework.Controls.MetroToggle ID_toggle_TastEmerg;
        private MetroFramework.Controls.MetroToggle ID_toggle_PlugPLE;
        private MetroFramework.Controls.MetroToggle ID_toggle_PlugExp;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroPanel SW_pan_P;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroRadioButton ID_radio_868_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_433_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_915_P;
        private MetroFramework.Controls.MetroToggle ID_toggle_Fungo;
        private MetroFramework.Controls.MetroToggle ID_toggle_Torcia;
        private MetroFramework.Controls.MetroToggle ID_toggle_Vibracall;
        private MetroFramework.Controls.MetroToggle ID_toggle_Buzzer;
        private MetroFramework.Controls.MetroToggle ID_toggle_SP;
        private MetroFramework.Controls.MetroToggle ID_toggle_Accel;
        private MetroFramework.Controls.MetroToggle ID_toggle_Display;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel ID_lab_Palmare;
        private MetroFramework.Controls.MetroPanel SW_pan_Top;
        private System.Windows.Forms.ComboBox ID_combo_Famiglia;
        private MetroFramework.Controls.MetroLabel titolo_ID;
        private MetroFramework.Controls.MetroLabel SW_lab_Famiglia;
        private MetroFramework.Controls.MetroPanel SW_pan_bottom;
        private System.Windows.Forms.PictureBox C_sch_image;
        private MetroFramework.Controls.MetroTile bt_Home;
        private MetroFramework.Controls.MetroLabel SW_lab_codice_SW;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_frequency;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_version;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_name;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroGrid grid_SW_codificati;
        private MetroFramework.Controls.MetroPanel pan_top_Dx;
        private MetroFramework.Controls.MetroPanel pan_top_Sx;
        private MetroFramework.Controls.MetroPanel pan_top_top;
        private MetroFramework.Controls.MetroPanel pan_top_Dx_2;
        private MetroFramework.Controls.MetroPanel pan_top_Dx_1;
        private System.Windows.Forms.BindingSource famProdSchedeBindingSource;
        private System.Windows.Forms.BindingSource famProdBindingSource;
        private DB_FactoryDataSet dB_FactoryDataSet;
        private System.Windows.Forms.BindingSource famProdSoftwareBindingSource;
        private DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter fam_ProdTableAdapter;
        private DB_FactoryDataSetTableAdapters.SchedeTableAdapter schedeTableAdapter;
        private DB_FactoryDataSetTableAdapters.SoftwareTableAdapter softwareTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SW_Customer;
        private MetroFramework.Controls.MetroGrid grid_SchedeCompatibili;
        private MetroFramework.Controls.MetroPanel pan_P_middle;
        private MetroFramework.Controls.MetroPanel pan_P_top;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private MetroFramework.Controls.MetroToggle metroToggle1;
        private MetroFramework.Controls.MetroToggle metroToggle2;
        private MetroFramework.Controls.MetroToggle metroToggle3;
        private MetroFramework.Controls.MetroToggle metroToggle4;
        private MetroFramework.Controls.MetroToggle metroToggle5;
        private MetroFramework.Controls.MetroToggle metroToggle6;
        private MetroFramework.Controls.MetroToggle metroToggle7;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroPanel pan_P_Sx;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodSch;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodDescrizione;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SchedaCompatibile;
        private MetroFramework.Controls.MetroPanel pan_P_Dx;
        private MetroFramework.Controls.MetroPanel pan_P_Dx_revisioni;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private MetroFramework.Controls.MetroContextMenu metroContextMenu1;
        private MetroFramework.Controls.MetroPanel pan_P_Dx_Funzionamento;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private MetroFramework.Controls.MetroLabel metroLabel32;
        private MetroFramework.Controls.MetroPanel rev_fill;
        private MetroFramework.Controls.MetroPanel rev_top;
        private MetroFramework.Controls.MetroLabel metroLabel33;
        private MetroFramework.Controls.MetroPanel funz_fill;
        private MetroFramework.Controls.MetroPanel funz_top;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}
