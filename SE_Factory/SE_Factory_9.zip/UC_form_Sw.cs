﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using MetroFramework.Forms;
using iTextSharp.text.pdf;

namespace SE_Factory
{
    public partial class UC_form_Sw : UserControl
    {
        public string SchedeCompatibili_SW = "";
        public string TemplateFolder = @"C:\Users\documentazione\Desktop\___Alberto___\Indesign\Prova Moduli SW\Template_PDF_Software.pdf";

        public UC_form_Sw()
        {
            InitializeComponent();
        }

        private void famProdBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            {
                AzzeraVariabili();
                if (famProdBindingSource.Current != null)
                {
                    DataRow currentRow = ((DataRowView)famProdBindingSource.Current).Row;

                    GVar.glob_tipo_item = currentRow["Fam_Tipo"].ToString();
                    GVar.glob_hex_id = currentRow["Fam_Hex_ID"].ToString();
                    GVar.glob_result_id[0] = Convert.ToChar(currentRow["Fam_Hex_ID"]);

                    Setting_Form();
                }
            }
        }

        private void ID_timer_Tick(object sender, EventArgs e)
        {
            Calcola_ID_Palmare();
        }

        private void Calcola_ID_Palmare()
        {
            if (GVar.glob_tipo_item == "P")
            {
                Array.Clear(GVar.glob_bin_id, 0, 12);
                if (ID_radio_868_P.Checked) { GVar.glob_bin_id[0] = '1'; } else { GVar.glob_bin_id[0] = '0'; }
                if (ID_radio_915_P.Checked) { GVar.glob_bin_id[1] = '1'; } else { GVar.glob_bin_id[1] = '0'; }
                if (ID_radio_433_P.Checked) { GVar.glob_bin_id[2] = '1'; } else { GVar.glob_bin_id[2] = '0'; }
                if (ID_toggle_Display.Checked) { GVar.glob_bin_id[3] = '1'; } else { GVar.glob_bin_id[3] = '0'; }
                if (ID_toggle_Accel.Checked) { GVar.glob_bin_id[4] = '1'; } else { GVar.glob_bin_id[4] = '0'; }
                if (ID_toggle_SP.Checked) { GVar.glob_bin_id[5] = '1'; } else { GVar.glob_bin_id[5] = '0'; }
                if (ID_toggle_Buzzer.Checked) { GVar.glob_bin_id[6] = '1'; } else { GVar.glob_bin_id[6] = '0'; }
                if (ID_toggle_Vibracall.Checked) { GVar.glob_bin_id[7] = '1'; } else { GVar.glob_bin_id[7] = '0'; }
                if (ID_toggle_Torcia.Checked) { GVar.glob_bin_id[8] = '1'; } else { GVar.glob_bin_id[8] = '0'; }
                if (ID_toggle_Fungo.Checked) { GVar.glob_bin_id[9] = '1'; } else { GVar.glob_bin_id[9] = '0'; }
                GVar.glob_bin_id[10] = '0';
                GVar.glob_bin_id[11] = '0';
            }
            if (GVar.glob_tipo_item == "C")
            {
                Array.Clear(GVar.glob_bin_id, 0, 12);
                if (ID_radio_868_C.Checked) { GVar.glob_bin_id[0] = '1'; } else { GVar.glob_bin_id[0] = '0'; }
                if (ID_radio_915_C.Checked) { GVar.glob_bin_id[1] = '1'; } else { GVar.glob_bin_id[1] = '0'; }
                if (ID_radio_433_C.Checked) { GVar.glob_bin_id[2] = '1'; } else { GVar.glob_bin_id[2] = '0'; }
                if (ID_toggle_PlugExp.Checked) { GVar.glob_bin_id[3] = '1'; } else { GVar.glob_bin_id[3] = '0'; }
                if (ID_toggle_PlugPLE.Checked) { GVar.glob_bin_id[4] = '1'; } else { GVar.glob_bin_id[4] = '0'; }
                if (ID_toggle_TastEmerg.Checked) { GVar.glob_bin_id[5] = '1'; } else { GVar.glob_bin_id[5] = '0'; }
                if (ID_toggle_GuidaLuce.Checked) { GVar.glob_bin_id[6] = '1'; } else { GVar.glob_bin_id[6] = '0'; }
                if (ID_toggle_AntExt.Checked) { GVar.glob_bin_id[7] = '1'; } else { GVar.glob_bin_id[7] = '0'; }
                if (ID_toggle_CanBus.Checked) { GVar.glob_bin_id[8] = '1'; } else { GVar.glob_bin_id[8] = '0'; }
                if (ID_toggle_Prop.Checked) { GVar.glob_bin_id[9] = '1'; } else { GVar.glob_bin_id[9] = '0'; }
                GVar.glob_bin_id[10] = '0';
                GVar.glob_bin_id[11] = '0';
            }

            string binary = "";
            for (int i = 0; i < 12; i++)
            {
                binary = binary + GVar.glob_bin_id[i].ToString();
            }

            // Binary to Hex conversion
            string myhex = Convert.ToString(Convert.ToInt32(binary, 2), 16);
            GVar.glob_result_id[0] = GVar.glob_hex_id[0];
            GVar.glob_result_id[1] = Convert.ToChar(myhex.ToUpper().Substring(0, 1));
            GVar.glob_result_id[2] = Convert.ToChar(myhex.ToUpper().Substring(1, 1));
            GVar.glob_result_id[3] = Convert.ToChar(myhex.ToUpper().Substring(2, 1));
        }

        private void AzzeraVariabili()
        {
            ID_radio_868_P.Checked = true;
            ID_radio_868_C.Checked = true;

            //Azzero Palmari
            ID_toggle_Display.Checked = false;
            ID_toggle_Accel.Checked = false;
            ID_toggle_SP.Checked = false;
            ID_toggle_Buzzer.Checked = false;
            ID_toggle_Vibracall.Checked = false;
            ID_toggle_Torcia.Checked = false;
            ID_toggle_Fungo.Checked = false;

            //Azzero Controller
            ID_toggle_PlugExp.Checked = false;
            ID_toggle_PlugPLE.Checked = false;
            ID_toggle_TastEmerg.Checked = false;
            ID_toggle_GuidaLuce.Checked = false;
            ID_toggle_AntExt.Checked = false;
            ID_toggle_CanBus.Checked = false;
            ID_toggle_Prop.Checked = false;

            grid_P_SchedeCompatibili.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void Setting_Form()
        {
            switch (GVar.glob_form_status)
            {
                case "N":
                    //pan_SW_Lista.Visible = true;
                    //pan_SW_Lista.Enabled = false;
                    pan_SW_P.Visible = true;
                    pan_Menu_comandi.Enabled = false;
                    pan_Menu_salva.Enabled = true;
                    pan_Menu_exit.Enabled = false;
                    break;
                case "E":
                    //pan_SW_Lista.Visible = false;
                    pan_SW_P.Visible = true;
                    pan_SW_C.Visible = true;
                    pan_Menu_comandi.Enabled = false;
                    pan_Menu_salva.Enabled = true;
                    pan_Menu_exit.Enabled = false;
                    break;
                case "V":
                    //pan_SW_Lista.Visible = true;
                    //pan_SW_P.Visible = false;
                    //pan_SW_C.Visible = false;

                    if (GVar.glob_tipo_item == "P")
                    {
                        pan_SW_C.Visible = false;
                        pan_SW_P.Visible = true;
                        pan_SW_P.Enabled = false;
                    }
                    if (GVar.glob_tipo_item == "C")
                    {
                        pan_SW_P.Visible = false;
                        pan_SW__P_Testi.Visible = false;
                        pan_SW_C.Visible = true;
                        pan_SW__C_Testi.Visible = true;
                        pan_SW_C.Enabled = false;
                    }
                    pan_SW_Codifica.Enabled = false;
                    pan_Menu_comandi.Enabled = true;
                    pan_Menu_salva.Enabled = false;
                    pan_Menu_exit.Enabled = true;
                    break;
            }

            //Azzero il campo check nel datagrid
            foreach (DataGridViewRow riga_P in grid_P_SchedeCompatibili.Rows)
            {
                riga_P.Cells["P_SchedaCompatibile"].Value = false;
            }
            foreach (DataGridViewRow riga_C in grid_C_SchedeCompatibili.Rows)
            {
                riga_C.Cells["C_SchedaCompatibile"].Value = false;
            }

            //Visualizzo i dati in base ai valori del record
            if (famProdSoftwareBindingSource.Current != null)
            {
                DataRow SW_view = ((DataRowView)famProdSoftwareBindingSource.Current).Row;

                //Estrapolo i codici software
                string nome_sw = SW_view["SW_Code"].ToString();
                tbox_Sw_name.Text = nome_sw.Substring(4, 5);
                tbox_Sw_version.Text = nome_sw.Substring(9, 3);
                tbox_Sw_frequency.Text = nome_sw.Substring(12, 1);


                //Analizzo i campi del record
                string analisi_schede = SW_view["SW_SchedeCompatibili"].ToString();
                char[] delimitatore = new char[] { '|' };
                GVar.glob_schede_compatibili.Clear();
                foreach (string substringa in analisi_schede.Split(delimitatore))
                {
                    GVar.glob_schede_compatibili.Add(substringa);

                    //verifica la presenza nel datagrid
                    foreach (DataGridViewRow riga in grid_P_SchedeCompatibili.Rows)
                    {
                        if (riga.Cells["prodSch"].Value.ToString() == substringa)
                        {
                            riga.Cells["SchedaCompatibile"].Value = true;
                        }
                    }
                }

                switch (SW_view["SW_P_Opt_RF"])
                {
                    case "868":
                        ID_radio_868_P.Checked = true;
                        ID_radio_915_P.Checked = false;
                        ID_radio_433_P.Checked = false;
                        ID_radio_Filo_P.Checked = false;
                        ID_radio_None_P.Checked = false;
                        break;
                    case "915":
                        ID_radio_868_P.Checked = false;
                        ID_radio_915_P.Checked = true;
                        ID_radio_433_P.Checked = false;
                        ID_radio_Filo_P.Checked = false;
                        ID_radio_None_P.Checked = false;
                        break;
                    case "433":
                        ID_radio_868_P.Checked = false;
                        ID_radio_915_P.Checked = false;
                        ID_radio_433_P.Checked = true;
                        ID_radio_Filo_P.Checked = false;
                        ID_radio_None_P.Checked = false;
                        break;
                    case "Filo":
                        ID_radio_868_P.Checked = false;
                        ID_radio_915_P.Checked = false;
                        ID_radio_433_P.Checked = false;
                        ID_radio_Filo_P.Checked = true;
                        ID_radio_None_P.Checked = false;
                        break;
                    case "None":
                        ID_radio_868_P.Checked = false;
                        ID_radio_915_P.Checked = false;
                        ID_radio_433_P.Checked = false;
                        ID_radio_Filo_P.Checked = false;
                        ID_radio_None_P.Checked = true;
                        break;
                }

                if ((bool)SW_view["SW_P_Opt_Oled"]) { ID_toggle_Display.Checked = true; } else { ID_toggle_Display.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Accel"]) { ID_toggle_Accel.Checked = true; } else { ID_toggle_Accel.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_SP"]) { ID_toggle_SP.Checked = true; } else { ID_toggle_SP.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Buzzer"]) { ID_toggle_Buzzer.Checked = true; } else { ID_toggle_Buzzer.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Vibracall"]) { ID_toggle_Vibracall.Checked = true; } else { ID_toggle_Vibracall.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_LedTorch"]) { ID_toggle_Torcia.Checked = true; } else { ID_toggle_Torcia.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_EmButt"]) { ID_toggle_Fungo.Checked = true; } else { ID_toggle_Fungo.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Use_Backlight"]) { ID_toggle_use_Backlight.Checked = true; } else { ID_toggle_use_Backlight.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Use_Accel"]) { ID_toggle_use_Accel.Checked = true; } else { ID_toggle_use_Accel.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Use_SP"]) { ID_toggle_use_SP.Checked = true; } else { ID_toggle_use_SP.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Use_Buzzer"]) { ID_toggle_use_Buzzer.Checked = true; } else { ID_toggle_use_Buzzer.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Use_Vibracall"]) { ID_toggle_use_Vibracall.Checked = true; } else { ID_toggle_use_Vibracall.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_Use_LedTorch"]) { ID_toggle_use_Torch.Checked = true; } else { ID_toggle_use_Torch.Checked = false; }
                if ((bool)SW_view["SW_P_Opt_ShiftPage"]) { ID_toggle_ShiftPage.Checked = true; } else { ID_toggle_ShiftPage.Checked = false; }
                tb_Max_Pairable.Text = SW_view["SW_P_Opt_MaxPairDevices"].ToString();
                richtb_Revisioni.Text = SW_view["SW_Revisioni"].ToString();
                richtb_Funzioni.Text = SW_view["SW_Funzionamento"].ToString();
            }
            else
            {
                tbox_Sw_name.Text = "";
                tbox_Sw_version.Text = "";
                tbox_Sw_frequency.Text = "";
            }

        }

        private void tbox_Sw_name_Validating(object sender, CancelEventArgs e)
        {
            if ((!tbox_Sw_name.MaskFull) && (tbox_Sw_name.Text != ""))
            {
                MessageBox.Show("Campo non compilato completamente!");
                tbox_Sw_name.Focus();
            }
        }

        private void tbox_Sw_version_Validating(object sender, CancelEventArgs e)
        {
            if ((!tbox_Sw_version.MaskFull) && (tbox_Sw_version.Text != ""))
            {
                MessageBox.Show("Campo non compilato completamente!");
                tbox_Sw_version.Focus();
            }
        }

        private void tbox_Sw_frequency_Validating(object sender, CancelEventArgs e)
        {
            if ((!tbox_Sw_frequency.MaskFull) && (tbox_Sw_frequency.Text != ""))
            {
                MessageBox.Show("Campo non compilato completamente!");
                tbox_Sw_frequency.Focus();
            }

            if ((tbox_Sw_frequency.Text.ToUpper() != "X") &&
                (tbox_Sw_frequency.Text.ToUpper() != "A") &&
                (tbox_Sw_frequency.Text.ToUpper() != "B") &&
                (tbox_Sw_frequency.Text.ToUpper() != "N") &&
                (tbox_Sw_frequency.Text.ToUpper() != "Z"))
            {
                MessageBox.Show("Valore non corretto!");
                tbox_Sw_frequency.Focus();
            }

        }

        private void UC_form_Sw_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'dB_FactoryDataSet.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.fam_ProdTableAdapter.Fill(this.dB_FactoryDataSet.Fam_Prod);
            // TODO: questa riga di codice carica i dati nella tabella 'dB_FactoryDataSet.Schede'. È possibile spostarla o rimuoverla se necessario.
            this.schedeTableAdapter.Fill(this.dB_FactoryDataSet.Schede);
            // TODO: questa riga di codice carica i dati nella tabella 'dB_FactoryDataSet.Software'. È possibile spostarla o rimuoverla se necessario.
            this.softwareTableAdapter.Fill(this.dB_FactoryDataSet.Software);

            AzzeraVariabili();
            Setting_Form();
        }

        private void grid_SchedeCompatibili_Validated(object sender, EventArgs e)
        {
            if (grid_P_SchedeCompatibili.Rows.Count > 0)
            {
                SchedeCompatibili_SW = "";
                string testo = "";
                for (int i = 0; i < grid_P_SchedeCompatibili.Rows.Count; i++)
                {
                    DataGridViewRow selectedRow = grid_P_SchedeCompatibili.Rows[i];
                    bool isChecked = Convert.ToBoolean(selectedRow.Cells["SchedaCompatibile"].Value);

                    if (isChecked)
                    {
                        if (testo == "")
                        {
                            testo = selectedRow.Cells["prodSch"].Value.ToString();
                        }
                        else
                        {
                            testo = testo + "|";
                            testo = testo + selectedRow.Cells["prodSch"].Value.ToString();
                        }
                    }
                }
                SchedeCompatibili_SW = testo;
            }
        }

        private void CreaPDF()
        {
            System.Threading.Thread.Sleep(1000);

            string P_InputStream = TemplateFolder;

            string P_OutputStream = @"C:\Users\documentazione\Desktop\___Alberto___\Indesign\Prova Moduli SW\FolderOut\result.pdf";

            using (FileStream outFile = new FileStream(P_OutputStream, FileMode.Create))
            {
                PdfReader pdfReader = new PdfReader(P_InputStream);
                PdfStamper pdfStamper = new PdfStamper(pdfReader, outFile);
                AcroFields fields = pdfStamper.AcroFields;

                if ((famProdSoftwareBindingSource.Current != null) && (GVar.glob_tipo_item == "P"))
                {
                    DataRow SW_view = ((DataRowView)famProdSoftwareBindingSource.Current).Row;

                    fields.SetField("SW_Code", SW_view["SW_Code"].ToString());
                    fields.SetField("Chip_Code", SW_view["SW_Microchip_Code"].ToString());
                    fields.SetField("Schede", SW_view["SW_SchedeCompatibili"].ToString());
                    fields.SetField("Radio_Freq", SW_view["SW_P_Opt_RF"].ToString());
                    if ((bool)SW_view["SW_P_Opt_Oled"]) { fields.SetField("HW_Oled_si", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Accel"]) { fields.SetField("HW_Accel_si", "1"); }
                    if ((bool)SW_view["SW_P_Opt_SP"]) { fields.SetField("HW_SP_si", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Buzzer"]) { fields.SetField("HW_Buz_si", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Vibracall"]) { fields.SetField("HW_Vibra_si", "1"); }
                    if ((bool)SW_view["SW_P_Opt_LedTorch"]) { fields.SetField("HW_Torcia_si", "1"); }
                    if ((bool)SW_view["SW_P_Opt_EmButt"]) { fields.SetField("HW_Emer_si", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Use_Backlight"]) { fields.SetField("SW_use_back", "1"); }
                    if ((bool)SW_view["SW_P_Opt_ShiftPage"]) { fields.SetField("SW_shiftpage", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Use_Accel"]) { fields.SetField("SW_use_accel", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Use_SP"]) { fields.SetField("SW_use_SP", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Use_Buzzer"]) { fields.SetField("SW_use_buzz", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Use_Vibracall"]) { fields.SetField("SW_use_vibra", "1"); }
                    if ((bool)SW_view["SW_P_Opt_Use_LedTorch"]) { fields.SetField("SW_use_torch", "1"); }
                    fields.SetField("SW_max_pair_P", SW_view["SW_P_Opt_MaxPairDevices"].ToString());

                    fields.SetField("Revision", SW_view["SW_Revisioni"].ToString());
                    fields.SetField("Operation", SW_view["SW_Funzionamento"].ToString());
                }

                pdfStamper.Close();
                pdfReader.Close();
            }

        }

        private void modificaCodiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.glob_form_status = "E";
            Setting_Form();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            GVar.glob_form_status = "N";
            Setting_Form();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            this.Parent.Controls.Remove(this);
        }

        private void famProdSoftwareBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            Setting_Form();
        }

        private void creaPdfToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreaPDF();
        }
    }
}
