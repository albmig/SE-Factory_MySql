﻿namespace SE_Factory
{


    partial class DB_FactoryDataSet
    {
        partial class GC_CustomersDataTable
        {
        }

        partial class xls_SerialsDataTable
        {
        }

        partial class JLabelDataTable
        {
        }

        partial class local_SoftwareDataTable
        {
        }
    }
}

namespace SE_Factory.DB_FactoryDataSetTableAdapters
{
    partial class GC_CustomersTableAdapter
    {
    }

    public partial class local_SoftwareTableAdapter
    {
    }
}
