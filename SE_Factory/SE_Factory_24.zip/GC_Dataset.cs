﻿namespace SE_Factory
{


    partial class GC_Dataset
    {
    }
}
