﻿namespace SE_Factory
{
    partial class UC_form_Sw
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_form_Sw));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pan_SW_C_OLD = new MetroFramework.Controls.MetroPanel();
            this.lab_Des_Scheda_C = new MetroFramework.Controls.MetroLabel();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.ID_radio_868_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_433_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_915_C = new MetroFramework.Controls.MetroRadioButton();
            this.ID_toggle_Prop = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_CanBus = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_AntExt = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_GuidaLuce = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_TastEmerg = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_PlugPLE = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_PlugExp = new MetroFramework.Controls.MetroToggle();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.famProdSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.famProdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dB_FactoryDataSet = new SE_Factory.DB_FactoryDataSet();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.pan_SW__P_Testi = new MetroFramework.Controls.MetroPanel();
            this.pan_P_Dx_Funzionamento = new MetroFramework.Controls.MetroPanel();
            this.funz_fill = new MetroFramework.Controls.MetroPanel();
            this.richtb_Funzioni = new System.Windows.Forms.RichTextBox();
            this.funz_top = new MetroFramework.Controls.MetroPanel();
            this.metroLabel32 = new MetroFramework.Controls.MetroLabel();
            this.pan_P_Dx_revisioni = new MetroFramework.Controls.MetroPanel();
            this.rev_fill = new MetroFramework.Controls.MetroPanel();
            this.richtb_Revisioni = new System.Windows.Forms.RichTextBox();
            this.rev_top = new MetroFramework.Controls.MetroPanel();
            this.metroLabel33 = new MetroFramework.Controls.MetroLabel();
            this.pan_SW_P = new MetroFramework.Controls.MetroPanel();
            this.pan_P_middle = new MetroFramework.Controls.MetroPanel();
            this.tb_Max_Pairable = new System.Windows.Forms.TextBox();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.ID_toggle_ShiftPage = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Torch = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Vibracall = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Buzzer = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_SP = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Accel = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_use_Backlight = new MetroFramework.Controls.MetroToggle();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.ID_radio_None_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_Filo_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_868_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_433_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_radio_915_P = new MetroFramework.Controls.MetroRadioButton();
            this.ID_toggle_Fungo = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Torcia = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Vibracall = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Buzzer = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_SP = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Accel = new MetroFramework.Controls.MetroToggle();
            this.ID_toggle_Display = new MetroFramework.Controls.MetroToggle();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.pan_P_top = new MetroFramework.Controls.MetroPanel();
            this.pan_P_top_grid = new MetroFramework.Controls.MetroPanel();
            this.grid_P_SchedeCompatibili = new MetroFramework.Controls.MetroGrid();
            this.P_prodSch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_prodDescrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P_SchedaCompatibile = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pan_P_top_left = new MetroFramework.Controls.MetroPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.pan_P_top_top = new MetroFramework.Controls.MetroPanel();
            this.ID_lab_Palmare = new MetroFramework.Controls.MetroLabel();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.grid_SW_codificati = new MetroFramework.Controls.MetroGrid();
            this.sWCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SW_Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famProdSoftwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pan_SW_Codifica = new MetroFramework.Controls.MetroPanel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.SW_lab_codice_SW = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.tbox_Sw_name = new System.Windows.Forms.MaskedTextBox();
            this.tbox_Sw_version = new System.Windows.Forms.MaskedTextBox();
            this.tbox_Sw_frequency = new System.Windows.Forms.MaskedTextBox();
            this.SW_lab_Famiglia = new MetroFramework.Controls.MetroLabel();
            this.ID_combo_Famiglia = new System.Windows.Forms.ComboBox();
            this.pan_SW_Titolo = new MetroFramework.Controls.MetroPanel();
            this.titolo_ID = new MetroFramework.Controls.MetroLabel();
            this.fam_ProdTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter();
            this.schedeTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SchedeTableAdapter();
            this.softwareTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.SoftwareTableAdapter();
            this.metroContextMenu1 = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.SW_Layout = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_comandi = new System.Windows.Forms.MenuStrip();
            this.menu_sw_new = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div01 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_edit = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div02 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_clona = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div03 = new System.Windows.Forms.ToolStripMenuItem();
            this.creaRevisioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div04 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_creapdf = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_salva = new System.Windows.Forms.MenuStrip();
            this.menu_sw_div11 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_salva = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div12 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_annulla = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_SW_C = new MetroFramework.Controls.MetroPanel();
            this.pan_C_middle = new MetroFramework.Controls.MetroPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.metroLabel31 = new MetroFramework.Controls.MetroLabel();
            this.metroToggle1 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle2 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle3 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle4 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle5 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle6 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle7 = new MetroFramework.Controls.MetroToggle();
            this.metroLabel34 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel35 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel36 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel37 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel38 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel39 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel40 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel5 = new MetroFramework.Controls.MetroPanel();
            this.metroRadioButton1 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton2 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton3 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton4 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton5 = new MetroFramework.Controls.MetroRadioButton();
            this.metroToggle8 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle9 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle10 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle11 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle12 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle13 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle14 = new MetroFramework.Controls.MetroToggle();
            this.metroLabel41 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel42 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel43 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel44 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel45 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel46 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel47 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel48 = new MetroFramework.Controls.MetroLabel();
            this.pan_C_top = new MetroFramework.Controls.MetroPanel();
            this.pan_C_top_grid = new MetroFramework.Controls.MetroPanel();
            this.grid_C_SchedeCompatibili = new MetroFramework.Controls.MetroGrid();
            this.C_prodSch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C_prodDescrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C_SchedaCompatibile = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pan_C_top_left = new MetroFramework.Controls.MetroPanel();
            this.metroLabel49 = new MetroFramework.Controls.MetroLabel();
            this.pan_C_top_top = new MetroFramework.Controls.MetroPanel();
            this.ID_lab_Controller = new MetroFramework.Controls.MetroLabel();
            this.pan_SW__C_Testi = new MetroFramework.Controls.MetroPanel();
            this.pan_C_Dx_Funzionamento = new MetroFramework.Controls.MetroPanel();
            this.metroPanel6 = new MetroFramework.Controls.MetroPanel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.metroPanel7 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel50 = new MetroFramework.Controls.MetroLabel();
            this.pan_C_Dx_revisioni = new MetroFramework.Controls.MetroPanel();
            this.metroPanel9 = new MetroFramework.Controls.MetroPanel();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.metroPanel10 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel51 = new MetroFramework.Controls.MetroLabel();
            this.pan_SW_C_OLD.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).BeginInit();
            this.pan_SW__P_Testi.SuspendLayout();
            this.pan_P_Dx_Funzionamento.SuspendLayout();
            this.funz_fill.SuspendLayout();
            this.funz_top.SuspendLayout();
            this.pan_P_Dx_revisioni.SuspendLayout();
            this.rev_fill.SuspendLayout();
            this.rev_top.SuspendLayout();
            this.pan_SW_P.SuspendLayout();
            this.pan_P_middle.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            this.pan_P_top.SuspendLayout();
            this.pan_P_top_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_P_SchedeCompatibili)).BeginInit();
            this.pan_P_top_left.SuspendLayout();
            this.pan_P_top_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SW_codificati)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSoftwareBindingSource)).BeginInit();
            this.pan_SW_Codifica.SuspendLayout();
            this.pan_SW_Titolo.SuspendLayout();
            this.SW_Layout.SuspendLayout();
            this.pan_Menu_comandi.SuspendLayout();
            this.pan_Menu_salva.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.pan_SW_C.SuspendLayout();
            this.pan_C_middle.SuspendLayout();
            this.metroPanel5.SuspendLayout();
            this.pan_C_top.SuspendLayout();
            this.pan_C_top_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_C_SchedeCompatibili)).BeginInit();
            this.pan_C_top_left.SuspendLayout();
            this.pan_C_top_top.SuspendLayout();
            this.pan_SW__C_Testi.SuspendLayout();
            this.pan_C_Dx_Funzionamento.SuspendLayout();
            this.metroPanel6.SuspendLayout();
            this.metroPanel7.SuspendLayout();
            this.pan_C_Dx_revisioni.SuspendLayout();
            this.metroPanel9.SuspendLayout();
            this.metroPanel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // pan_SW_C_OLD
            // 
            this.pan_SW_C_OLD.BackColor = System.Drawing.SystemColors.Window;
            this.SW_Layout.SetColumnSpan(this.pan_SW_C_OLD, 10);
            this.pan_SW_C_OLD.Controls.Add(this.lab_Des_Scheda_C);
            this.pan_SW_C_OLD.Controls.Add(this.metroPanel3);
            this.pan_SW_C_OLD.Controls.Add(this.ID_toggle_Prop);
            this.pan_SW_C_OLD.Controls.Add(this.ID_toggle_CanBus);
            this.pan_SW_C_OLD.Controls.Add(this.ID_toggle_AntExt);
            this.pan_SW_C_OLD.Controls.Add(this.ID_toggle_GuidaLuce);
            this.pan_SW_C_OLD.Controls.Add(this.ID_toggle_TastEmerg);
            this.pan_SW_C_OLD.Controls.Add(this.ID_toggle_PlugPLE);
            this.pan_SW_C_OLD.Controls.Add(this.ID_toggle_PlugExp);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel11);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel12);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel13);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel14);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel15);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel16);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel17);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel18);
            this.pan_SW_C_OLD.Controls.Add(this.label1);
            this.pan_SW_C_OLD.Controls.Add(this.comboBox1);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel19);
            this.pan_SW_C_OLD.Controls.Add(this.metroLabel20);
            this.pan_SW_C_OLD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_C_OLD.ForeColor = System.Drawing.SystemColors.Control;
            this.pan_SW_C_OLD.HorizontalScrollbarBarColor = true;
            this.pan_SW_C_OLD.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_C_OLD.HorizontalScrollbarSize = 10;
            this.pan_SW_C_OLD.Location = new System.Drawing.Point(3, 1022);
            this.pan_SW_C_OLD.Name = "pan_SW_C_OLD";
            this.pan_SW_C_OLD.Size = new System.Drawing.Size(1120, 105);
            this.pan_SW_C_OLD.TabIndex = 8;
            this.pan_SW_C_OLD.UseCustomBackColor = true;
            this.pan_SW_C_OLD.VerticalScrollbarBarColor = true;
            this.pan_SW_C_OLD.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_C_OLD.VerticalScrollbarSize = 10;
            this.pan_SW_C_OLD.Visible = false;
            // 
            // lab_Des_Scheda_C
            // 
            this.lab_Des_Scheda_C.AutoSize = true;
            this.lab_Des_Scheda_C.Location = new System.Drawing.Point(360, 31);
            this.lab_Des_Scheda_C.Name = "lab_Des_Scheda_C";
            this.lab_Des_Scheda_C.Size = new System.Drawing.Size(88, 19);
            this.lab_Des_Scheda_C.TabIndex = 37;
            this.lab_Des_Scheda_C.Text = "metroLabel21";
            // 
            // metroPanel3
            // 
            this.metroPanel3.Controls.Add(this.ID_radio_868_C);
            this.metroPanel3.Controls.Add(this.ID_radio_433_C);
            this.metroPanel3.Controls.Add(this.ID_radio_915_C);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(150, 63);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(170, 20);
            this.metroPanel3.TabIndex = 36;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // ID_radio_868_C
            // 
            this.ID_radio_868_C.AutoSize = true;
            this.ID_radio_868_C.Location = new System.Drawing.Point(0, 0);
            this.ID_radio_868_C.Name = "ID_radio_868_C";
            this.ID_radio_868_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_868_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_868_C.TabIndex = 32;
            this.ID_radio_868_C.Text = "868";
            this.ID_radio_868_C.UseCustomBackColor = true;
            this.ID_radio_868_C.UseSelectable = true;
            this.ID_radio_868_C.UseStyleColors = true;
            // 
            // ID_radio_433_C
            // 
            this.ID_radio_433_C.AutoSize = true;
            this.ID_radio_433_C.Location = new System.Drawing.Point(120, 0);
            this.ID_radio_433_C.Name = "ID_radio_433_C";
            this.ID_radio_433_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_433_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_433_C.TabIndex = 34;
            this.ID_radio_433_C.Text = "433";
            this.ID_radio_433_C.UseCustomBackColor = true;
            this.ID_radio_433_C.UseSelectable = true;
            this.ID_radio_433_C.UseStyleColors = true;
            // 
            // ID_radio_915_C
            // 
            this.ID_radio_915_C.AutoSize = true;
            this.ID_radio_915_C.Location = new System.Drawing.Point(60, 0);
            this.ID_radio_915_C.Name = "ID_radio_915_C";
            this.ID_radio_915_C.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_915_C.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_915_C.TabIndex = 33;
            this.ID_radio_915_C.Text = "915";
            this.ID_radio_915_C.UseCustomBackColor = true;
            this.ID_radio_915_C.UseSelectable = true;
            this.ID_radio_915_C.UseStyleColors = true;
            // 
            // ID_toggle_Prop
            // 
            this.ID_toggle_Prop.AutoSize = true;
            this.ID_toggle_Prop.Location = new System.Drawing.Point(150, 270);
            this.ID_toggle_Prop.Name = "ID_toggle_Prop";
            this.ID_toggle_Prop.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Prop.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Prop.TabIndex = 28;
            this.ID_toggle_Prop.Text = "Off";
            this.ID_toggle_Prop.UseSelectable = true;
            // 
            // ID_toggle_CanBus
            // 
            this.ID_toggle_CanBus.AutoSize = true;
            this.ID_toggle_CanBus.Location = new System.Drawing.Point(150, 240);
            this.ID_toggle_CanBus.Name = "ID_toggle_CanBus";
            this.ID_toggle_CanBus.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_CanBus.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_CanBus.TabIndex = 27;
            this.ID_toggle_CanBus.Text = "Off";
            this.ID_toggle_CanBus.UseSelectable = true;
            // 
            // ID_toggle_AntExt
            // 
            this.ID_toggle_AntExt.AutoSize = true;
            this.ID_toggle_AntExt.Location = new System.Drawing.Point(150, 210);
            this.ID_toggle_AntExt.Name = "ID_toggle_AntExt";
            this.ID_toggle_AntExt.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_AntExt.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_AntExt.TabIndex = 26;
            this.ID_toggle_AntExt.Text = "Off";
            this.ID_toggle_AntExt.UseSelectable = true;
            // 
            // ID_toggle_GuidaLuce
            // 
            this.ID_toggle_GuidaLuce.AutoSize = true;
            this.ID_toggle_GuidaLuce.Location = new System.Drawing.Point(150, 180);
            this.ID_toggle_GuidaLuce.Name = "ID_toggle_GuidaLuce";
            this.ID_toggle_GuidaLuce.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_GuidaLuce.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_GuidaLuce.TabIndex = 25;
            this.ID_toggle_GuidaLuce.Text = "Off";
            this.ID_toggle_GuidaLuce.UseSelectable = true;
            // 
            // ID_toggle_TastEmerg
            // 
            this.ID_toggle_TastEmerg.AutoSize = true;
            this.ID_toggle_TastEmerg.Location = new System.Drawing.Point(150, 150);
            this.ID_toggle_TastEmerg.Name = "ID_toggle_TastEmerg";
            this.ID_toggle_TastEmerg.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_TastEmerg.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_TastEmerg.TabIndex = 24;
            this.ID_toggle_TastEmerg.Text = "Off";
            this.ID_toggle_TastEmerg.UseSelectable = true;
            // 
            // ID_toggle_PlugPLE
            // 
            this.ID_toggle_PlugPLE.AutoSize = true;
            this.ID_toggle_PlugPLE.Location = new System.Drawing.Point(150, 120);
            this.ID_toggle_PlugPLE.Name = "ID_toggle_PlugPLE";
            this.ID_toggle_PlugPLE.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_PlugPLE.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_PlugPLE.TabIndex = 23;
            this.ID_toggle_PlugPLE.Text = "Off";
            this.ID_toggle_PlugPLE.UseSelectable = true;
            // 
            // ID_toggle_PlugExp
            // 
            this.ID_toggle_PlugExp.AutoSize = true;
            this.ID_toggle_PlugExp.Checked = true;
            this.ID_toggle_PlugExp.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ID_toggle_PlugExp.Location = new System.Drawing.Point(150, 90);
            this.ID_toggle_PlugExp.Name = "ID_toggle_PlugExp";
            this.ID_toggle_PlugExp.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_PlugExp.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_PlugExp.TabIndex = 22;
            this.ID_toggle_PlugExp.Text = "On";
            this.ID_toggle_PlugExp.UseSelectable = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(5, 270);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(95, 19);
            this.metroLabel11.TabIndex = 20;
            this.metroLabel11.Text = "Proporzionale:";
            this.metroLabel11.UseCustomBackColor = true;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(5, 240);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(64, 19);
            this.metroLabel12.TabIndex = 19;
            this.metroLabel12.Text = "CAN Bus:";
            this.metroLabel12.UseCustomBackColor = true;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(5, 210);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(106, 19);
            this.metroLabel13.TabIndex = 18;
            this.metroLabel13.Text = "Antenna Esterna:";
            this.metroLabel13.UseCustomBackColor = true;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(5, 180);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(76, 19);
            this.metroLabel14.TabIndex = 17;
            this.metroLabel14.Text = "Guida Luce:";
            this.metroLabel14.UseCustomBackColor = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(5, 150);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(136, 19);
            this.metroLabel15.TabIndex = 16;
            this.metroLabel15.Text = "Tastiera d\'emergenza:";
            this.metroLabel15.UseCustomBackColor = true;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(5, 120);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(63, 19);
            this.metroLabel16.TabIndex = 15;
            this.metroLabel16.Text = "Plug PLE:";
            this.metroLabel16.UseCustomBackColor = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(5, 90);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(63, 19);
            this.metroLabel17.TabIndex = 14;
            this.metroLabel17.Text = "Plug Exp:";
            this.metroLabel17.UseCustomBackColor = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(5, 60);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(111, 19);
            this.metroLabel18.TabIndex = 13;
            this.metroLabel18.Text = "Frequenza Radio:";
            this.metroLabel18.UseCustomBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(160, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "label1";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.famProdSchedeBindingSource;
            this.comboBox1.DisplayMember = "Prod_Sch";
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 15;
            this.comboBox1.Location = new System.Drawing.Point(150, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 23);
            this.comboBox1.TabIndex = 11;
            // 
            // famProdSchedeBindingSource
            // 
            this.famProdSchedeBindingSource.DataMember = "Fam_Prod_Schede";
            this.famProdSchedeBindingSource.DataSource = this.famProdBindingSource;
            // 
            // famProdBindingSource
            // 
            this.famProdBindingSource.DataMember = "Fam_Prod";
            this.famProdBindingSource.DataSource = this.dB_FactoryDataSet;
            this.famProdBindingSource.CurrentChanged += new System.EventHandler(this.famProdBindingSource_CurrentChanged);
            // 
            // dB_FactoryDataSet
            // 
            this.dB_FactoryDataSet.DataSetName = "DB_FactoryDataSet";
            this.dB_FactoryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(5, 30);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(108, 19);
            this.metroLabel19.TabIndex = 9;
            this.metroLabel19.Text = "Scheda utilizzata:";
            this.metroLabel19.UseCustomBackColor = true;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel20.Location = new System.Drawing.Point(0, 0);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(90, 25);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel20.TabIndex = 7;
            this.metroLabel20.Text = "Controller";
            this.metroLabel20.UseCustomBackColor = true;
            this.metroLabel20.UseStyleColors = true;
            // 
            // pan_SW__P_Testi
            // 
            this.pan_SW__P_Testi.BackColor = System.Drawing.Color.Linen;
            this.SW_Layout.SetColumnSpan(this.pan_SW__P_Testi, 4);
            this.pan_SW__P_Testi.Controls.Add(this.pan_P_Dx_Funzionamento);
            this.pan_SW__P_Testi.Controls.Add(this.pan_P_Dx_revisioni);
            this.pan_SW__P_Testi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW__P_Testi.HorizontalScrollbarBarColor = true;
            this.pan_SW__P_Testi.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW__P_Testi.HorizontalScrollbarSize = 10;
            this.pan_SW__P_Testi.Location = new System.Drawing.Point(675, 180);
            this.pan_SW__P_Testi.Name = "pan_SW__P_Testi";
            this.pan_SW__P_Testi.Size = new System.Drawing.Size(448, 415);
            this.pan_SW__P_Testi.TabIndex = 54;
            this.pan_SW__P_Testi.UseCustomBackColor = true;
            this.pan_SW__P_Testi.VerticalScrollbarBarColor = true;
            this.pan_SW__P_Testi.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW__P_Testi.VerticalScrollbarSize = 10;
            // 
            // pan_P_Dx_Funzionamento
            // 
            this.pan_P_Dx_Funzionamento.BackColor = System.Drawing.Color.Transparent;
            this.pan_P_Dx_Funzionamento.Controls.Add(this.funz_fill);
            this.pan_P_Dx_Funzionamento.Controls.Add(this.funz_top);
            this.pan_P_Dx_Funzionamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_Funzionamento.HorizontalScrollbarSize = 10;
            this.pan_P_Dx_Funzionamento.Location = new System.Drawing.Point(0, 150);
            this.pan_P_Dx_Funzionamento.Name = "pan_P_Dx_Funzionamento";
            this.pan_P_Dx_Funzionamento.Size = new System.Drawing.Size(448, 265);
            this.pan_P_Dx_Funzionamento.TabIndex = 12;
            this.pan_P_Dx_Funzionamento.UseCustomBackColor = true;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarBarColor = true;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_Funzionamento.VerticalScrollbarSize = 10;
            // 
            // funz_fill
            // 
            this.funz_fill.BackColor = System.Drawing.Color.Linen;
            this.funz_fill.Controls.Add(this.richtb_Funzioni);
            this.funz_fill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.funz_fill.HorizontalScrollbarBarColor = true;
            this.funz_fill.HorizontalScrollbarHighlightOnWheel = false;
            this.funz_fill.HorizontalScrollbarSize = 10;
            this.funz_fill.Location = new System.Drawing.Point(0, 15);
            this.funz_fill.Name = "funz_fill";
            this.funz_fill.Size = new System.Drawing.Size(448, 250);
            this.funz_fill.TabIndex = 13;
            this.funz_fill.UseCustomBackColor = true;
            this.funz_fill.VerticalScrollbarBarColor = true;
            this.funz_fill.VerticalScrollbarHighlightOnWheel = false;
            this.funz_fill.VerticalScrollbarSize = 10;
            // 
            // richtb_Funzioni
            // 
            this.richtb_Funzioni.BackColor = System.Drawing.Color.Linen;
            this.richtb_Funzioni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richtb_Funzioni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richtb_Funzioni.Location = new System.Drawing.Point(0, 0);
            this.richtb_Funzioni.Name = "richtb_Funzioni";
            this.richtb_Funzioni.Size = new System.Drawing.Size(448, 250);
            this.richtb_Funzioni.TabIndex = 11;
            this.richtb_Funzioni.Text = "";
            // 
            // funz_top
            // 
            this.funz_top.BackColor = System.Drawing.Color.Linen;
            this.funz_top.Controls.Add(this.metroLabel32);
            this.funz_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.funz_top.HorizontalScrollbarBarColor = true;
            this.funz_top.HorizontalScrollbarHighlightOnWheel = false;
            this.funz_top.HorizontalScrollbarSize = 10;
            this.funz_top.Location = new System.Drawing.Point(0, 0);
            this.funz_top.Name = "funz_top";
            this.funz_top.Size = new System.Drawing.Size(448, 15);
            this.funz_top.TabIndex = 12;
            this.funz_top.UseCustomBackColor = true;
            this.funz_top.VerticalScrollbarBarColor = true;
            this.funz_top.VerticalScrollbarHighlightOnWheel = false;
            this.funz_top.VerticalScrollbarSize = 10;
            // 
            // metroLabel32
            // 
            this.metroLabel32.AutoSize = true;
            this.metroLabel32.Location = new System.Drawing.Point(0, 0);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(102, 19);
            this.metroLabel32.TabIndex = 10;
            this.metroLabel32.Text = "Funzionamento:";
            this.metroLabel32.UseCustomBackColor = true;
            // 
            // pan_P_Dx_revisioni
            // 
            this.pan_P_Dx_revisioni.BackColor = System.Drawing.Color.Transparent;
            this.pan_P_Dx_revisioni.Controls.Add(this.rev_fill);
            this.pan_P_Dx_revisioni.Controls.Add(this.rev_top);
            this.pan_P_Dx_revisioni.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_P_Dx_revisioni.HorizontalScrollbarBarColor = true;
            this.pan_P_Dx_revisioni.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_revisioni.HorizontalScrollbarSize = 10;
            this.pan_P_Dx_revisioni.Location = new System.Drawing.Point(0, 0);
            this.pan_P_Dx_revisioni.Name = "pan_P_Dx_revisioni";
            this.pan_P_Dx_revisioni.Size = new System.Drawing.Size(448, 150);
            this.pan_P_Dx_revisioni.TabIndex = 11;
            this.pan_P_Dx_revisioni.UseCustomBackColor = true;
            this.pan_P_Dx_revisioni.VerticalScrollbarBarColor = true;
            this.pan_P_Dx_revisioni.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_Dx_revisioni.VerticalScrollbarSize = 10;
            // 
            // rev_fill
            // 
            this.rev_fill.Controls.Add(this.richtb_Revisioni);
            this.rev_fill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rev_fill.HorizontalScrollbarBarColor = true;
            this.rev_fill.HorizontalScrollbarHighlightOnWheel = false;
            this.rev_fill.HorizontalScrollbarSize = 10;
            this.rev_fill.Location = new System.Drawing.Point(0, 20);
            this.rev_fill.Name = "rev_fill";
            this.rev_fill.Size = new System.Drawing.Size(448, 130);
            this.rev_fill.TabIndex = 13;
            this.rev_fill.VerticalScrollbarBarColor = true;
            this.rev_fill.VerticalScrollbarHighlightOnWheel = false;
            this.rev_fill.VerticalScrollbarSize = 10;
            // 
            // richtb_Revisioni
            // 
            this.richtb_Revisioni.BackColor = System.Drawing.Color.Linen;
            this.richtb_Revisioni.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.richtb_Revisioni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richtb_Revisioni.Location = new System.Drawing.Point(0, 0);
            this.richtb_Revisioni.Name = "richtb_Revisioni";
            this.richtb_Revisioni.Size = new System.Drawing.Size(448, 130);
            this.richtb_Revisioni.TabIndex = 11;
            this.richtb_Revisioni.Text = "";
            // 
            // rev_top
            // 
            this.rev_top.BackColor = System.Drawing.Color.Linen;
            this.rev_top.Controls.Add(this.metroLabel33);
            this.rev_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.rev_top.HorizontalScrollbarBarColor = true;
            this.rev_top.HorizontalScrollbarHighlightOnWheel = false;
            this.rev_top.HorizontalScrollbarSize = 10;
            this.rev_top.Location = new System.Drawing.Point(0, 0);
            this.rev_top.Name = "rev_top";
            this.rev_top.Size = new System.Drawing.Size(448, 20);
            this.rev_top.TabIndex = 12;
            this.rev_top.UseCustomBackColor = true;
            this.rev_top.VerticalScrollbarBarColor = true;
            this.rev_top.VerticalScrollbarHighlightOnWheel = false;
            this.rev_top.VerticalScrollbarSize = 10;
            // 
            // metroLabel33
            // 
            this.metroLabel33.AutoSize = true;
            this.metroLabel33.Location = new System.Drawing.Point(0, 0);
            this.metroLabel33.Name = "metroLabel33";
            this.metroLabel33.Size = new System.Drawing.Size(62, 19);
            this.metroLabel33.TabIndex = 10;
            this.metroLabel33.Text = "Revisioni:";
            this.metroLabel33.UseCustomBackColor = true;
            // 
            // pan_SW_P
            // 
            this.SW_Layout.SetColumnSpan(this.pan_SW_P, 6);
            this.pan_SW_P.Controls.Add(this.pan_P_middle);
            this.pan_SW_P.Controls.Add(this.pan_P_top);
            this.pan_SW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_P.HorizontalScrollbarBarColor = true;
            this.pan_SW_P.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_P.HorizontalScrollbarSize = 10;
            this.pan_SW_P.Location = new System.Drawing.Point(3, 180);
            this.pan_SW_P.Name = "pan_SW_P";
            this.pan_SW_P.Size = new System.Drawing.Size(666, 415);
            this.pan_SW_P.TabIndex = 53;
            this.pan_SW_P.VerticalScrollbarBarColor = true;
            this.pan_SW_P.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_P.VerticalScrollbarSize = 10;
            // 
            // pan_P_middle
            // 
            this.pan_P_middle.Controls.Add(this.tb_Max_Pairable);
            this.pan_P_middle.Controls.Add(this.metroLabel30);
            this.pan_P_middle.Controls.Add(this.ID_toggle_ShiftPage);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Torch);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Vibracall);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Buzzer);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_SP);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Accel);
            this.pan_P_middle.Controls.Add(this.ID_toggle_use_Backlight);
            this.pan_P_middle.Controls.Add(this.metroLabel23);
            this.pan_P_middle.Controls.Add(this.metroLabel24);
            this.pan_P_middle.Controls.Add(this.metroLabel25);
            this.pan_P_middle.Controls.Add(this.metroLabel26);
            this.pan_P_middle.Controls.Add(this.metroLabel27);
            this.pan_P_middle.Controls.Add(this.metroLabel28);
            this.pan_P_middle.Controls.Add(this.metroLabel29);
            this.pan_P_middle.Controls.Add(this.metroPanel1);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Fungo);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Torcia);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Vibracall);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Buzzer);
            this.pan_P_middle.Controls.Add(this.ID_toggle_SP);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Accel);
            this.pan_P_middle.Controls.Add(this.ID_toggle_Display);
            this.pan_P_middle.Controls.Add(this.metroLabel9);
            this.pan_P_middle.Controls.Add(this.metroLabel8);
            this.pan_P_middle.Controls.Add(this.metroLabel7);
            this.pan_P_middle.Controls.Add(this.metroLabel6);
            this.pan_P_middle.Controls.Add(this.metroLabel5);
            this.pan_P_middle.Controls.Add(this.metroLabel4);
            this.pan_P_middle.Controls.Add(this.metroLabel3);
            this.pan_P_middle.Controls.Add(this.metroLabel2);
            this.pan_P_middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_middle.HorizontalScrollbarBarColor = true;
            this.pan_P_middle.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_middle.HorizontalScrollbarSize = 10;
            this.pan_P_middle.Location = new System.Drawing.Point(0, 160);
            this.pan_P_middle.Name = "pan_P_middle";
            this.pan_P_middle.Size = new System.Drawing.Size(666, 255);
            this.pan_P_middle.TabIndex = 42;
            this.pan_P_middle.VerticalScrollbarBarColor = true;
            this.pan_P_middle.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_middle.VerticalScrollbarSize = 10;
            // 
            // tb_Max_Pairable
            // 
            this.tb_Max_Pairable.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Max_Pairable.Location = new System.Drawing.Point(424, 188);
            this.tb_Max_Pairable.Name = "tb_Max_Pairable";
            this.tb_Max_Pairable.Size = new System.Drawing.Size(52, 23);
            this.tb_Max_Pairable.TabIndex = 54;
            this.tb_Max_Pairable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.Location = new System.Drawing.Point(251, 185);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(139, 19);
            this.metroLabel30.TabIndex = 51;
            this.metroLabel30.Text = "MAX pairable devices:";
            this.metroLabel30.UseCustomBackColor = true;
            // 
            // ID_toggle_ShiftPage
            // 
            this.ID_toggle_ShiftPage.AutoSize = true;
            this.ID_toggle_ShiftPage.Location = new System.Drawing.Point(396, 165);
            this.ID_toggle_ShiftPage.Name = "ID_toggle_ShiftPage";
            this.ID_toggle_ShiftPage.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_ShiftPage.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_ShiftPage.TabIndex = 50;
            this.ID_toggle_ShiftPage.Text = "Off";
            this.ID_toggle_ShiftPage.UseSelectable = true;
            // 
            // ID_toggle_use_Torch
            // 
            this.ID_toggle_use_Torch.AutoSize = true;
            this.ID_toggle_use_Torch.Location = new System.Drawing.Point(396, 125);
            this.ID_toggle_use_Torch.Name = "ID_toggle_use_Torch";
            this.ID_toggle_use_Torch.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Torch.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Torch.TabIndex = 49;
            this.ID_toggle_use_Torch.Text = "Off";
            this.ID_toggle_use_Torch.UseSelectable = true;
            // 
            // ID_toggle_use_Vibracall
            // 
            this.ID_toggle_use_Vibracall.AutoSize = true;
            this.ID_toggle_use_Vibracall.Location = new System.Drawing.Point(396, 105);
            this.ID_toggle_use_Vibracall.Name = "ID_toggle_use_Vibracall";
            this.ID_toggle_use_Vibracall.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Vibracall.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Vibracall.TabIndex = 48;
            this.ID_toggle_use_Vibracall.Text = "Off";
            this.ID_toggle_use_Vibracall.UseSelectable = true;
            // 
            // ID_toggle_use_Buzzer
            // 
            this.ID_toggle_use_Buzzer.AutoSize = true;
            this.ID_toggle_use_Buzzer.Location = new System.Drawing.Point(396, 85);
            this.ID_toggle_use_Buzzer.Name = "ID_toggle_use_Buzzer";
            this.ID_toggle_use_Buzzer.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Buzzer.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Buzzer.TabIndex = 47;
            this.ID_toggle_use_Buzzer.Text = "Off";
            this.ID_toggle_use_Buzzer.UseSelectable = true;
            // 
            // ID_toggle_use_SP
            // 
            this.ID_toggle_use_SP.AutoSize = true;
            this.ID_toggle_use_SP.Location = new System.Drawing.Point(396, 65);
            this.ID_toggle_use_SP.Name = "ID_toggle_use_SP";
            this.ID_toggle_use_SP.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_SP.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_SP.TabIndex = 46;
            this.ID_toggle_use_SP.Text = "Off";
            this.ID_toggle_use_SP.UseSelectable = true;
            // 
            // ID_toggle_use_Accel
            // 
            this.ID_toggle_use_Accel.AutoSize = true;
            this.ID_toggle_use_Accel.Location = new System.Drawing.Point(396, 45);
            this.ID_toggle_use_Accel.Name = "ID_toggle_use_Accel";
            this.ID_toggle_use_Accel.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Accel.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Accel.TabIndex = 45;
            this.ID_toggle_use_Accel.Text = "Off";
            this.ID_toggle_use_Accel.UseSelectable = true;
            // 
            // ID_toggle_use_Backlight
            // 
            this.ID_toggle_use_Backlight.AutoSize = true;
            this.ID_toggle_use_Backlight.Location = new System.Drawing.Point(396, 25);
            this.ID_toggle_use_Backlight.Name = "ID_toggle_use_Backlight";
            this.ID_toggle_use_Backlight.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_use_Backlight.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_use_Backlight.TabIndex = 44;
            this.ID_toggle_use_Backlight.Text = "Off";
            this.ID_toggle_use_Backlight.UseSelectable = true;
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.Location = new System.Drawing.Point(251, 165);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(102, 19);
            this.metroLabel23.TabIndex = 43;
            this.metroLabel23.Text = "Cambio Pagina:";
            this.metroLabel23.UseCustomBackColor = true;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(251, 125);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(71, 19);
            this.metroLabel24.TabIndex = 42;
            this.metroLabel24.Text = "Usa Torcia:";
            this.metroLabel24.UseCustomBackColor = true;
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(251, 105);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(87, 19);
            this.metroLabel25.TabIndex = 41;
            this.metroLabel25.Text = "Usa Vibracall:";
            this.metroLabel25.UseCustomBackColor = true;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(251, 85);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(77, 19);
            this.metroLabel26.TabIndex = 40;
            this.metroLabel26.Text = "Usa Buzzer:";
            this.metroLabel26.UseCustomBackColor = true;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.Location = new System.Drawing.Point(251, 65);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(105, 19);
            this.metroLabel27.TabIndex = 39;
            this.metroLabel27.Text = "Usa Safety Point:";
            this.metroLabel27.UseCustomBackColor = true;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.Location = new System.Drawing.Point(251, 45);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(124, 19);
            this.metroLabel28.TabIndex = 38;
            this.metroLabel28.Text = "Usa Accelerometro:";
            this.metroLabel28.UseCustomBackColor = true;
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(251, 25);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(89, 19);
            this.metroLabel29.TabIndex = 37;
            this.metroLabel29.Text = "Use Backlight:";
            this.metroLabel29.UseCustomBackColor = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.ID_radio_None_P);
            this.metroPanel1.Controls.Add(this.ID_radio_Filo_P);
            this.metroPanel1.Controls.Add(this.ID_radio_868_P);
            this.metroPanel1.Controls.Add(this.ID_radio_433_P);
            this.metroPanel1.Controls.Add(this.ID_radio_915_P);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(150, 8);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(353, 16);
            this.metroPanel1.TabIndex = 36;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // ID_radio_None_P
            // 
            this.ID_radio_None_P.AutoSize = true;
            this.ID_radio_None_P.Location = new System.Drawing.Point(240, 0);
            this.ID_radio_None_P.Name = "ID_radio_None_P";
            this.ID_radio_None_P.Size = new System.Drawing.Size(52, 15);
            this.ID_radio_None_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_None_P.TabIndex = 36;
            this.ID_radio_None_P.Text = "None";
            this.ID_radio_None_P.UseCustomBackColor = true;
            this.ID_radio_None_P.UseSelectable = true;
            this.ID_radio_None_P.UseStyleColors = true;
            // 
            // ID_radio_Filo_P
            // 
            this.ID_radio_Filo_P.AutoSize = true;
            this.ID_radio_Filo_P.Location = new System.Drawing.Point(180, 0);
            this.ID_radio_Filo_P.Name = "ID_radio_Filo_P";
            this.ID_radio_Filo_P.Size = new System.Drawing.Size(42, 15);
            this.ID_radio_Filo_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_Filo_P.TabIndex = 35;
            this.ID_radio_Filo_P.Text = "Filo";
            this.ID_radio_Filo_P.UseCustomBackColor = true;
            this.ID_radio_Filo_P.UseSelectable = true;
            this.ID_radio_Filo_P.UseStyleColors = true;
            // 
            // ID_radio_868_P
            // 
            this.ID_radio_868_P.AutoSize = true;
            this.ID_radio_868_P.Location = new System.Drawing.Point(0, 0);
            this.ID_radio_868_P.Name = "ID_radio_868_P";
            this.ID_radio_868_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_868_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_868_P.TabIndex = 32;
            this.ID_radio_868_P.Text = "868";
            this.ID_radio_868_P.UseCustomBackColor = true;
            this.ID_radio_868_P.UseSelectable = true;
            this.ID_radio_868_P.UseStyleColors = true;
            // 
            // ID_radio_433_P
            // 
            this.ID_radio_433_P.AutoSize = true;
            this.ID_radio_433_P.Location = new System.Drawing.Point(120, 0);
            this.ID_radio_433_P.Name = "ID_radio_433_P";
            this.ID_radio_433_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_433_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_433_P.TabIndex = 34;
            this.ID_radio_433_P.Text = "433";
            this.ID_radio_433_P.UseCustomBackColor = true;
            this.ID_radio_433_P.UseSelectable = true;
            this.ID_radio_433_P.UseStyleColors = true;
            // 
            // ID_radio_915_P
            // 
            this.ID_radio_915_P.AutoSize = true;
            this.ID_radio_915_P.Location = new System.Drawing.Point(60, 0);
            this.ID_radio_915_P.Name = "ID_radio_915_P";
            this.ID_radio_915_P.Size = new System.Drawing.Size(41, 15);
            this.ID_radio_915_P.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_radio_915_P.TabIndex = 33;
            this.ID_radio_915_P.Text = "915";
            this.ID_radio_915_P.UseCustomBackColor = true;
            this.ID_radio_915_P.UseSelectable = true;
            this.ID_radio_915_P.UseStyleColors = true;
            // 
            // ID_toggle_Fungo
            // 
            this.ID_toggle_Fungo.AutoSize = true;
            this.ID_toggle_Fungo.Location = new System.Drawing.Point(150, 145);
            this.ID_toggle_Fungo.Name = "ID_toggle_Fungo";
            this.ID_toggle_Fungo.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Fungo.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Fungo.TabIndex = 28;
            this.ID_toggle_Fungo.Text = "Off";
            this.ID_toggle_Fungo.UseSelectable = true;
            // 
            // ID_toggle_Torcia
            // 
            this.ID_toggle_Torcia.AutoSize = true;
            this.ID_toggle_Torcia.Location = new System.Drawing.Point(150, 125);
            this.ID_toggle_Torcia.Name = "ID_toggle_Torcia";
            this.ID_toggle_Torcia.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Torcia.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Torcia.TabIndex = 27;
            this.ID_toggle_Torcia.Text = "Off";
            this.ID_toggle_Torcia.UseSelectable = true;
            // 
            // ID_toggle_Vibracall
            // 
            this.ID_toggle_Vibracall.AutoSize = true;
            this.ID_toggle_Vibracall.Location = new System.Drawing.Point(150, 105);
            this.ID_toggle_Vibracall.Name = "ID_toggle_Vibracall";
            this.ID_toggle_Vibracall.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Vibracall.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Vibracall.TabIndex = 26;
            this.ID_toggle_Vibracall.Text = "Off";
            this.ID_toggle_Vibracall.UseSelectable = true;
            // 
            // ID_toggle_Buzzer
            // 
            this.ID_toggle_Buzzer.AutoSize = true;
            this.ID_toggle_Buzzer.Location = new System.Drawing.Point(150, 85);
            this.ID_toggle_Buzzer.Name = "ID_toggle_Buzzer";
            this.ID_toggle_Buzzer.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Buzzer.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Buzzer.TabIndex = 25;
            this.ID_toggle_Buzzer.Text = "Off";
            this.ID_toggle_Buzzer.UseSelectable = true;
            // 
            // ID_toggle_SP
            // 
            this.ID_toggle_SP.AutoSize = true;
            this.ID_toggle_SP.Location = new System.Drawing.Point(150, 65);
            this.ID_toggle_SP.Name = "ID_toggle_SP";
            this.ID_toggle_SP.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_SP.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_SP.TabIndex = 24;
            this.ID_toggle_SP.Text = "Off";
            this.ID_toggle_SP.UseSelectable = true;
            // 
            // ID_toggle_Accel
            // 
            this.ID_toggle_Accel.AutoSize = true;
            this.ID_toggle_Accel.Location = new System.Drawing.Point(150, 45);
            this.ID_toggle_Accel.Name = "ID_toggle_Accel";
            this.ID_toggle_Accel.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Accel.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Accel.TabIndex = 23;
            this.ID_toggle_Accel.Text = "Off";
            this.ID_toggle_Accel.UseSelectable = true;
            // 
            // ID_toggle_Display
            // 
            this.ID_toggle_Display.AutoSize = true;
            this.ID_toggle_Display.Location = new System.Drawing.Point(150, 25);
            this.ID_toggle_Display.Name = "ID_toggle_Display";
            this.ID_toggle_Display.Size = new System.Drawing.Size(80, 17);
            this.ID_toggle_Display.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_toggle_Display.TabIndex = 22;
            this.ID_toggle_Display.Text = "Off";
            this.ID_toggle_Display.UseSelectable = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(5, 145);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(119, 19);
            this.metroLabel9.TabIndex = 20;
            this.metroLabel9.Text = "Fungo Emergenza:";
            this.metroLabel9.UseCustomBackColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(5, 125);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(46, 19);
            this.metroLabel8.TabIndex = 19;
            this.metroLabel8.Text = "Torcia:";
            this.metroLabel8.UseCustomBackColor = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(5, 105);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(62, 19);
            this.metroLabel7.TabIndex = 18;
            this.metroLabel7.Text = "Vibracall:";
            this.metroLabel7.UseCustomBackColor = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(5, 85);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(52, 19);
            this.metroLabel6.TabIndex = 17;
            this.metroLabel6.Text = "Buzzer:";
            this.metroLabel6.UseCustomBackColor = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(5, 65);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(80, 19);
            this.metroLabel5.TabIndex = 16;
            this.metroLabel5.Text = "Safety Point:";
            this.metroLabel5.UseCustomBackColor = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(5, 45);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(99, 19);
            this.metroLabel4.TabIndex = 15;
            this.metroLabel4.Text = "Accelerometro:";
            this.metroLabel4.UseCustomBackColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(5, 25);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(86, 19);
            this.metroLabel3.TabIndex = 14;
            this.metroLabel3.Text = "Display Oled:";
            this.metroLabel3.UseCustomBackColor = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(5, 5);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(111, 19);
            this.metroLabel2.TabIndex = 13;
            this.metroLabel2.Text = "Frequenza Radio:";
            this.metroLabel2.UseCustomBackColor = true;
            // 
            // pan_P_top
            // 
            this.pan_P_top.BackColor = System.Drawing.Color.White;
            this.pan_P_top.Controls.Add(this.pan_P_top_grid);
            this.pan_P_top.Controls.Add(this.pan_P_top_left);
            this.pan_P_top.Controls.Add(this.pan_P_top_top);
            this.pan_P_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_P_top.HorizontalScrollbarBarColor = true;
            this.pan_P_top.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_top.HorizontalScrollbarSize = 10;
            this.pan_P_top.Location = new System.Drawing.Point(0, 0);
            this.pan_P_top.Name = "pan_P_top";
            this.pan_P_top.Size = new System.Drawing.Size(666, 160);
            this.pan_P_top.TabIndex = 41;
            this.pan_P_top.VerticalScrollbarBarColor = true;
            this.pan_P_top.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_top.VerticalScrollbarSize = 10;
            // 
            // pan_P_top_grid
            // 
            this.pan_P_top_grid.Controls.Add(this.grid_P_SchedeCompatibili);
            this.pan_P_top_grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_P_top_grid.HorizontalScrollbarBarColor = true;
            this.pan_P_top_grid.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_top_grid.HorizontalScrollbarSize = 10;
            this.pan_P_top_grid.Location = new System.Drawing.Point(120, 30);
            this.pan_P_top_grid.Name = "pan_P_top_grid";
            this.pan_P_top_grid.Size = new System.Drawing.Size(546, 130);
            this.pan_P_top_grid.TabIndex = 43;
            this.pan_P_top_grid.VerticalScrollbarBarColor = true;
            this.pan_P_top_grid.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_top_grid.VerticalScrollbarSize = 10;
            // 
            // grid_P_SchedeCompatibili
            // 
            this.grid_P_SchedeCompatibili.AllowUserToAddRows = false;
            this.grid_P_SchedeCompatibili.AllowUserToDeleteRows = false;
            this.grid_P_SchedeCompatibili.AllowUserToResizeRows = false;
            this.grid_P_SchedeCompatibili.AutoGenerateColumns = false;
            this.grid_P_SchedeCompatibili.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grid_P_SchedeCompatibili.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_P_SchedeCompatibili.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_P_SchedeCompatibili.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_P_SchedeCompatibili.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_P_SchedeCompatibili.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.grid_P_SchedeCompatibili.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_P_SchedeCompatibili.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.P_prodSch,
            this.P_prodDescrizione,
            this.P_SchedaCompatibile});
            this.grid_P_SchedeCompatibili.DataSource = this.famProdSchedeBindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_P_SchedeCompatibili.DefaultCellStyle = dataGridViewCellStyle5;
            this.grid_P_SchedeCompatibili.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_P_SchedeCompatibili.EnableHeadersVisualStyles = false;
            this.grid_P_SchedeCompatibili.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_P_SchedeCompatibili.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_P_SchedeCompatibili.HighLightPercentage = 1.5F;
            this.grid_P_SchedeCompatibili.Location = new System.Drawing.Point(0, 0);
            this.grid_P_SchedeCompatibili.Name = "grid_P_SchedeCompatibili";
            this.grid_P_SchedeCompatibili.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_P_SchedeCompatibili.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.grid_P_SchedeCompatibili.RowHeadersVisible = false;
            this.grid_P_SchedeCompatibili.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_P_SchedeCompatibili.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_P_SchedeCompatibili.Size = new System.Drawing.Size(546, 130);
            this.grid_P_SchedeCompatibili.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_P_SchedeCompatibili.TabIndex = 40;
            this.grid_P_SchedeCompatibili.UseStyleColors = true;
            this.grid_P_SchedeCompatibili.Validated += new System.EventHandler(this.grid_P_SchedeCompatibili_Validated);
            // 
            // P_prodSch
            // 
            this.P_prodSch.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.P_prodSch.DataPropertyName = "Prod_Sch";
            this.P_prodSch.FillWeight = 20F;
            this.P_prodSch.HeaderText = "Scheda";
            this.P_prodSch.Name = "P_prodSch";
            // 
            // P_prodDescrizione
            // 
            this.P_prodDescrizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.P_prodDescrizione.DataPropertyName = "Prod_Descrizione";
            this.P_prodDescrizione.FillWeight = 60F;
            this.P_prodDescrizione.HeaderText = "Descrizione Scheda";
            this.P_prodDescrizione.Name = "P_prodDescrizione";
            // 
            // P_SchedaCompatibile
            // 
            this.P_SchedaCompatibile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.P_SchedaCompatibile.FillWeight = 20F;
            this.P_SchedaCompatibile.HeaderText = "Scheda compatibile (Si/No)";
            this.P_SchedaCompatibile.Name = "P_SchedaCompatibile";
            // 
            // pan_P_top_left
            // 
            this.pan_P_top_left.Controls.Add(this.metroLabel1);
            this.pan_P_top_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_P_top_left.HorizontalScrollbarBarColor = true;
            this.pan_P_top_left.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_top_left.HorizontalScrollbarSize = 10;
            this.pan_P_top_left.Location = new System.Drawing.Point(0, 30);
            this.pan_P_top_left.Name = "pan_P_top_left";
            this.pan_P_top_left.Size = new System.Drawing.Size(120, 130);
            this.pan_P_top_left.TabIndex = 42;
            this.pan_P_top_left.VerticalScrollbarBarColor = true;
            this.pan_P_top_left.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_top_left.VerticalScrollbarSize = 10;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(5, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(108, 19);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Scheda utilizzata:";
            this.metroLabel1.UseCustomBackColor = true;
            // 
            // pan_P_top_top
            // 
            this.pan_P_top_top.BackColor = System.Drawing.Color.White;
            this.pan_P_top_top.Controls.Add(this.ID_lab_Palmare);
            this.pan_P_top_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_P_top_top.HorizontalScrollbarBarColor = true;
            this.pan_P_top_top.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_P_top_top.HorizontalScrollbarSize = 10;
            this.pan_P_top_top.Location = new System.Drawing.Point(0, 0);
            this.pan_P_top_top.Name = "pan_P_top_top";
            this.pan_P_top_top.Size = new System.Drawing.Size(666, 30);
            this.pan_P_top_top.TabIndex = 41;
            this.pan_P_top_top.VerticalScrollbarBarColor = true;
            this.pan_P_top_top.VerticalScrollbarHighlightOnWheel = false;
            this.pan_P_top_top.VerticalScrollbarSize = 10;
            // 
            // ID_lab_Palmare
            // 
            this.ID_lab_Palmare.AutoSize = true;
            this.ID_lab_Palmare.Dock = System.Windows.Forms.DockStyle.Top;
            this.ID_lab_Palmare.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.ID_lab_Palmare.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.ID_lab_Palmare.Location = new System.Drawing.Point(0, 0);
            this.ID_lab_Palmare.Name = "ID_lab_Palmare";
            this.ID_lab_Palmare.Size = new System.Drawing.Size(74, 25);
            this.ID_lab_Palmare.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_lab_Palmare.TabIndex = 7;
            this.ID_lab_Palmare.Text = "Palmare";
            this.ID_lab_Palmare.UseCustomBackColor = true;
            this.ID_lab_Palmare.UseStyleColors = true;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroLabel22.Location = new System.Drawing.Point(339, 52);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(106, 19);
            this.metroLabel22.TabIndex = 13;
            this.metroLabel22.Text = "Software già codificati:";
            this.metroLabel22.UseCustomBackColor = true;
            // 
            // grid_SW_codificati
            // 
            this.grid_SW_codificati.AllowUserToAddRows = false;
            this.grid_SW_codificati.AllowUserToDeleteRows = false;
            this.grid_SW_codificati.AllowUserToResizeRows = false;
            this.grid_SW_codificati.AutoGenerateColumns = false;
            this.grid_SW_codificati.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid_SW_codificati.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SW_codificati.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_SW_codificati.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_SW_codificati.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SW_codificati.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grid_SW_codificati.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_SW_codificati.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sWCodeDataGridViewTextBoxColumn,
            this.SW_Customer});
            this.SW_Layout.SetColumnSpan(this.grid_SW_codificati, 6);
            this.grid_SW_codificati.DataSource = this.famProdSoftwareBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_SW_codificati.DefaultCellStyle = dataGridViewCellStyle2;
            this.grid_SW_codificati.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_SW_codificati.EnableHeadersVisualStyles = false;
            this.grid_SW_codificati.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_SW_codificati.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_SW_codificati.HighLightPercentage = 1.5F;
            this.grid_SW_codificati.Location = new System.Drawing.Point(451, 55);
            this.grid_SW_codificati.MultiSelect = false;
            this.grid_SW_codificati.Name = "grid_SW_codificati";
            this.grid_SW_codificati.ReadOnly = true;
            this.grid_SW_codificati.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_SW_codificati.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grid_SW_codificati.RowHeadersVisible = false;
            this.grid_SW_codificati.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_SW_codificati.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_SW_codificati.Size = new System.Drawing.Size(672, 94);
            this.grid_SW_codificati.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_SW_codificati.TabIndex = 15;
            // 
            // sWCodeDataGridViewTextBoxColumn
            // 
            this.sWCodeDataGridViewTextBoxColumn.DataPropertyName = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn.HeaderText = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn.Name = "sWCodeDataGridViewTextBoxColumn";
            this.sWCodeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // SW_Customer
            // 
            this.SW_Customer.DataPropertyName = "SW_Customer";
            this.SW_Customer.HeaderText = "Cliente";
            this.SW_Customer.Name = "SW_Customer";
            this.SW_Customer.ReadOnly = true;
            // 
            // famProdSoftwareBindingSource
            // 
            this.famProdSoftwareBindingSource.DataMember = "Fam_Prod_Software";
            this.famProdSoftwareBindingSource.DataSource = this.famProdBindingSource;
            this.famProdSoftwareBindingSource.CurrentChanged += new System.EventHandler(this.famProdSoftwareBindingSource_CurrentChanged);
            // 
            // pan_SW_Codifica
            // 
            this.pan_SW_Codifica.BackColor = System.Drawing.Color.Bisque;
            this.SW_Layout.SetColumnSpan(this.pan_SW_Codifica, 10);
            this.pan_SW_Codifica.Controls.Add(this.metroLabel10);
            this.pan_SW_Codifica.Controls.Add(this.SW_lab_codice_SW);
            this.pan_SW_Codifica.Controls.Add(this.metroLabel21);
            this.pan_SW_Codifica.Controls.Add(this.tbox_Sw_name);
            this.pan_SW_Codifica.Controls.Add(this.tbox_Sw_version);
            this.pan_SW_Codifica.Controls.Add(this.tbox_Sw_frequency);
            this.pan_SW_Codifica.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_Codifica.HorizontalScrollbarBarColor = true;
            this.pan_SW_Codifica.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_Codifica.HorizontalScrollbarSize = 10;
            this.pan_SW_Codifica.Location = new System.Drawing.Point(3, 155);
            this.pan_SW_Codifica.Name = "pan_SW_Codifica";
            this.pan_SW_Codifica.Size = new System.Drawing.Size(1120, 19);
            this.pan_SW_Codifica.TabIndex = 17;
            this.pan_SW_Codifica.UseCustomBackColor = true;
            this.pan_SW_Codifica.VerticalScrollbarBarColor = true;
            this.pan_SW_Codifica.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_Codifica.VerticalScrollbarSize = 10;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel10.Location = new System.Drawing.Point(330, 3);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(22, 19);
            this.metroLabel10.TabIndex = 13;
            this.metroLabel10.Text = "_L";
            this.metroLabel10.UseCustomBackColor = true;
            // 
            // SW_lab_codice_SW
            // 
            this.SW_lab_codice_SW.AutoSize = true;
            this.SW_lab_codice_SW.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.SW_lab_codice_SW.Location = new System.Drawing.Point(5, 3);
            this.SW_lab_codice_SW.Name = "SW_lab_codice_SW";
            this.SW_lab_codice_SW.Size = new System.Drawing.Size(110, 19);
            this.SW_lab_codice_SW.Style = MetroFramework.MetroColorStyle.Red;
            this.SW_lab_codice_SW.TabIndex = 7;
            this.SW_lab_codice_SW.Text = "Codice Software:";
            this.SW_lab_codice_SW.UseCustomBackColor = true;
            this.SW_lab_codice_SW.UseStyleColors = true;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel21.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel21.Location = new System.Drawing.Point(119, 3);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(49, 19);
            this.metroLabel21.TabIndex = 8;
            this.metroLabel21.Text = "XSWR";
            this.metroLabel21.UseCustomBackColor = true;
            // 
            // tbox_Sw_name
            // 
            this.tbox_Sw_name.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_name.Location = new System.Drawing.Point(170, 1);
            this.tbox_Sw_name.Mask = ">AAAAA";
            this.tbox_Sw_name.Name = "tbox_Sw_name";
            this.tbox_Sw_name.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_name.TabIndex = 10;
            this.tbox_Sw_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_name.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_name_Validating);
            // 
            // tbox_Sw_version
            // 
            this.tbox_Sw_version.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_version.Location = new System.Drawing.Point(225, 1);
            this.tbox_Sw_version.Mask = ">AAA";
            this.tbox_Sw_version.Name = "tbox_Sw_version";
            this.tbox_Sw_version.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_version.TabIndex = 11;
            this.tbox_Sw_version.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_version.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_version_Validating);
            // 
            // tbox_Sw_frequency
            // 
            this.tbox_Sw_frequency.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.tbox_Sw_frequency.Location = new System.Drawing.Point(280, 1);
            this.tbox_Sw_frequency.Mask = ">&";
            this.tbox_Sw_frequency.Name = "tbox_Sw_frequency";
            this.tbox_Sw_frequency.Size = new System.Drawing.Size(44, 23);
            this.tbox_Sw_frequency.TabIndex = 12;
            this.tbox_Sw_frequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbox_Sw_frequency.Validating += new System.ComponentModel.CancelEventHandler(this.tbox_Sw_frequency_Validating);
            // 
            // SW_lab_Famiglia
            // 
            this.SW_lab_Famiglia.AutoSize = true;
            this.SW_lab_Famiglia.Dock = System.Windows.Forms.DockStyle.Top;
            this.SW_lab_Famiglia.Location = new System.Drawing.Point(3, 52);
            this.SW_lab_Famiglia.Name = "SW_lab_Famiglia";
            this.SW_lab_Famiglia.Size = new System.Drawing.Size(106, 19);
            this.SW_lab_Famiglia.TabIndex = 3;
            this.SW_lab_Famiglia.Text = "Famiglia di prodotto:";
            this.SW_lab_Famiglia.UseCustomBackColor = true;
            // 
            // ID_combo_Famiglia
            // 
            this.ID_combo_Famiglia.BackColor = System.Drawing.SystemColors.Window;
            this.SW_Layout.SetColumnSpan(this.ID_combo_Famiglia, 2);
            this.ID_combo_Famiglia.DataSource = this.famProdBindingSource;
            this.ID_combo_Famiglia.DisplayMember = "Fam_Name";
            this.ID_combo_Famiglia.Dock = System.Windows.Forms.DockStyle.Top;
            this.ID_combo_Famiglia.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ID_combo_Famiglia.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_combo_Famiglia.FormattingEnabled = true;
            this.ID_combo_Famiglia.ItemHeight = 15;
            this.ID_combo_Famiglia.Location = new System.Drawing.Point(115, 55);
            this.ID_combo_Famiglia.Name = "ID_combo_Famiglia";
            this.ID_combo_Famiglia.Size = new System.Drawing.Size(218, 23);
            this.ID_combo_Famiglia.TabIndex = 6;
            // 
            // pan_SW_Titolo
            // 
            this.SW_Layout.SetColumnSpan(this.pan_SW_Titolo, 10);
            this.pan_SW_Titolo.Controls.Add(this.titolo_ID);
            this.pan_SW_Titolo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_Titolo.HorizontalScrollbarBarColor = true;
            this.pan_SW_Titolo.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_Titolo.HorizontalScrollbarSize = 10;
            this.pan_SW_Titolo.Location = new System.Drawing.Point(3, 3);
            this.pan_SW_Titolo.Name = "pan_SW_Titolo";
            this.pan_SW_Titolo.Size = new System.Drawing.Size(1120, 22);
            this.pan_SW_Titolo.TabIndex = 18;
            this.pan_SW_Titolo.UseCustomBackColor = true;
            this.pan_SW_Titolo.VerticalScrollbarBarColor = true;
            this.pan_SW_Titolo.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_Titolo.VerticalScrollbarSize = 10;
            // 
            // titolo_ID
            // 
            this.titolo_ID.AutoSize = true;
            this.titolo_ID.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.titolo_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.titolo_ID.Location = new System.Drawing.Point(0, 0);
            this.titolo_ID.Name = "titolo_ID";
            this.titolo_ID.Size = new System.Drawing.Size(166, 25);
            this.titolo_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.titolo_ID.TabIndex = 2;
            this.titolo_ID.Text = "Datasheet Software";
            this.titolo_ID.UseCustomBackColor = true;
            this.titolo_ID.UseStyleColors = true;
            // 
            // fam_ProdTableAdapter
            // 
            this.fam_ProdTableAdapter.ClearBeforeFill = true;
            // 
            // schedeTableAdapter
            // 
            this.schedeTableAdapter.ClearBeforeFill = true;
            // 
            // softwareTableAdapter
            // 
            this.softwareTableAdapter.ClearBeforeFill = true;
            // 
            // metroContextMenu1
            // 
            this.metroContextMenu1.Name = "metroContextMenu1";
            this.metroContextMenu1.Size = new System.Drawing.Size(61, 4);
            // 
            // SW_Layout
            // 
            this.SW_Layout.ColumnCount = 10;
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.SW_Layout.Controls.Add(this.SW_lab_Famiglia, 0, 3);
            this.SW_Layout.Controls.Add(this.ID_combo_Famiglia, 1, 3);
            this.SW_Layout.Controls.Add(this.metroLabel22, 3, 3);
            this.SW_Layout.Controls.Add(this.grid_SW_codificati, 4, 3);
            this.SW_Layout.Controls.Add(this.pan_SW_Titolo, 0, 0);
            this.SW_Layout.Controls.Add(this.pan_Menu_comandi, 0, 2);
            this.SW_Layout.Controls.Add(this.pan_Menu_salva, 6, 2);
            this.SW_Layout.Controls.Add(this.pan_Menu_exit, 9, 2);
            this.SW_Layout.Controls.Add(this.pan_SW_Codifica, 0, 4);
            this.SW_Layout.Controls.Add(this.pan_SW_P, 0, 5);
            this.SW_Layout.Controls.Add(this.pan_SW__P_Testi, 6, 5);
            this.SW_Layout.Controls.Add(this.pan_SW_C, 0, 6);
            this.SW_Layout.Controls.Add(this.pan_SW__C_Testi, 6, 6);
            this.SW_Layout.Controls.Add(this.pan_SW_C_OLD, 0, 7);
            this.SW_Layout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SW_Layout.Location = new System.Drawing.Point(0, 0);
            this.SW_Layout.Name = "SW_Layout";
            this.SW_Layout.RowCount = 12;
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.SW_Layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.SW_Layout.Size = new System.Drawing.Size(1126, 1500);
            this.SW_Layout.TabIndex = 16;
            // 
            // pan_Menu_comandi
            // 
            this.pan_Menu_comandi.BackColor = System.Drawing.Color.Gainsboro;
            this.SW_Layout.SetColumnSpan(this.pan_Menu_comandi, 6);
            this.pan_Menu_comandi.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_new,
            this.menu_sw_div01,
            this.menu_sw_edit,
            this.menu_sw_div02,
            this.menu_sw_clona,
            this.menu_sw_div03,
            this.creaRevisioneToolStripMenuItem,
            this.menu_sw_div04,
            this.menu_sw_creapdf});
            this.pan_Menu_comandi.Location = new System.Drawing.Point(0, 28);
            this.pan_Menu_comandi.Name = "pan_Menu_comandi";
            this.pan_Menu_comandi.Size = new System.Drawing.Size(672, 24);
            this.pan_Menu_comandi.TabIndex = 12;
            this.pan_Menu_comandi.Text = "menuStrip1";
            // 
            // menu_sw_new
            // 
            this.menu_sw_new.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_new.Image")));
            this.menu_sw_new.Name = "menu_sw_new";
            this.menu_sw_new.Size = new System.Drawing.Size(111, 20);
            this.menu_sw_new.Text = "Nuovo Codice";
            this.menu_sw_new.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // menu_sw_div01
            // 
            this.menu_sw_div01.Enabled = false;
            this.menu_sw_div01.Name = "menu_sw_div01";
            this.menu_sw_div01.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div01.Text = "|";
            // 
            // menu_sw_edit
            // 
            this.menu_sw_edit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_edit.Image")));
            this.menu_sw_edit.Name = "menu_sw_edit";
            this.menu_sw_edit.Size = new System.Drawing.Size(122, 20);
            this.menu_sw_edit.Text = "Modifica Codice";
            this.menu_sw_edit.Click += new System.EventHandler(this.modificaCodiceToolStripMenuItem_Click);
            // 
            // menu_sw_div02
            // 
            this.menu_sw_div02.Enabled = false;
            this.menu_sw_div02.Name = "menu_sw_div02";
            this.menu_sw_div02.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div02.Text = "|";
            // 
            // menu_sw_clona
            // 
            this.menu_sw_clona.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_clona.Image")));
            this.menu_sw_clona.Name = "menu_sw_clona";
            this.menu_sw_clona.Size = new System.Drawing.Size(106, 20);
            this.menu_sw_clona.Text = "Clona Codice";
            // 
            // menu_sw_div03
            // 
            this.menu_sw_div03.Enabled = false;
            this.menu_sw_div03.Name = "menu_sw_div03";
            this.menu_sw_div03.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div03.Text = "|";
            // 
            // creaRevisioneToolStripMenuItem
            // 
            this.creaRevisioneToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("creaRevisioneToolStripMenuItem.Image")));
            this.creaRevisioneToolStripMenuItem.Name = "creaRevisioneToolStripMenuItem";
            this.creaRevisioneToolStripMenuItem.Size = new System.Drawing.Size(112, 20);
            this.creaRevisioneToolStripMenuItem.Text = "Crea Revisione";
            // 
            // menu_sw_div04
            // 
            this.menu_sw_div04.Enabled = false;
            this.menu_sw_div04.Name = "menu_sw_div04";
            this.menu_sw_div04.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div04.Text = "|";
            // 
            // menu_sw_creapdf
            // 
            this.menu_sw_creapdf.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_creapdf.Image")));
            this.menu_sw_creapdf.Name = "menu_sw_creapdf";
            this.menu_sw_creapdf.Size = new System.Drawing.Size(80, 20);
            this.menu_sw_creapdf.Text = "Crea pdf";
            this.menu_sw_creapdf.Click += new System.EventHandler(this.creaPdfToolStripMenuItem_Click);
            // 
            // pan_Menu_salva
            // 
            this.pan_Menu_salva.BackColor = System.Drawing.Color.Gainsboro;
            this.SW_Layout.SetColumnSpan(this.pan_Menu_salva, 3);
            this.pan_Menu_salva.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_div11,
            this.menu_sw_salva,
            this.menu_sw_div12,
            this.menu_sw_annulla});
            this.pan_Menu_salva.Location = new System.Drawing.Point(672, 28);
            this.pan_Menu_salva.Name = "pan_Menu_salva";
            this.pan_Menu_salva.Size = new System.Drawing.Size(336, 24);
            this.pan_Menu_salva.TabIndex = 55;
            this.pan_Menu_salva.Text = "menuStrip1";
            // 
            // menu_sw_div11
            // 
            this.menu_sw_div11.Enabled = false;
            this.menu_sw_div11.Name = "menu_sw_div11";
            this.menu_sw_div11.ShowShortcutKeys = false;
            this.menu_sw_div11.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div11.Text = "|";
            // 
            // menu_sw_salva
            // 
            this.menu_sw_salva.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_salva.Image")));
            this.menu_sw_salva.Name = "menu_sw_salva";
            this.menu_sw_salva.Size = new System.Drawing.Size(62, 20);
            this.menu_sw_salva.Text = "Salva";
            // 
            // menu_sw_div12
            // 
            this.menu_sw_div12.Enabled = false;
            this.menu_sw_div12.Name = "menu_sw_div12";
            this.menu_sw_div12.ShowShortcutKeys = false;
            this.menu_sw_div12.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div12.Text = "|";
            // 
            // menu_sw_annulla
            // 
            this.menu_sw_annulla.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_annulla.Image")));
            this.menu_sw_annulla.Name = "menu_sw_annulla";
            this.menu_sw_annulla.Size = new System.Drawing.Size(76, 20);
            this.menu_sw_annulla.Text = "Annulla";
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(1008, 28);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(118, 24);
            this.pan_Menu_exit.TabIndex = 19;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Enabled = false;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.ShowShortcutKeys = false;
            this.toolStripMenuItem5.Size = new System.Drawing.Size(22, 20);
            this.toolStripMenuItem5.Text = "|";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // pan_SW_C
            // 
            this.SW_Layout.SetColumnSpan(this.pan_SW_C, 6);
            this.pan_SW_C.Controls.Add(this.pan_C_middle);
            this.pan_SW_C.Controls.Add(this.pan_C_top);
            this.pan_SW_C.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW_C.HorizontalScrollbarBarColor = true;
            this.pan_SW_C.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW_C.HorizontalScrollbarSize = 10;
            this.pan_SW_C.Location = new System.Drawing.Point(3, 601);
            this.pan_SW_C.Name = "pan_SW_C";
            this.pan_SW_C.Size = new System.Drawing.Size(666, 415);
            this.pan_SW_C.TabIndex = 56;
            this.pan_SW_C.VerticalScrollbarBarColor = true;
            this.pan_SW_C.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW_C.VerticalScrollbarSize = 10;
            // 
            // pan_C_middle
            // 
            this.pan_C_middle.Controls.Add(this.textBox1);
            this.pan_C_middle.Controls.Add(this.metroLabel31);
            this.pan_C_middle.Controls.Add(this.metroToggle1);
            this.pan_C_middle.Controls.Add(this.metroToggle2);
            this.pan_C_middle.Controls.Add(this.metroToggle3);
            this.pan_C_middle.Controls.Add(this.metroToggle4);
            this.pan_C_middle.Controls.Add(this.metroToggle5);
            this.pan_C_middle.Controls.Add(this.metroToggle6);
            this.pan_C_middle.Controls.Add(this.metroToggle7);
            this.pan_C_middle.Controls.Add(this.metroLabel34);
            this.pan_C_middle.Controls.Add(this.metroLabel35);
            this.pan_C_middle.Controls.Add(this.metroLabel36);
            this.pan_C_middle.Controls.Add(this.metroLabel37);
            this.pan_C_middle.Controls.Add(this.metroLabel38);
            this.pan_C_middle.Controls.Add(this.metroLabel39);
            this.pan_C_middle.Controls.Add(this.metroLabel40);
            this.pan_C_middle.Controls.Add(this.metroPanel5);
            this.pan_C_middle.Controls.Add(this.metroToggle8);
            this.pan_C_middle.Controls.Add(this.metroToggle9);
            this.pan_C_middle.Controls.Add(this.metroToggle10);
            this.pan_C_middle.Controls.Add(this.metroToggle11);
            this.pan_C_middle.Controls.Add(this.metroToggle12);
            this.pan_C_middle.Controls.Add(this.metroToggle13);
            this.pan_C_middle.Controls.Add(this.metroToggle14);
            this.pan_C_middle.Controls.Add(this.metroLabel41);
            this.pan_C_middle.Controls.Add(this.metroLabel42);
            this.pan_C_middle.Controls.Add(this.metroLabel43);
            this.pan_C_middle.Controls.Add(this.metroLabel44);
            this.pan_C_middle.Controls.Add(this.metroLabel45);
            this.pan_C_middle.Controls.Add(this.metroLabel46);
            this.pan_C_middle.Controls.Add(this.metroLabel47);
            this.pan_C_middle.Controls.Add(this.metroLabel48);
            this.pan_C_middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_C_middle.HorizontalScrollbarBarColor = true;
            this.pan_C_middle.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_C_middle.HorizontalScrollbarSize = 10;
            this.pan_C_middle.Location = new System.Drawing.Point(0, 160);
            this.pan_C_middle.Name = "pan_C_middle";
            this.pan_C_middle.Size = new System.Drawing.Size(666, 255);
            this.pan_C_middle.TabIndex = 42;
            this.pan_C_middle.VerticalScrollbarBarColor = true;
            this.pan_C_middle.VerticalScrollbarHighlightOnWheel = false;
            this.pan_C_middle.VerticalScrollbarSize = 10;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(424, 188);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(52, 23);
            this.textBox1.TabIndex = 54;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // metroLabel31
            // 
            this.metroLabel31.AutoSize = true;
            this.metroLabel31.Location = new System.Drawing.Point(251, 185);
            this.metroLabel31.Name = "metroLabel31";
            this.metroLabel31.Size = new System.Drawing.Size(139, 19);
            this.metroLabel31.TabIndex = 51;
            this.metroLabel31.Text = "MAX pairable devices:";
            this.metroLabel31.UseCustomBackColor = true;
            // 
            // metroToggle1
            // 
            this.metroToggle1.AutoSize = true;
            this.metroToggle1.Location = new System.Drawing.Point(396, 165);
            this.metroToggle1.Name = "metroToggle1";
            this.metroToggle1.Size = new System.Drawing.Size(80, 17);
            this.metroToggle1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle1.TabIndex = 50;
            this.metroToggle1.Text = "Off";
            this.metroToggle1.UseSelectable = true;
            // 
            // metroToggle2
            // 
            this.metroToggle2.AutoSize = true;
            this.metroToggle2.Location = new System.Drawing.Point(396, 125);
            this.metroToggle2.Name = "metroToggle2";
            this.metroToggle2.Size = new System.Drawing.Size(80, 17);
            this.metroToggle2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle2.TabIndex = 49;
            this.metroToggle2.Text = "Off";
            this.metroToggle2.UseSelectable = true;
            // 
            // metroToggle3
            // 
            this.metroToggle3.AutoSize = true;
            this.metroToggle3.Location = new System.Drawing.Point(396, 105);
            this.metroToggle3.Name = "metroToggle3";
            this.metroToggle3.Size = new System.Drawing.Size(80, 17);
            this.metroToggle3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle3.TabIndex = 48;
            this.metroToggle3.Text = "Off";
            this.metroToggle3.UseSelectable = true;
            // 
            // metroToggle4
            // 
            this.metroToggle4.AutoSize = true;
            this.metroToggle4.Location = new System.Drawing.Point(396, 85);
            this.metroToggle4.Name = "metroToggle4";
            this.metroToggle4.Size = new System.Drawing.Size(80, 17);
            this.metroToggle4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle4.TabIndex = 47;
            this.metroToggle4.Text = "Off";
            this.metroToggle4.UseSelectable = true;
            // 
            // metroToggle5
            // 
            this.metroToggle5.AutoSize = true;
            this.metroToggle5.Location = new System.Drawing.Point(396, 65);
            this.metroToggle5.Name = "metroToggle5";
            this.metroToggle5.Size = new System.Drawing.Size(80, 17);
            this.metroToggle5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle5.TabIndex = 46;
            this.metroToggle5.Text = "Off";
            this.metroToggle5.UseSelectable = true;
            // 
            // metroToggle6
            // 
            this.metroToggle6.AutoSize = true;
            this.metroToggle6.Location = new System.Drawing.Point(396, 45);
            this.metroToggle6.Name = "metroToggle6";
            this.metroToggle6.Size = new System.Drawing.Size(80, 17);
            this.metroToggle6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle6.TabIndex = 45;
            this.metroToggle6.Text = "Off";
            this.metroToggle6.UseSelectable = true;
            // 
            // metroToggle7
            // 
            this.metroToggle7.AutoSize = true;
            this.metroToggle7.Location = new System.Drawing.Point(396, 25);
            this.metroToggle7.Name = "metroToggle7";
            this.metroToggle7.Size = new System.Drawing.Size(80, 17);
            this.metroToggle7.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle7.TabIndex = 44;
            this.metroToggle7.Text = "Off";
            this.metroToggle7.UseSelectable = true;
            // 
            // metroLabel34
            // 
            this.metroLabel34.AutoSize = true;
            this.metroLabel34.Location = new System.Drawing.Point(251, 165);
            this.metroLabel34.Name = "metroLabel34";
            this.metroLabel34.Size = new System.Drawing.Size(102, 19);
            this.metroLabel34.TabIndex = 43;
            this.metroLabel34.Text = "Cambio Pagina:";
            this.metroLabel34.UseCustomBackColor = true;
            // 
            // metroLabel35
            // 
            this.metroLabel35.AutoSize = true;
            this.metroLabel35.Location = new System.Drawing.Point(251, 125);
            this.metroLabel35.Name = "metroLabel35";
            this.metroLabel35.Size = new System.Drawing.Size(71, 19);
            this.metroLabel35.TabIndex = 42;
            this.metroLabel35.Text = "Usa Torcia:";
            this.metroLabel35.UseCustomBackColor = true;
            // 
            // metroLabel36
            // 
            this.metroLabel36.AutoSize = true;
            this.metroLabel36.Location = new System.Drawing.Point(251, 105);
            this.metroLabel36.Name = "metroLabel36";
            this.metroLabel36.Size = new System.Drawing.Size(87, 19);
            this.metroLabel36.TabIndex = 41;
            this.metroLabel36.Text = "Usa Vibracall:";
            this.metroLabel36.UseCustomBackColor = true;
            // 
            // metroLabel37
            // 
            this.metroLabel37.AutoSize = true;
            this.metroLabel37.Location = new System.Drawing.Point(251, 85);
            this.metroLabel37.Name = "metroLabel37";
            this.metroLabel37.Size = new System.Drawing.Size(77, 19);
            this.metroLabel37.TabIndex = 40;
            this.metroLabel37.Text = "Usa Buzzer:";
            this.metroLabel37.UseCustomBackColor = true;
            // 
            // metroLabel38
            // 
            this.metroLabel38.AutoSize = true;
            this.metroLabel38.Location = new System.Drawing.Point(251, 65);
            this.metroLabel38.Name = "metroLabel38";
            this.metroLabel38.Size = new System.Drawing.Size(105, 19);
            this.metroLabel38.TabIndex = 39;
            this.metroLabel38.Text = "Usa Safety Point:";
            this.metroLabel38.UseCustomBackColor = true;
            // 
            // metroLabel39
            // 
            this.metroLabel39.AutoSize = true;
            this.metroLabel39.Location = new System.Drawing.Point(251, 45);
            this.metroLabel39.Name = "metroLabel39";
            this.metroLabel39.Size = new System.Drawing.Size(124, 19);
            this.metroLabel39.TabIndex = 38;
            this.metroLabel39.Text = "Usa Accelerometro:";
            this.metroLabel39.UseCustomBackColor = true;
            // 
            // metroLabel40
            // 
            this.metroLabel40.AutoSize = true;
            this.metroLabel40.Location = new System.Drawing.Point(251, 25);
            this.metroLabel40.Name = "metroLabel40";
            this.metroLabel40.Size = new System.Drawing.Size(89, 19);
            this.metroLabel40.TabIndex = 37;
            this.metroLabel40.Text = "Use Backlight:";
            this.metroLabel40.UseCustomBackColor = true;
            // 
            // metroPanel5
            // 
            this.metroPanel5.Controls.Add(this.metroRadioButton1);
            this.metroPanel5.Controls.Add(this.metroRadioButton2);
            this.metroPanel5.Controls.Add(this.metroRadioButton3);
            this.metroPanel5.Controls.Add(this.metroRadioButton4);
            this.metroPanel5.Controls.Add(this.metroRadioButton5);
            this.metroPanel5.HorizontalScrollbarBarColor = true;
            this.metroPanel5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel5.HorizontalScrollbarSize = 10;
            this.metroPanel5.Location = new System.Drawing.Point(150, 8);
            this.metroPanel5.Name = "metroPanel5";
            this.metroPanel5.Size = new System.Drawing.Size(353, 16);
            this.metroPanel5.TabIndex = 36;
            this.metroPanel5.VerticalScrollbarBarColor = true;
            this.metroPanel5.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel5.VerticalScrollbarSize = 10;
            // 
            // metroRadioButton1
            // 
            this.metroRadioButton1.AutoSize = true;
            this.metroRadioButton1.Location = new System.Drawing.Point(240, 0);
            this.metroRadioButton1.Name = "metroRadioButton1";
            this.metroRadioButton1.Size = new System.Drawing.Size(52, 15);
            this.metroRadioButton1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroRadioButton1.TabIndex = 36;
            this.metroRadioButton1.Text = "None";
            this.metroRadioButton1.UseCustomBackColor = true;
            this.metroRadioButton1.UseSelectable = true;
            this.metroRadioButton1.UseStyleColors = true;
            // 
            // metroRadioButton2
            // 
            this.metroRadioButton2.AutoSize = true;
            this.metroRadioButton2.Location = new System.Drawing.Point(180, 0);
            this.metroRadioButton2.Name = "metroRadioButton2";
            this.metroRadioButton2.Size = new System.Drawing.Size(42, 15);
            this.metroRadioButton2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroRadioButton2.TabIndex = 35;
            this.metroRadioButton2.Text = "Filo";
            this.metroRadioButton2.UseCustomBackColor = true;
            this.metroRadioButton2.UseSelectable = true;
            this.metroRadioButton2.UseStyleColors = true;
            // 
            // metroRadioButton3
            // 
            this.metroRadioButton3.AutoSize = true;
            this.metroRadioButton3.Location = new System.Drawing.Point(0, 0);
            this.metroRadioButton3.Name = "metroRadioButton3";
            this.metroRadioButton3.Size = new System.Drawing.Size(41, 15);
            this.metroRadioButton3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroRadioButton3.TabIndex = 32;
            this.metroRadioButton3.Text = "868";
            this.metroRadioButton3.UseCustomBackColor = true;
            this.metroRadioButton3.UseSelectable = true;
            this.metroRadioButton3.UseStyleColors = true;
            // 
            // metroRadioButton4
            // 
            this.metroRadioButton4.AutoSize = true;
            this.metroRadioButton4.Location = new System.Drawing.Point(120, 0);
            this.metroRadioButton4.Name = "metroRadioButton4";
            this.metroRadioButton4.Size = new System.Drawing.Size(41, 15);
            this.metroRadioButton4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroRadioButton4.TabIndex = 34;
            this.metroRadioButton4.Text = "433";
            this.metroRadioButton4.UseCustomBackColor = true;
            this.metroRadioButton4.UseSelectable = true;
            this.metroRadioButton4.UseStyleColors = true;
            // 
            // metroRadioButton5
            // 
            this.metroRadioButton5.AutoSize = true;
            this.metroRadioButton5.Location = new System.Drawing.Point(60, 0);
            this.metroRadioButton5.Name = "metroRadioButton5";
            this.metroRadioButton5.Size = new System.Drawing.Size(41, 15);
            this.metroRadioButton5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroRadioButton5.TabIndex = 33;
            this.metroRadioButton5.Text = "915";
            this.metroRadioButton5.UseCustomBackColor = true;
            this.metroRadioButton5.UseSelectable = true;
            this.metroRadioButton5.UseStyleColors = true;
            // 
            // metroToggle8
            // 
            this.metroToggle8.AutoSize = true;
            this.metroToggle8.Location = new System.Drawing.Point(150, 145);
            this.metroToggle8.Name = "metroToggle8";
            this.metroToggle8.Size = new System.Drawing.Size(80, 17);
            this.metroToggle8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle8.TabIndex = 28;
            this.metroToggle8.Text = "Off";
            this.metroToggle8.UseSelectable = true;
            // 
            // metroToggle9
            // 
            this.metroToggle9.AutoSize = true;
            this.metroToggle9.Location = new System.Drawing.Point(150, 125);
            this.metroToggle9.Name = "metroToggle9";
            this.metroToggle9.Size = new System.Drawing.Size(80, 17);
            this.metroToggle9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle9.TabIndex = 27;
            this.metroToggle9.Text = "Off";
            this.metroToggle9.UseSelectable = true;
            // 
            // metroToggle10
            // 
            this.metroToggle10.AutoSize = true;
            this.metroToggle10.Location = new System.Drawing.Point(150, 105);
            this.metroToggle10.Name = "metroToggle10";
            this.metroToggle10.Size = new System.Drawing.Size(80, 17);
            this.metroToggle10.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle10.TabIndex = 26;
            this.metroToggle10.Text = "Off";
            this.metroToggle10.UseSelectable = true;
            // 
            // metroToggle11
            // 
            this.metroToggle11.AutoSize = true;
            this.metroToggle11.Location = new System.Drawing.Point(150, 85);
            this.metroToggle11.Name = "metroToggle11";
            this.metroToggle11.Size = new System.Drawing.Size(80, 17);
            this.metroToggle11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle11.TabIndex = 25;
            this.metroToggle11.Text = "Off";
            this.metroToggle11.UseSelectable = true;
            // 
            // metroToggle12
            // 
            this.metroToggle12.AutoSize = true;
            this.metroToggle12.Location = new System.Drawing.Point(150, 65);
            this.metroToggle12.Name = "metroToggle12";
            this.metroToggle12.Size = new System.Drawing.Size(80, 17);
            this.metroToggle12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle12.TabIndex = 24;
            this.metroToggle12.Text = "Off";
            this.metroToggle12.UseSelectable = true;
            // 
            // metroToggle13
            // 
            this.metroToggle13.AutoSize = true;
            this.metroToggle13.Location = new System.Drawing.Point(150, 45);
            this.metroToggle13.Name = "metroToggle13";
            this.metroToggle13.Size = new System.Drawing.Size(80, 17);
            this.metroToggle13.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle13.TabIndex = 23;
            this.metroToggle13.Text = "Off";
            this.metroToggle13.UseSelectable = true;
            // 
            // metroToggle14
            // 
            this.metroToggle14.AutoSize = true;
            this.metroToggle14.Location = new System.Drawing.Point(150, 25);
            this.metroToggle14.Name = "metroToggle14";
            this.metroToggle14.Size = new System.Drawing.Size(80, 17);
            this.metroToggle14.Style = MetroFramework.MetroColorStyle.Red;
            this.metroToggle14.TabIndex = 22;
            this.metroToggle14.Text = "Off";
            this.metroToggle14.UseSelectable = true;
            // 
            // metroLabel41
            // 
            this.metroLabel41.AutoSize = true;
            this.metroLabel41.Location = new System.Drawing.Point(5, 145);
            this.metroLabel41.Name = "metroLabel41";
            this.metroLabel41.Size = new System.Drawing.Size(119, 19);
            this.metroLabel41.TabIndex = 20;
            this.metroLabel41.Text = "Fungo Emergenza:";
            this.metroLabel41.UseCustomBackColor = true;
            // 
            // metroLabel42
            // 
            this.metroLabel42.AutoSize = true;
            this.metroLabel42.Location = new System.Drawing.Point(5, 125);
            this.metroLabel42.Name = "metroLabel42";
            this.metroLabel42.Size = new System.Drawing.Size(46, 19);
            this.metroLabel42.TabIndex = 19;
            this.metroLabel42.Text = "Torcia:";
            this.metroLabel42.UseCustomBackColor = true;
            // 
            // metroLabel43
            // 
            this.metroLabel43.AutoSize = true;
            this.metroLabel43.Location = new System.Drawing.Point(5, 105);
            this.metroLabel43.Name = "metroLabel43";
            this.metroLabel43.Size = new System.Drawing.Size(62, 19);
            this.metroLabel43.TabIndex = 18;
            this.metroLabel43.Text = "Vibracall:";
            this.metroLabel43.UseCustomBackColor = true;
            // 
            // metroLabel44
            // 
            this.metroLabel44.AutoSize = true;
            this.metroLabel44.Location = new System.Drawing.Point(5, 85);
            this.metroLabel44.Name = "metroLabel44";
            this.metroLabel44.Size = new System.Drawing.Size(52, 19);
            this.metroLabel44.TabIndex = 17;
            this.metroLabel44.Text = "Buzzer:";
            this.metroLabel44.UseCustomBackColor = true;
            // 
            // metroLabel45
            // 
            this.metroLabel45.AutoSize = true;
            this.metroLabel45.Location = new System.Drawing.Point(5, 65);
            this.metroLabel45.Name = "metroLabel45";
            this.metroLabel45.Size = new System.Drawing.Size(80, 19);
            this.metroLabel45.TabIndex = 16;
            this.metroLabel45.Text = "Safety Point:";
            this.metroLabel45.UseCustomBackColor = true;
            // 
            // metroLabel46
            // 
            this.metroLabel46.AutoSize = true;
            this.metroLabel46.Location = new System.Drawing.Point(5, 45);
            this.metroLabel46.Name = "metroLabel46";
            this.metroLabel46.Size = new System.Drawing.Size(99, 19);
            this.metroLabel46.TabIndex = 15;
            this.metroLabel46.Text = "Accelerometro:";
            this.metroLabel46.UseCustomBackColor = true;
            // 
            // metroLabel47
            // 
            this.metroLabel47.AutoSize = true;
            this.metroLabel47.Location = new System.Drawing.Point(5, 25);
            this.metroLabel47.Name = "metroLabel47";
            this.metroLabel47.Size = new System.Drawing.Size(86, 19);
            this.metroLabel47.TabIndex = 14;
            this.metroLabel47.Text = "Display Oled:";
            this.metroLabel47.UseCustomBackColor = true;
            // 
            // metroLabel48
            // 
            this.metroLabel48.AutoSize = true;
            this.metroLabel48.Location = new System.Drawing.Point(5, 5);
            this.metroLabel48.Name = "metroLabel48";
            this.metroLabel48.Size = new System.Drawing.Size(111, 19);
            this.metroLabel48.TabIndex = 13;
            this.metroLabel48.Text = "Frequenza Radio:";
            this.metroLabel48.UseCustomBackColor = true;
            // 
            // pan_C_top
            // 
            this.pan_C_top.BackColor = System.Drawing.Color.White;
            this.pan_C_top.Controls.Add(this.pan_C_top_grid);
            this.pan_C_top.Controls.Add(this.pan_C_top_left);
            this.pan_C_top.Controls.Add(this.pan_C_top_top);
            this.pan_C_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_C_top.HorizontalScrollbarBarColor = true;
            this.pan_C_top.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_C_top.HorizontalScrollbarSize = 10;
            this.pan_C_top.Location = new System.Drawing.Point(0, 0);
            this.pan_C_top.Name = "pan_C_top";
            this.pan_C_top.Size = new System.Drawing.Size(666, 160);
            this.pan_C_top.TabIndex = 41;
            this.pan_C_top.VerticalScrollbarBarColor = true;
            this.pan_C_top.VerticalScrollbarHighlightOnWheel = false;
            this.pan_C_top.VerticalScrollbarSize = 10;
            // 
            // pan_C_top_grid
            // 
            this.pan_C_top_grid.Controls.Add(this.grid_C_SchedeCompatibili);
            this.pan_C_top_grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_C_top_grid.HorizontalScrollbarBarColor = true;
            this.pan_C_top_grid.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_C_top_grid.HorizontalScrollbarSize = 10;
            this.pan_C_top_grid.Location = new System.Drawing.Point(120, 30);
            this.pan_C_top_grid.Name = "pan_C_top_grid";
            this.pan_C_top_grid.Size = new System.Drawing.Size(546, 130);
            this.pan_C_top_grid.TabIndex = 43;
            this.pan_C_top_grid.VerticalScrollbarBarColor = true;
            this.pan_C_top_grid.VerticalScrollbarHighlightOnWheel = false;
            this.pan_C_top_grid.VerticalScrollbarSize = 10;
            // 
            // grid_C_SchedeCompatibili
            // 
            this.grid_C_SchedeCompatibili.AllowUserToAddRows = false;
            this.grid_C_SchedeCompatibili.AllowUserToDeleteRows = false;
            this.grid_C_SchedeCompatibili.AllowUserToResizeRows = false;
            this.grid_C_SchedeCompatibili.AutoGenerateColumns = false;
            this.grid_C_SchedeCompatibili.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid_C_SchedeCompatibili.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_C_SchedeCompatibili.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_C_SchedeCompatibili.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_C_SchedeCompatibili.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_C_SchedeCompatibili.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.grid_C_SchedeCompatibili.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_C_SchedeCompatibili.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.C_prodSch,
            this.C_prodDescrizione,
            this.C_SchedaCompatibile});
            this.grid_C_SchedeCompatibili.DataSource = this.famProdSchedeBindingSource;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_C_SchedeCompatibili.DefaultCellStyle = dataGridViewCellStyle8;
            this.grid_C_SchedeCompatibili.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_C_SchedeCompatibili.EnableHeadersVisualStyles = false;
            this.grid_C_SchedeCompatibili.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_C_SchedeCompatibili.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_C_SchedeCompatibili.HighLightPercentage = 1.5F;
            this.grid_C_SchedeCompatibili.Location = new System.Drawing.Point(0, 0);
            this.grid_C_SchedeCompatibili.Name = "grid_C_SchedeCompatibili";
            this.grid_C_SchedeCompatibili.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(188)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_C_SchedeCompatibili.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.grid_C_SchedeCompatibili.RowHeadersVisible = false;
            this.grid_C_SchedeCompatibili.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_C_SchedeCompatibili.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_C_SchedeCompatibili.Size = new System.Drawing.Size(546, 130);
            this.grid_C_SchedeCompatibili.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_C_SchedeCompatibili.TabIndex = 40;
            this.grid_C_SchedeCompatibili.UseStyleColors = true;
            // 
            // C_prodSch
            // 
            this.C_prodSch.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.C_prodSch.DataPropertyName = "Prod_Sch";
            this.C_prodSch.FillWeight = 20F;
            this.C_prodSch.HeaderText = "Scheda";
            this.C_prodSch.Name = "C_prodSch";
            this.C_prodSch.Width = 67;
            // 
            // C_prodDescrizione
            // 
            this.C_prodDescrizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.C_prodDescrizione.DataPropertyName = "Prod_Descrizione";
            this.C_prodDescrizione.FillWeight = 60F;
            this.C_prodDescrizione.HeaderText = "Descrizione Scheda";
            this.C_prodDescrizione.Name = "C_prodDescrizione";
            this.C_prodDescrizione.Width = 118;
            // 
            // C_SchedaCompatibile
            // 
            this.C_SchedaCompatibile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.C_SchedaCompatibile.FillWeight = 20F;
            this.C_SchedaCompatibile.HeaderText = "Comp.";
            this.C_SchedaCompatibile.Name = "C_SchedaCompatibile";
            this.C_SchedaCompatibile.Width = 44;
            // 
            // pan_C_top_left
            // 
            this.pan_C_top_left.Controls.Add(this.metroLabel49);
            this.pan_C_top_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_C_top_left.HorizontalScrollbarBarColor = true;
            this.pan_C_top_left.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_C_top_left.HorizontalScrollbarSize = 10;
            this.pan_C_top_left.Location = new System.Drawing.Point(0, 30);
            this.pan_C_top_left.Name = "pan_C_top_left";
            this.pan_C_top_left.Size = new System.Drawing.Size(120, 130);
            this.pan_C_top_left.TabIndex = 42;
            this.pan_C_top_left.VerticalScrollbarBarColor = true;
            this.pan_C_top_left.VerticalScrollbarHighlightOnWheel = false;
            this.pan_C_top_left.VerticalScrollbarSize = 10;
            // 
            // metroLabel49
            // 
            this.metroLabel49.AutoSize = true;
            this.metroLabel49.Location = new System.Drawing.Point(5, 0);
            this.metroLabel49.Name = "metroLabel49";
            this.metroLabel49.Size = new System.Drawing.Size(108, 19);
            this.metroLabel49.TabIndex = 9;
            this.metroLabel49.Text = "Scheda utilizzata:";
            this.metroLabel49.UseCustomBackColor = true;
            // 
            // pan_C_top_top
            // 
            this.pan_C_top_top.BackColor = System.Drawing.Color.White;
            this.pan_C_top_top.Controls.Add(this.ID_lab_Controller);
            this.pan_C_top_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_C_top_top.HorizontalScrollbarBarColor = true;
            this.pan_C_top_top.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_C_top_top.HorizontalScrollbarSize = 10;
            this.pan_C_top_top.Location = new System.Drawing.Point(0, 0);
            this.pan_C_top_top.Name = "pan_C_top_top";
            this.pan_C_top_top.Size = new System.Drawing.Size(666, 30);
            this.pan_C_top_top.TabIndex = 41;
            this.pan_C_top_top.VerticalScrollbarBarColor = true;
            this.pan_C_top_top.VerticalScrollbarHighlightOnWheel = false;
            this.pan_C_top_top.VerticalScrollbarSize = 10;
            // 
            // ID_lab_Controller
            // 
            this.ID_lab_Controller.AutoSize = true;
            this.ID_lab_Controller.Dock = System.Windows.Forms.DockStyle.Top;
            this.ID_lab_Controller.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.ID_lab_Controller.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.ID_lab_Controller.Location = new System.Drawing.Point(0, 0);
            this.ID_lab_Controller.Name = "ID_lab_Controller";
            this.ID_lab_Controller.Size = new System.Drawing.Size(90, 25);
            this.ID_lab_Controller.Style = MetroFramework.MetroColorStyle.Red;
            this.ID_lab_Controller.TabIndex = 7;
            this.ID_lab_Controller.Text = "Controller";
            this.ID_lab_Controller.UseCustomBackColor = true;
            this.ID_lab_Controller.UseStyleColors = true;
            // 
            // pan_SW__C_Testi
            // 
            this.pan_SW__C_Testi.BackColor = System.Drawing.Color.Linen;
            this.SW_Layout.SetColumnSpan(this.pan_SW__C_Testi, 4);
            this.pan_SW__C_Testi.Controls.Add(this.pan_C_Dx_Funzionamento);
            this.pan_SW__C_Testi.Controls.Add(this.pan_C_Dx_revisioni);
            this.pan_SW__C_Testi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_SW__C_Testi.HorizontalScrollbarBarColor = true;
            this.pan_SW__C_Testi.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_SW__C_Testi.HorizontalScrollbarSize = 10;
            this.pan_SW__C_Testi.Location = new System.Drawing.Point(675, 601);
            this.pan_SW__C_Testi.Name = "pan_SW__C_Testi";
            this.pan_SW__C_Testi.Size = new System.Drawing.Size(448, 415);
            this.pan_SW__C_Testi.TabIndex = 55;
            this.pan_SW__C_Testi.UseCustomBackColor = true;
            this.pan_SW__C_Testi.VerticalScrollbarBarColor = true;
            this.pan_SW__C_Testi.VerticalScrollbarHighlightOnWheel = false;
            this.pan_SW__C_Testi.VerticalScrollbarSize = 10;
            // 
            // pan_C_Dx_Funzionamento
            // 
            this.pan_C_Dx_Funzionamento.BackColor = System.Drawing.Color.Transparent;
            this.pan_C_Dx_Funzionamento.Controls.Add(this.metroPanel6);
            this.pan_C_Dx_Funzionamento.Controls.Add(this.metroPanel7);
            this.pan_C_Dx_Funzionamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_C_Dx_Funzionamento.HorizontalScrollbarBarColor = true;
            this.pan_C_Dx_Funzionamento.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_C_Dx_Funzionamento.HorizontalScrollbarSize = 10;
            this.pan_C_Dx_Funzionamento.Location = new System.Drawing.Point(0, 150);
            this.pan_C_Dx_Funzionamento.Name = "pan_C_Dx_Funzionamento";
            this.pan_C_Dx_Funzionamento.Size = new System.Drawing.Size(448, 265);
            this.pan_C_Dx_Funzionamento.TabIndex = 12;
            this.pan_C_Dx_Funzionamento.UseCustomBackColor = true;
            this.pan_C_Dx_Funzionamento.VerticalScrollbarBarColor = true;
            this.pan_C_Dx_Funzionamento.VerticalScrollbarHighlightOnWheel = false;
            this.pan_C_Dx_Funzionamento.VerticalScrollbarSize = 10;
            // 
            // metroPanel6
            // 
            this.metroPanel6.BackColor = System.Drawing.Color.Linen;
            this.metroPanel6.Controls.Add(this.richTextBox1);
            this.metroPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel6.HorizontalScrollbarBarColor = true;
            this.metroPanel6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel6.HorizontalScrollbarSize = 10;
            this.metroPanel6.Location = new System.Drawing.Point(0, 15);
            this.metroPanel6.Name = "metroPanel6";
            this.metroPanel6.Size = new System.Drawing.Size(448, 250);
            this.metroPanel6.TabIndex = 13;
            this.metroPanel6.UseCustomBackColor = true;
            this.metroPanel6.VerticalScrollbarBarColor = true;
            this.metroPanel6.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel6.VerticalScrollbarSize = 10;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.Linen;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(448, 250);
            this.richTextBox1.TabIndex = 11;
            this.richTextBox1.Text = "";
            // 
            // metroPanel7
            // 
            this.metroPanel7.BackColor = System.Drawing.Color.Linen;
            this.metroPanel7.Controls.Add(this.metroLabel50);
            this.metroPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel7.HorizontalScrollbarBarColor = true;
            this.metroPanel7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel7.HorizontalScrollbarSize = 10;
            this.metroPanel7.Location = new System.Drawing.Point(0, 0);
            this.metroPanel7.Name = "metroPanel7";
            this.metroPanel7.Size = new System.Drawing.Size(448, 15);
            this.metroPanel7.TabIndex = 12;
            this.metroPanel7.UseCustomBackColor = true;
            this.metroPanel7.VerticalScrollbarBarColor = true;
            this.metroPanel7.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel7.VerticalScrollbarSize = 10;
            // 
            // metroLabel50
            // 
            this.metroLabel50.AutoSize = true;
            this.metroLabel50.Location = new System.Drawing.Point(0, 0);
            this.metroLabel50.Name = "metroLabel50";
            this.metroLabel50.Size = new System.Drawing.Size(102, 19);
            this.metroLabel50.TabIndex = 10;
            this.metroLabel50.Text = "Funzionamento:";
            this.metroLabel50.UseCustomBackColor = true;
            // 
            // pan_C_Dx_revisioni
            // 
            this.pan_C_Dx_revisioni.BackColor = System.Drawing.Color.Transparent;
            this.pan_C_Dx_revisioni.Controls.Add(this.metroPanel9);
            this.pan_C_Dx_revisioni.Controls.Add(this.metroPanel10);
            this.pan_C_Dx_revisioni.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_C_Dx_revisioni.HorizontalScrollbarBarColor = true;
            this.pan_C_Dx_revisioni.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_C_Dx_revisioni.HorizontalScrollbarSize = 10;
            this.pan_C_Dx_revisioni.Location = new System.Drawing.Point(0, 0);
            this.pan_C_Dx_revisioni.Name = "pan_C_Dx_revisioni";
            this.pan_C_Dx_revisioni.Size = new System.Drawing.Size(448, 150);
            this.pan_C_Dx_revisioni.TabIndex = 11;
            this.pan_C_Dx_revisioni.UseCustomBackColor = true;
            this.pan_C_Dx_revisioni.VerticalScrollbarBarColor = true;
            this.pan_C_Dx_revisioni.VerticalScrollbarHighlightOnWheel = false;
            this.pan_C_Dx_revisioni.VerticalScrollbarSize = 10;
            // 
            // metroPanel9
            // 
            this.metroPanel9.Controls.Add(this.richTextBox2);
            this.metroPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel9.HorizontalScrollbarBarColor = true;
            this.metroPanel9.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel9.HorizontalScrollbarSize = 10;
            this.metroPanel9.Location = new System.Drawing.Point(0, 20);
            this.metroPanel9.Name = "metroPanel9";
            this.metroPanel9.Size = new System.Drawing.Size(448, 130);
            this.metroPanel9.TabIndex = 13;
            this.metroPanel9.VerticalScrollbarBarColor = true;
            this.metroPanel9.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel9.VerticalScrollbarSize = 10;
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Linen;
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.richTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.Location = new System.Drawing.Point(0, 0);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(448, 130);
            this.richTextBox2.TabIndex = 11;
            this.richTextBox2.Text = "";
            // 
            // metroPanel10
            // 
            this.metroPanel10.BackColor = System.Drawing.Color.Linen;
            this.metroPanel10.Controls.Add(this.metroLabel51);
            this.metroPanel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel10.HorizontalScrollbarBarColor = true;
            this.metroPanel10.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel10.HorizontalScrollbarSize = 10;
            this.metroPanel10.Location = new System.Drawing.Point(0, 0);
            this.metroPanel10.Name = "metroPanel10";
            this.metroPanel10.Size = new System.Drawing.Size(448, 20);
            this.metroPanel10.TabIndex = 12;
            this.metroPanel10.UseCustomBackColor = true;
            this.metroPanel10.VerticalScrollbarBarColor = true;
            this.metroPanel10.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel10.VerticalScrollbarSize = 10;
            // 
            // metroLabel51
            // 
            this.metroLabel51.AutoSize = true;
            this.metroLabel51.Location = new System.Drawing.Point(0, 0);
            this.metroLabel51.Name = "metroLabel51";
            this.metroLabel51.Size = new System.Drawing.Size(62, 19);
            this.metroLabel51.TabIndex = 10;
            this.metroLabel51.Text = "Revisioni:";
            this.metroLabel51.UseCustomBackColor = true;
            // 
            // UC_form_Sw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.SW_Layout);
            this.Name = "UC_form_Sw";
            this.Size = new System.Drawing.Size(1126, 1500);
            this.Load += new System.EventHandler(this.UC_form_Sw_Load);
            this.pan_SW_C_OLD.ResumeLayout(false);
            this.pan_SW_C_OLD.PerformLayout();
            this.metroPanel3.ResumeLayout(false);
            this.metroPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).EndInit();
            this.pan_SW__P_Testi.ResumeLayout(false);
            this.pan_P_Dx_Funzionamento.ResumeLayout(false);
            this.funz_fill.ResumeLayout(false);
            this.funz_top.ResumeLayout(false);
            this.funz_top.PerformLayout();
            this.pan_P_Dx_revisioni.ResumeLayout(false);
            this.rev_fill.ResumeLayout(false);
            this.rev_top.ResumeLayout(false);
            this.rev_top.PerformLayout();
            this.pan_SW_P.ResumeLayout(false);
            this.pan_P_middle.ResumeLayout(false);
            this.pan_P_middle.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.pan_P_top.ResumeLayout(false);
            this.pan_P_top_grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_P_SchedeCompatibili)).EndInit();
            this.pan_P_top_left.ResumeLayout(false);
            this.pan_P_top_left.PerformLayout();
            this.pan_P_top_top.ResumeLayout(false);
            this.pan_P_top_top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_SW_codificati)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdSoftwareBindingSource)).EndInit();
            this.pan_SW_Codifica.ResumeLayout(false);
            this.pan_SW_Codifica.PerformLayout();
            this.pan_SW_Titolo.ResumeLayout(false);
            this.pan_SW_Titolo.PerformLayout();
            this.SW_Layout.ResumeLayout(false);
            this.SW_Layout.PerformLayout();
            this.pan_Menu_comandi.ResumeLayout(false);
            this.pan_Menu_comandi.PerformLayout();
            this.pan_Menu_salva.ResumeLayout(false);
            this.pan_Menu_salva.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.pan_SW_C.ResumeLayout(false);
            this.pan_C_middle.ResumeLayout(false);
            this.pan_C_middle.PerformLayout();
            this.metroPanel5.ResumeLayout(false);
            this.metroPanel5.PerformLayout();
            this.pan_C_top.ResumeLayout(false);
            this.pan_C_top_grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_C_SchedeCompatibili)).EndInit();
            this.pan_C_top_left.ResumeLayout(false);
            this.pan_C_top_left.PerformLayout();
            this.pan_C_top_top.ResumeLayout(false);
            this.pan_C_top_top.PerformLayout();
            this.pan_SW__C_Testi.ResumeLayout(false);
            this.pan_C_Dx_Funzionamento.ResumeLayout(false);
            this.metroPanel6.ResumeLayout(false);
            this.metroPanel7.ResumeLayout(false);
            this.metroPanel7.PerformLayout();
            this.pan_C_Dx_revisioni.ResumeLayout(false);
            this.metroPanel9.ResumeLayout(false);
            this.metroPanel10.ResumeLayout(false);
            this.metroPanel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel pan_SW_C_OLD;
        private MetroFramework.Controls.MetroLabel lab_Des_Scheda_C;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroRadioButton ID_radio_868_C;
        private MetroFramework.Controls.MetroRadioButton ID_radio_433_C;
        private MetroFramework.Controls.MetroRadioButton ID_radio_915_C;
        private MetroFramework.Controls.MetroToggle ID_toggle_Prop;
        private MetroFramework.Controls.MetroToggle ID_toggle_CanBus;
        private MetroFramework.Controls.MetroToggle ID_toggle_AntExt;
        private MetroFramework.Controls.MetroToggle ID_toggle_GuidaLuce;
        private MetroFramework.Controls.MetroToggle ID_toggle_TastEmerg;
        private MetroFramework.Controls.MetroToggle ID_toggle_PlugPLE;
        private MetroFramework.Controls.MetroToggle ID_toggle_PlugExp;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroRadioButton ID_radio_868_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_433_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_915_P;
        private MetroFramework.Controls.MetroToggle ID_toggle_Fungo;
        private MetroFramework.Controls.MetroToggle ID_toggle_Torcia;
        private MetroFramework.Controls.MetroToggle ID_toggle_Vibracall;
        private MetroFramework.Controls.MetroToggle ID_toggle_Buzzer;
        private MetroFramework.Controls.MetroToggle ID_toggle_SP;
        private MetroFramework.Controls.MetroToggle ID_toggle_Accel;
        private MetroFramework.Controls.MetroToggle ID_toggle_Display;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel ID_lab_Palmare;
        private System.Windows.Forms.ComboBox ID_combo_Famiglia;
        private MetroFramework.Controls.MetroLabel titolo_ID;
        private MetroFramework.Controls.MetroLabel SW_lab_Famiglia;
        private MetroFramework.Controls.MetroLabel SW_lab_codice_SW;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_frequency;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_version;
        private System.Windows.Forms.MaskedTextBox tbox_Sw_name;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroGrid grid_SW_codificati;
        private MetroFramework.Controls.MetroPanel pan_SW_Codifica;
        private MetroFramework.Controls.MetroPanel pan_SW_Titolo;
        private System.Windows.Forms.BindingSource famProdSchedeBindingSource;
        private System.Windows.Forms.BindingSource famProdBindingSource;
        private DB_FactoryDataSet dB_FactoryDataSet;
        private System.Windows.Forms.BindingSource famProdSoftwareBindingSource;
        private DB_FactoryDataSetTableAdapters.Fam_ProdTableAdapter fam_ProdTableAdapter;
        private DB_FactoryDataSetTableAdapters.SchedeTableAdapter schedeTableAdapter;
        private DB_FactoryDataSetTableAdapters.SoftwareTableAdapter softwareTableAdapter;
        private MetroFramework.Controls.MetroGrid grid_P_SchedeCompatibili;
        private MetroFramework.Controls.MetroPanel pan_P_middle;
        private MetroFramework.Controls.MetroPanel pan_P_top;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private MetroFramework.Controls.MetroToggle ID_toggle_ShiftPage;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Torch;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Vibracall;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Buzzer;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_SP;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Accel;
        private MetroFramework.Controls.MetroToggle ID_toggle_use_Backlight;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroPanel pan_SW_P;
        private MetroFramework.Controls.MetroPanel pan_SW__P_Testi;
        private MetroFramework.Controls.MetroPanel pan_P_Dx_revisioni;
        private System.Windows.Forms.RichTextBox richtb_Revisioni;
        private MetroFramework.Controls.MetroContextMenu metroContextMenu1;
        private MetroFramework.Controls.MetroPanel pan_P_Dx_Funzionamento;
        private System.Windows.Forms.RichTextBox richtb_Funzioni;
        private MetroFramework.Controls.MetroLabel metroLabel32;
        private MetroFramework.Controls.MetroPanel rev_fill;
        private MetroFramework.Controls.MetroPanel rev_top;
        private MetroFramework.Controls.MetroLabel metroLabel33;
        private MetroFramework.Controls.MetroPanel funz_fill;
        private MetroFramework.Controls.MetroPanel funz_top;
        private System.Windows.Forms.TableLayoutPanel SW_Layout;
        private System.Windows.Forms.MenuStrip pan_Menu_comandi;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_new;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_edit;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div01;
        private System.Windows.Forms.TextBox tb_Max_Pairable;
        private MetroFramework.Controls.MetroRadioButton ID_radio_None_P;
        private MetroFramework.Controls.MetroRadioButton ID_radio_Filo_P;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_creapdf;
        private MetroFramework.Controls.MetroPanel pan_P_top_grid;
        private MetroFramework.Controls.MetroPanel pan_P_top_left;
        private MetroFramework.Controls.MetroPanel pan_P_top_top;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div02;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_clona;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div03;
        private System.Windows.Forms.ToolStripMenuItem creaRevisioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div04;
        private System.Windows.Forms.MenuStrip pan_Menu_salva;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div11;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_salva;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div12;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_annulla;
        private MetroFramework.Controls.MetroPanel pan_SW_C;
        private MetroFramework.Controls.MetroPanel pan_C_middle;
        private System.Windows.Forms.TextBox textBox1;
        private MetroFramework.Controls.MetroLabel metroLabel31;
        private MetroFramework.Controls.MetroToggle metroToggle1;
        private MetroFramework.Controls.MetroToggle metroToggle2;
        private MetroFramework.Controls.MetroToggle metroToggle3;
        private MetroFramework.Controls.MetroToggle metroToggle4;
        private MetroFramework.Controls.MetroToggle metroToggle5;
        private MetroFramework.Controls.MetroToggle metroToggle6;
        private MetroFramework.Controls.MetroToggle metroToggle7;
        private MetroFramework.Controls.MetroLabel metroLabel34;
        private MetroFramework.Controls.MetroLabel metroLabel35;
        private MetroFramework.Controls.MetroLabel metroLabel36;
        private MetroFramework.Controls.MetroLabel metroLabel37;
        private MetroFramework.Controls.MetroLabel metroLabel38;
        private MetroFramework.Controls.MetroLabel metroLabel39;
        private MetroFramework.Controls.MetroLabel metroLabel40;
        private MetroFramework.Controls.MetroPanel metroPanel5;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton1;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton2;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton3;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton4;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton5;
        private MetroFramework.Controls.MetroToggle metroToggle8;
        private MetroFramework.Controls.MetroToggle metroToggle9;
        private MetroFramework.Controls.MetroToggle metroToggle10;
        private MetroFramework.Controls.MetroToggle metroToggle11;
        private MetroFramework.Controls.MetroToggle metroToggle12;
        private MetroFramework.Controls.MetroToggle metroToggle13;
        private MetroFramework.Controls.MetroToggle metroToggle14;
        private MetroFramework.Controls.MetroLabel metroLabel41;
        private MetroFramework.Controls.MetroLabel metroLabel42;
        private MetroFramework.Controls.MetroLabel metroLabel43;
        private MetroFramework.Controls.MetroLabel metroLabel44;
        private MetroFramework.Controls.MetroLabel metroLabel45;
        private MetroFramework.Controls.MetroLabel metroLabel46;
        private MetroFramework.Controls.MetroLabel metroLabel47;
        private MetroFramework.Controls.MetroLabel metroLabel48;
        private MetroFramework.Controls.MetroPanel pan_C_top;
        private MetroFramework.Controls.MetroPanel pan_C_top_grid;
        private MetroFramework.Controls.MetroGrid grid_C_SchedeCompatibili;
        private System.Windows.Forms.DataGridViewTextBoxColumn C_prodSch;
        private System.Windows.Forms.DataGridViewTextBoxColumn C_prodDescrizione;
        private System.Windows.Forms.DataGridViewCheckBoxColumn C_SchedaCompatibile;
        private MetroFramework.Controls.MetroPanel pan_C_top_left;
        private MetroFramework.Controls.MetroLabel metroLabel49;
        private MetroFramework.Controls.MetroPanel pan_C_top_top;
        private MetroFramework.Controls.MetroLabel ID_lab_Controller;
        private MetroFramework.Controls.MetroPanel pan_SW__C_Testi;
        private MetroFramework.Controls.MetroPanel pan_C_Dx_Funzionamento;
        private MetroFramework.Controls.MetroPanel metroPanel6;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private MetroFramework.Controls.MetroPanel metroPanel7;
        private MetroFramework.Controls.MetroLabel metroLabel50;
        private MetroFramework.Controls.MetroPanel pan_C_Dx_revisioni;
        private MetroFramework.Controls.MetroPanel metroPanel9;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private MetroFramework.Controls.MetroPanel metroPanel10;
        private MetroFramework.Controls.MetroLabel metroLabel51;
        private System.Windows.Forms.DataGridViewTextBoxColumn SW_Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWSchedeCompatibiliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_prodSch;
        private System.Windows.Forms.DataGridViewTextBoxColumn P_prodDescrizione;
        private System.Windows.Forms.DataGridViewCheckBoxColumn P_SchedaCompatibile;
    }
}
