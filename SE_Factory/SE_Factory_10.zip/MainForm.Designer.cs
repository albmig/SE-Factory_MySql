﻿namespace SE_Factory
{
    partial class MainForm
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel_Menu = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_Home = new MetroFramework.Controls.MetroTile();
            this.menu_spacer_05 = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_Clienti = new MetroFramework.Controls.MetroTile();
            this.menu_spacer_04 = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_Sw = new MetroFramework.Controls.MetroTile();
            this.menu_spacer_03 = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_prodotti = new MetroFramework.Controls.MetroTile();
            this.menu_spacer_02 = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_printer = new MetroFramework.Controls.MetroTile();
            this.menu_spacer_01 = new MetroFramework.Controls.MetroPanel();
            this.menu_btn_ID = new MetroFramework.Controls.MetroTile();
            this.panel_default_printer = new MetroFramework.Controls.MetroPanel();
            this.lab_def_printer = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.panel_Application = new MetroFramework.Controls.MetroUserControl();
            this.dB_FactoryDataSet = new SE_Factory.DB_FactoryDataSet();
            this.printersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.printersTableAdapter = new SE_Factory.DB_FactoryDataSetTableAdapters.PrintersTableAdapter();
            this.panel_Menu.SuspendLayout();
            this.panel_default_printer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.printersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Menu
            // 
            this.panel_Menu.BackColor = System.Drawing.Color.Transparent;
            this.panel_Menu.Controls.Add(this.menu_btn_Home);
            this.panel_Menu.Controls.Add(this.menu_spacer_05);
            this.panel_Menu.Controls.Add(this.menu_btn_Clienti);
            this.panel_Menu.Controls.Add(this.menu_spacer_04);
            this.panel_Menu.Controls.Add(this.menu_btn_Sw);
            this.panel_Menu.Controls.Add(this.menu_spacer_03);
            this.panel_Menu.Controls.Add(this.menu_btn_prodotti);
            this.panel_Menu.Controls.Add(this.menu_spacer_02);
            this.panel_Menu.Controls.Add(this.menu_btn_printer);
            this.panel_Menu.Controls.Add(this.menu_spacer_01);
            this.panel_Menu.Controls.Add(this.menu_btn_ID);
            this.panel_Menu.Controls.Add(this.panel_default_printer);
            this.panel_Menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Menu.HorizontalScrollbarBarColor = true;
            this.panel_Menu.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Menu.HorizontalScrollbarSize = 10;
            this.panel_Menu.Location = new System.Drawing.Point(23, 83);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(150, 590);
            this.panel_Menu.TabIndex = 1;
            this.panel_Menu.VerticalScrollbarBarColor = true;
            this.panel_Menu.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Menu.VerticalScrollbarSize = 10;
            // 
            // menu_btn_Home
            // 
            this.menu_btn_Home.ActiveControl = null;
            this.menu_btn_Home.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menu_btn_Home.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_Home.ForeColor = System.Drawing.SystemColors.ControlText;
            this.menu_btn_Home.Location = new System.Drawing.Point(0, 276);
            this.menu_btn_Home.Name = "menu_btn_Home";
            this.menu_btn_Home.Size = new System.Drawing.Size(150, 42);
            this.menu_btn_Home.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_Home.TabIndex = 9;
            this.menu_btn_Home.Text = "Uscita";
            this.menu_btn_Home.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_Home.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_Home.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_Home.TileImage")));
            this.menu_btn_Home.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_Home.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_Home.UseCustomBackColor = true;
            this.menu_btn_Home.UseCustomForeColor = true;
            this.menu_btn_Home.UseSelectable = true;
            this.menu_btn_Home.UseTileImage = true;
            this.menu_btn_Home.Click += new System.EventHandler(this.bt_Home_Click);
            // 
            // menu_spacer_05
            // 
            this.menu_spacer_05.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_spacer_05.HorizontalScrollbarBarColor = true;
            this.menu_spacer_05.HorizontalScrollbarHighlightOnWheel = false;
            this.menu_spacer_05.HorizontalScrollbarSize = 10;
            this.menu_spacer_05.Location = new System.Drawing.Point(0, 266);
            this.menu_spacer_05.Name = "menu_spacer_05";
            this.menu_spacer_05.Size = new System.Drawing.Size(150, 10);
            this.menu_spacer_05.TabIndex = 16;
            this.menu_spacer_05.VerticalScrollbarBarColor = true;
            this.menu_spacer_05.VerticalScrollbarHighlightOnWheel = false;
            this.menu_spacer_05.VerticalScrollbarSize = 10;
            // 
            // menu_btn_Clienti
            // 
            this.menu_btn_Clienti.ActiveControl = null;
            this.menu_btn_Clienti.BackColor = System.Drawing.SystemColors.Control;
            this.menu_btn_Clienti.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_Clienti.ForeColor = System.Drawing.SystemColors.ControlText;
            this.menu_btn_Clienti.Location = new System.Drawing.Point(0, 224);
            this.menu_btn_Clienti.Name = "menu_btn_Clienti";
            this.menu_btn_Clienti.Size = new System.Drawing.Size(150, 42);
            this.menu_btn_Clienti.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_Clienti.TabIndex = 15;
            this.menu_btn_Clienti.Text = "Conv. Clienti";
            this.menu_btn_Clienti.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_Clienti.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_Clienti.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_Clienti.TileImage")));
            this.menu_btn_Clienti.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_Clienti.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_Clienti.UseCustomBackColor = true;
            this.menu_btn_Clienti.UseCustomForeColor = true;
            this.menu_btn_Clienti.UseSelectable = true;
            this.menu_btn_Clienti.UseTileImage = true;
            this.menu_btn_Clienti.Click += new System.EventHandler(this.menu_btn_Clienti_Click);
            // 
            // menu_spacer_04
            // 
            this.menu_spacer_04.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_spacer_04.HorizontalScrollbarBarColor = true;
            this.menu_spacer_04.HorizontalScrollbarHighlightOnWheel = false;
            this.menu_spacer_04.HorizontalScrollbarSize = 10;
            this.menu_spacer_04.Location = new System.Drawing.Point(0, 214);
            this.menu_spacer_04.Name = "menu_spacer_04";
            this.menu_spacer_04.Size = new System.Drawing.Size(150, 10);
            this.menu_spacer_04.TabIndex = 14;
            this.menu_spacer_04.VerticalScrollbarBarColor = true;
            this.menu_spacer_04.VerticalScrollbarHighlightOnWheel = false;
            this.menu_spacer_04.VerticalScrollbarSize = 10;
            // 
            // menu_btn_Sw
            // 
            this.menu_btn_Sw.ActiveControl = null;
            this.menu_btn_Sw.BackColor = System.Drawing.SystemColors.Control;
            this.menu_btn_Sw.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_Sw.ForeColor = System.Drawing.SystemColors.ControlText;
            this.menu_btn_Sw.Location = new System.Drawing.Point(0, 172);
            this.menu_btn_Sw.Name = "menu_btn_Sw";
            this.menu_btn_Sw.Size = new System.Drawing.Size(150, 42);
            this.menu_btn_Sw.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_Sw.TabIndex = 13;
            this.menu_btn_Sw.Text = "Doc. Software";
            this.menu_btn_Sw.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_Sw.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_Sw.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_Sw.TileImage")));
            this.menu_btn_Sw.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_Sw.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_Sw.UseCustomBackColor = true;
            this.menu_btn_Sw.UseCustomForeColor = true;
            this.menu_btn_Sw.UseSelectable = true;
            this.menu_btn_Sw.UseTileImage = true;
            this.menu_btn_Sw.Click += new System.EventHandler(this.menu_btn_Sw_Click);
            // 
            // menu_spacer_03
            // 
            this.menu_spacer_03.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_spacer_03.HorizontalScrollbarBarColor = true;
            this.menu_spacer_03.HorizontalScrollbarHighlightOnWheel = false;
            this.menu_spacer_03.HorizontalScrollbarSize = 10;
            this.menu_spacer_03.Location = new System.Drawing.Point(0, 162);
            this.menu_spacer_03.Name = "menu_spacer_03";
            this.menu_spacer_03.Size = new System.Drawing.Size(150, 10);
            this.menu_spacer_03.TabIndex = 11;
            this.menu_spacer_03.VerticalScrollbarBarColor = true;
            this.menu_spacer_03.VerticalScrollbarHighlightOnWheel = false;
            this.menu_spacer_03.VerticalScrollbarSize = 10;
            // 
            // menu_btn_prodotti
            // 
            this.menu_btn_prodotti.ActiveControl = null;
            this.menu_btn_prodotti.BackColor = System.Drawing.SystemColors.Control;
            this.menu_btn_prodotti.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_prodotti.ForeColor = System.Drawing.SystemColors.ControlText;
            this.menu_btn_prodotti.Location = new System.Drawing.Point(0, 120);
            this.menu_btn_prodotti.Name = "menu_btn_prodotti";
            this.menu_btn_prodotti.Size = new System.Drawing.Size(150, 42);
            this.menu_btn_prodotti.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_prodotti.TabIndex = 12;
            this.menu_btn_prodotti.Text = "Prodotti";
            this.menu_btn_prodotti.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_prodotti.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_prodotti.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_prodotti.TileImage")));
            this.menu_btn_prodotti.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_prodotti.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_prodotti.UseCustomBackColor = true;
            this.menu_btn_prodotti.UseCustomForeColor = true;
            this.menu_btn_prodotti.UseSelectable = true;
            this.menu_btn_prodotti.UseTileImage = true;
            this.menu_btn_prodotti.Click += new System.EventHandler(this.menu_btn_prodotti_Click);
            // 
            // menu_spacer_02
            // 
            this.menu_spacer_02.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_spacer_02.HorizontalScrollbarBarColor = true;
            this.menu_spacer_02.HorizontalScrollbarHighlightOnWheel = false;
            this.menu_spacer_02.HorizontalScrollbarSize = 10;
            this.menu_spacer_02.Location = new System.Drawing.Point(0, 110);
            this.menu_spacer_02.Name = "menu_spacer_02";
            this.menu_spacer_02.Size = new System.Drawing.Size(150, 10);
            this.menu_spacer_02.TabIndex = 5;
            this.menu_spacer_02.VerticalScrollbarBarColor = true;
            this.menu_spacer_02.VerticalScrollbarHighlightOnWheel = false;
            this.menu_spacer_02.VerticalScrollbarSize = 10;
            // 
            // menu_btn_printer
            // 
            this.menu_btn_printer.ActiveControl = null;
            this.menu_btn_printer.BackColor = System.Drawing.SystemColors.Control;
            this.menu_btn_printer.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_printer.Location = new System.Drawing.Point(0, 60);
            this.menu_btn_printer.Name = "menu_btn_printer";
            this.menu_btn_printer.Size = new System.Drawing.Size(150, 50);
            this.menu_btn_printer.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_printer.TabIndex = 4;
            this.menu_btn_printer.Text = "IP Stampante";
            this.menu_btn_printer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_printer.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_printer.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_printer.TileImage")));
            this.menu_btn_printer.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_printer.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_printer.UseCustomBackColor = true;
            this.menu_btn_printer.UseCustomForeColor = true;
            this.menu_btn_printer.UseSelectable = true;
            this.menu_btn_printer.UseTileImage = true;
            this.menu_btn_printer.Click += new System.EventHandler(this.menu_btn_printer_Click);
            // 
            // menu_spacer_01
            // 
            this.menu_spacer_01.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_spacer_01.HorizontalScrollbarBarColor = true;
            this.menu_spacer_01.HorizontalScrollbarHighlightOnWheel = false;
            this.menu_spacer_01.HorizontalScrollbarSize = 10;
            this.menu_spacer_01.Location = new System.Drawing.Point(0, 50);
            this.menu_spacer_01.Name = "menu_spacer_01";
            this.menu_spacer_01.Size = new System.Drawing.Size(150, 10);
            this.menu_spacer_01.TabIndex = 3;
            this.menu_spacer_01.VerticalScrollbarBarColor = true;
            this.menu_spacer_01.VerticalScrollbarHighlightOnWheel = false;
            this.menu_spacer_01.VerticalScrollbarSize = 10;
            // 
            // menu_btn_ID
            // 
            this.menu_btn_ID.ActiveControl = null;
            this.menu_btn_ID.BackColor = System.Drawing.SystemColors.Control;
            this.menu_btn_ID.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu_btn_ID.Location = new System.Drawing.Point(0, 0);
            this.menu_btn_ID.Name = "menu_btn_ID";
            this.menu_btn_ID.Size = new System.Drawing.Size(150, 50);
            this.menu_btn_ID.Style = MetroFramework.MetroColorStyle.White;
            this.menu_btn_ID.TabIndex = 2;
            this.menu_btn_ID.Text = "Calcolo ID";
            this.menu_btn_ID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menu_btn_ID.Theme = MetroFramework.MetroThemeStyle.Light;
            this.menu_btn_ID.TileImage = ((System.Drawing.Image)(resources.GetObject("menu_btn_ID.TileImage")));
            this.menu_btn_ID.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_btn_ID.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.menu_btn_ID.UseCustomBackColor = true;
            this.menu_btn_ID.UseCustomForeColor = true;
            this.menu_btn_ID.UseSelectable = true;
            this.menu_btn_ID.UseTileImage = true;
            this.menu_btn_ID.Click += new System.EventHandler(this.menu_btn_ID_Click);
            // 
            // panel_default_printer
            // 
            this.panel_default_printer.Controls.Add(this.lab_def_printer);
            this.panel_default_printer.Controls.Add(this.metroLabel1);
            this.panel_default_printer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_default_printer.HorizontalScrollbarBarColor = true;
            this.panel_default_printer.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_default_printer.HorizontalScrollbarSize = 10;
            this.panel_default_printer.Location = new System.Drawing.Point(0, 530);
            this.panel_default_printer.Name = "panel_default_printer";
            this.panel_default_printer.Size = new System.Drawing.Size(150, 60);
            this.panel_default_printer.TabIndex = 10;
            this.panel_default_printer.VerticalScrollbarBarColor = true;
            this.panel_default_printer.VerticalScrollbarHighlightOnWheel = false;
            this.panel_default_printer.VerticalScrollbarSize = 10;
            // 
            // lab_def_printer
            // 
            this.lab_def_printer.AutoSize = true;
            this.lab_def_printer.Dock = System.Windows.Forms.DockStyle.Top;
            this.lab_def_printer.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_def_printer.Location = new System.Drawing.Point(0, 19);
            this.lab_def_printer.Name = "lab_def_printer";
            this.lab_def_printer.Size = new System.Drawing.Size(94, 19);
            this.lab_def_printer.TabIndex = 3;
            this.lab_def_printer.Text = "metroLabel2";
            this.lab_def_printer.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(0, 0);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(124, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Stampante definita";
            this.metroLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel_Application
            // 
            this.panel_Application.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_Application.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Application.Location = new System.Drawing.Point(173, 83);
            this.panel_Application.Name = "panel_Application";
            this.panel_Application.Size = new System.Drawing.Size(770, 590);
            this.panel_Application.TabIndex = 4;
            this.panel_Application.UseSelectable = true;
            this.panel_Application.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.panel_Application_ControlRemoved);
            // 
            // dB_FactoryDataSet
            // 
            this.dB_FactoryDataSet.DataSetName = "DB_FactoryDataSet";
            this.dB_FactoryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // printersBindingSource
            // 
            this.printersBindingSource.DataMember = "Printers";
            this.printersBindingSource.DataSource = this.dB_FactoryDataSet;
            // 
            // printersTableAdapter
            // 
            this.printersTableAdapter.ClearBeforeFill = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 701);
            this.Controls.Add(this.panel_Application);
            this.Controls.Add(this.panel_Menu);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(23, 83, 23, 28);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica Factory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel_Menu.ResumeLayout(false);
            this.panel_default_printer.ResumeLayout(false);
            this.panel_default_printer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dB_FactoryDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.printersBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel panel_Menu;
        private MetroFramework.Controls.MetroTile menu_btn_ID;
        private MetroFramework.Controls.MetroPanel menu_spacer_01;
        private MetroFramework.Controls.MetroUserControl panel_Application;
        private MetroFramework.Controls.MetroPanel menu_spacer_02;
        private MetroFramework.Controls.MetroTile menu_btn_printer;
        private MetroFramework.Controls.MetroTile menu_btn_Home;
        private MetroFramework.Controls.MetroPanel panel_default_printer;
        private MetroFramework.Controls.MetroLabel lab_def_printer;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private DB_FactoryDataSet dB_FactoryDataSet;
        private System.Windows.Forms.BindingSource printersBindingSource;
        private DB_FactoryDataSetTableAdapters.PrintersTableAdapter printersTableAdapter;
        private MetroFramework.Controls.MetroPanel menu_spacer_03;
        private MetroFramework.Controls.MetroTile menu_btn_prodotti;
        private MetroFramework.Controls.MetroTile menu_btn_Sw;
        private MetroFramework.Controls.MetroPanel menu_spacer_04;
        private MetroFramework.Controls.MetroPanel menu_spacer_05;
        private MetroFramework.Controls.MetroTile menu_btn_Clienti;
    }
}

